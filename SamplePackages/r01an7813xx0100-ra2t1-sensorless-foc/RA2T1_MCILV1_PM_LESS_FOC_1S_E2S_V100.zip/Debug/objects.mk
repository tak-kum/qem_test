################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -l:RM_DSP_RA2_GCC_32BIT.o -l:rm_mtr_ctrl_gain.o -l:ICS2_RA2T1.o -l:rm_mtr_ol2cl_ctrl.o -l:rm_mtr_est_phase_err.o

