/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_mtr_config.h
* Description  : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_CONFIG_H
#define R_MTR_CONFIG_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Created date : 2025/05/14 */

#define IP_MCK
#define MP_R42BLD30L3_A_a1
#define CP_R42BLD30L3_A_a1


/* Select of current sensing method
* - SINGLE_SHUNT(default)
* - THREE_SHUNT
*/
#define SINGLE_SHUNT           (0)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define THREE_SHUNT            (1)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */

#define CURRENT_SENS_METHOD    (SINGLE_SHUNT)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */

/*
 * Define the macro as 1 to enable the utility
 * as 0 to disable the utility
 */

/* Defines whether use deadtime compensation in FOC */
#define USE_DEADTIME_COMP          (1)
/* Defines whether use speed LPF */
#define USE_SPEED_LPF              (1)
/* Defines whether use current LPF */
#define USE_CURRENT_LPF_IQ         (0)
#define USE_CURRENT_LPF_ID         (0)
/* Defines whether use Open-loop damping Control */
#define USE_OPENLOOP_DAMPING       (1)
/* Defines Current compensation for 2-phase duty cross */
#define USE_DUTY_2PH_CROS_COMP     (1)
/* Defines Open-loop to Closed-loop switch Control */
#define USE_OL2CL_CTRL             (1)



/* Select preparation method for start-up
* - PS_IPD_SAL     : IPD for salient motor
* - PS_IPD_NON_SAL : IPD for non-salient motor
* - PS_IPD_UNKNOWN : IPD without motor information
* - PS_DRAW_IN     : Draw-in
*/
#define  PS_IPD_SAL                (0)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  PS_IPD_NON_SAL            (1)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  PS_IPD_UNKNOWN            (2)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  PS_DRAW_IN                (3)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */

#define  PS_METHOD                 (PS_DRAW_IN)

/* Select carrier frequency for PWM
 * - CP_CARRIER_FREQ_20KHZ : 20kHz carrier frequency
 * - CP_CARRIER_FREQ_40KHZ : 40kHz carrier frequency
 * - CP_CARRIER_FREQ_16KHZ : 16kHz carrier frequency
 */
#define CP_CARRIER_FREQ_20KHZ      (0) /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define CP_CARRIER_FREQ_40KHZ      (1) /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define CP_CARRIER_FREQ_16KHZ      (2) /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */

#define CP_CARRIER_FREQ_SEL (CP_CARRIER_FREQ_20KHZ)

/* Select modulation method
* - MOD_3PH_SPWM : Sinusoidal Pulse-Width Modulation
* - MOD_3PH_TOW  : Third order wave addition
* - MOD_2PH_BOT : 2-phase modulation of Low arm 120-degree on
*/
#define  MOD_3PH_SPWM              (0)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  MOD_3PH_TOW               (1)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  MOD_2PH_BOT               (2)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */

#define  MOD_METHOD                (MOD_3PH_TOW)

/*
 * Hardware system configurations file include
 */

#include "r_mtr_motor_parameter.h"
#include "r_mtr_control_parameter.h"
#include "r_mtr_inverter_parameter.h"
#include "r_mtr_scaling_parameter.h"


#endif /* R_MTR_CONFIG_H */

