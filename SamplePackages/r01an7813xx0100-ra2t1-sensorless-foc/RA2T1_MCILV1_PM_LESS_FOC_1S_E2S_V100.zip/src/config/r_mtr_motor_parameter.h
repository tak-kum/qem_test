/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_motor_parameter.h
* Description : Definition of the target motor parameters
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_MOTOR_PARAMETER_H
#define R_MTR_MOTOR_PARAMETER_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Target motor parameter definitions */
/* Created date : 2025/05/14 */
#ifdef MP_R42BLD30L3_A_a1
#define     MP_POLE_PAIRS                   (4)                 /* Number of pole pairs */
#define     MP_RESISTANCE                   (1.299367f)         /* Resistance [ohm] */
#define     MP_D_INDUCTANCE                 (0.002058504f)      /* Resistance [ohm] */
#define     MP_Q_INDUCTANCE                 (0.002225475f)      /* Resistance [ohm] */
#define     MP_BEMF_CONSTANT                (0.01037395f)       /* Resistance [ohm] */
#define     MP_ROTOR_INERTIA                (0.000005687693f)   /* Resistance [ohm] */
#define     MP_FRICTION_0TH_ORDER           (0.003583013f)      /* Resistance [ohm] */
#define     MP_FRICTION_1ST_ORDER           (0.000001850949f)   /* Resistance [ohm] */
#define     MP_RATED_CURRENT                (1.67f)             /* Resistance [ohm] */
#define     MP_RATED_SPEED                  (4000)              /* Rated speed [rpm] */

/* Motor stator wire connection
* - STAR : Star connection
* - DELTA : Delta connection
*/
#define  STAR                      (0)
#define  DELTA                     (1)
#define     MP_MOTOR_WIRE_CONNECTION        (STAR)
#endif

#endif /* R_MTR_MOTOR_PARAMETER_H */

