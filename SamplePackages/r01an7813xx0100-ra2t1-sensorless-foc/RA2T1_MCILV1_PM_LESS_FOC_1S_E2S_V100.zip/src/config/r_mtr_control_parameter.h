/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_control_parameter.h
* Description : Definitions of default control parameters
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_CONTROL_PARAMETER_H
#define R_MTR_CONTROL_PARAMETER_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Terget control parameter definitions */
/* Target Motor name : R42BLD30L3_A_a1 */
/* Created date : 2025/05/14 */

#ifdef CP_R42BLD30L3_A_a1
#define CP_PWM_TIMER_FREQ               (32.0f)                  /* PWM timer frequency [MHz] */
#define CP_INTVAL_TIMER_FREQ            (32.0f)                  /* interval timer frequency [MHz] */
#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ)
#define CP_CARRIER_FREQ                 (16.0f)                  /* PWM carrier wave frequency [kHz] */
#elif (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#define CP_CARRIER_FREQ                 (20.0f)                  /* PWM carrier wave frequency [kHz] */
#elif (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_40KHZ)
#define CP_CARRIER_FREQ                 (40.0f)                  /* PWM carrier wave frequency [kHz] */
#endif
#define CP_TRX_TIMER_FREQ               (32.0f)                  /* TRX timer frequency [MHz] */
#if (CURRENT_SENS_METHOD == SINGLE_SHUNT)
#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#define CP_INT_DECIMATION               (1)                   /* interrupt skipping number */
#define CP_V_PHASE_LEAD_COEF            (1.00f)                  /* Voltage leading phase coefficient */
#elif (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_40KHZ)
#define CP_INT_DECIMATION               (3)                   /* interrupt skipping number */
#define CP_V_PHASE_LEAD_COEF            (0.75f)                  /* Voltage leading phase coefficient */
#endif
#elif (CURRENT_SENS_METHOD == THREE_SHUNT)
#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#define CP_INT_DECIMATION               (0)                   /* interrupt skipping number */
#define CP_V_PHASE_LEAD_COEF            (1.50f)                  /* Voltage leading phase coefficient */
#elif (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_40KHZ)
#define CP_INT_DECIMATION               (1)                   /* interrupt skipping number */
#define CP_V_PHASE_LEAD_COEF            (1.00f)                  /* Voltage leading phase coefficient */
#endif
#endif
#define CP_SPEED_CTRL_PERIOD            (0.001f)                 /* control period for speed loop [sec] */
#define CP_AD_CONVERSION_TIME           (1.1375f)                /* AD conversion time */
#define CP_AD_RINGING_WAIT_CNT          (32)                   /* Current ringing wait time at AD conversion */
#define CP_AD_RINGING_WAIT_2PH_CNT      (42)                   /* Current ringing wait time at AD conversion for 2-phase modulation */
#define CP_ACR_DEADBAND_LSB             (0.05000f)               /* Deadband of current PI calculation [LSB] */
#define CP_ASR_DEADBAND_LSB             (0.05000f)               /* Deadband of speed PI calculation [LSB] */
#define CP_PLL_DEADBAND_LSB             (0.05000f)               /* Deadband of phase locked loop calculation [LSB] */
#define CP_OFFSET_CALC_CNT              (512)                   /* Number of current offset averaging times */
#define CP_OFFSET_CALC_ST_WAIT_CNT      (100)                   /* Offset calculation stable waiting time */
#define CP_AD_POINT_A_ADJ_CNT           (32)                   /* A/D delay adjustment parameter for 1-shunt */
#define CP_AD_POINT_B_ADJ_CNT           (32)                   /* A/D delay adjustment parameter for 1-shunt */
#define CP_AD_POINT_A_ADJ_2PH_CNT       (42)                   /* A/D delay adjustment parameter for 1-shunt and 2-phase modulation */
#define CP_AD_POINT_B_ADJ_2PH_CNT       (42)                   /* A/D delay adjustment parameter for 1-shunt and 2-phase modulation */
#define CP_MOD_2PH_BOT_CHANGE_CNT       (200)                   /* 2-phase modulation phase switching judgment counter */

/* MOTOR DEPENDENT PARAMETER */
/* Please modify the following parameters when changing the motor. */
#define CP_ACR_NF_HZ                    (500.0f)                 /* Current PI natural frequency */
#define CP_ASR_NF_HZ                    (12.00000f)              /* Speed PI natural frequency */
#define CP_PLL_NF_HZ                    (60.00000f)              /* Phase locked loop natural frequency */
#define CP_ASR_LPF_COF_HZ               (150.00000f)             /* Cutoff frequency [Hz] of speed LPF */
#define CP_ACR_LPF_COF_HZ               (2000.00000f)            /* Cutoff frequency [Hz] of current LPF */
#define CP_I_REPRO_COF_HZ               (2000.00000f)            /* Cutoff frequency [Hz] of current reproduction LPF */
#define CP_ASR_KI_AUG                   (8.00000f)               /* Augmentation rate for integral part of ASR */
#define CP_MAX_SPEED_RPM                (4000)                   /* Max speed [rpm] */
#define CP_SPEED_LIMIT_RPM              (8000)                   /* Speed limit [rpm] */
#define CP_OC_LIMIT                     (3.34000f)               /* Limit for over current protection [A] */
#define CP_OL_REF_ID                    (1.67000f)               /* id reference when low speed [A] */
#define CP_DRAW_IN_WAIT_TIME            (0.20000f)               /* Draw-in wait time count value */
#define CP_INIT_ASR_INTEG               (0.05906f)               /* q-axis pi control initial integral parameter */
#define CP_RAMP_LIMIT_CURRENT           (0.0134880f)             /* Step of current change [A/ms] */
#define CP_MOD_3PH2PH_SPEED_RPM         (1600.0000000f)          /* Switching speed from 3-phase to 2-phase modulation [rpm] */
#define CP_MOD_2PH3PH_SPEED_RPM         (1400.0000000f)          /* Switching speed from 2-phase to 3-phase modulation [rpm] */
#define CP_OL2CL_SPEED_RPM              (800.0000000f)           /* Speed to start decreasing id [rpm] */
#define CP_CL2OL_SPEED_RPM              (600.0000000f)           /* Speed to start increasing id [rpm] */
#define CP_CL2OL_JUDGE_WAIT_TIME        (12.5000000f)            /* Wating time to judge down to open-loop [ms] */
#define CP_RAMP_LIMIT_SPEED_RPM         (5.1172170f)             /* Step of speed change [rpm/ms] */
#define CP_RAMP_SPEED_CNT_DECIMATION    (0)                   /* Decimation count for step of speed change */
#define CP_DAMP_HPF_COF_HZ              (5.0000000f)             /* HPF cutoff frequency for ed [Hz] */
#define CP_DAMP_ZETA                    (1.0000000f)             /* Damping ratio of open-loop damping control */
#define CP_DAMP_SPEED_LIMIT_RATE        (0.2000000f)             /* Speed limit rate */
#define CP_PHASE_ERR_LPF_COF_HZ         (10.0000000f)            /* Cut off frequency[Hz] of phase error LPF */
#define CP_OL2CL_SWITCH_TIME            (0.3073000f)             /* Time[s] to switch open-loop to sensor-less */
#define CP_OL2CL_SWITCH_ANGLE_MIN       (5.0000000f)             /* Minimum angle for switching to closed-loop [deg] */

#endif
#endif /* R_MTR_CONTROL_PARAMETER_H */
