/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_ctrl_gain.h
* Description : Definitions of Phase error estimator module
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

#ifndef RM_MTR_CTRL_GAIN_H
#define RM_MTR_CTRL_GAIN_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_foc_less_speed.h"
#include <stdint.h>

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/
/* Data structure for storing input control parameters */
typedef struct
{
    float    f4_dt;                      /* control period */
    float    f4_dt_speed;                /* control period for speed loop [sec] */
    float    f4_pu_sf_afreq;             /* frequency scale factor */
    float    f4_i_lim_vd;                /* current PI integral term limit for vd */
    float    f4_i_lim_vq;                /* current PI integral term limit for vq */
    float    f4_speed_lim_rad;           /* over speed limit [rad/s] */
    uint8_t  u1_q_current;               /* Q-format of current */
    uint8_t  u1_q_acr_kp;                /* Q-format of Q-axis current PI proportional gain */
    uint8_t  u1_q_acr_kidt;              /* Q-format of Q-axis current PI ki * dt */
    uint8_t  u1_q_acr_deadband;          /* Q-format of current PI deadband */
    uint8_t  u1_q_asr_kp;                /* Q-format of Speed current PI proportional gain */
    uint8_t  u1_q_asr_kidt;              /* Q-format of Speed current PI ki * dt */
    uint8_t  u1_q_asr_deadband;          /* Q-format of speed PI deadband */
    uint8_t  u1_q_pll_kp;                /* Q-format of D-axis current PI proportional gain */
    uint8_t  u1_q_pll_kidt;              /* Q-format of D-axis current PI ki * dt */
    uint8_t  u1_q_pll_deadband;          /* Q-format of speed estimator PI deadband */
    uint8_t  u1_q_acr_lpf_k;             /* Q-format of Current LPF numerator */
    uint8_t  u1_q_asr_lpf_k;             /* Q-format of Speed LPF numerator */
    uint8_t  u1_q_i_repro_lpf_k;         /* Q-format of LPF numerator for current reproduction */
    uint8_t  u1_q_do_lpf_k;              /* Q-format of disturbance suppressionLPF numerator */
    uint8_t  u1_q_do_hpf_k;              /* Q-format of disturbance suppression HPF numerator */
    uint8_t  u1_q_j_div_tc_p2m;          /* Q-format of inertia/time constant of LPF coefficient */
    uint8_t  u1_q_damp_k;                /* Q-format of damping control gain */
    uint8_t  u1_q_damp_hpf_k;            /* Q-format of damping control HPF numerator */
    uint8_t  u1_q_pherr_lpf_k;           /* Q-format of phase error LPF coefficient */
    uint8_t  u1_q_ol2cl_current_k1;      /* Q-format of angle error-dependent portion of reference current */
    uint8_t  u1_q_coef_mtpa_current;     /* Q-format of (ld-lq) / ke calculation */
    uint8_t  u1_q_fw_lpf_k;              /* Q-format of LPF numerator for Field-Weakening Control */
    uint8_t  u1_q_fw_kp;                 /* Q-format of D-axis FW PI proportional gain */
    uint8_t  u1_q_fw_kidt;               /* Q-format of D-axis FW PI ki * dt */
    uint8_t  u1_q_d1_div_p2m;            /* Q-format of 1st order fric-coef / (pole pairs * pole pairs * BEMF-const) */
    uint8_t  u1_q_pi_run_acr_err;        /* Q-format of ACR PI err */
    uint8_t  u1_q_pi_run_asr_err;        /* Q-format of ASR PI err */
    uint8_t  u1_q_pi_run_pll_err;        /* Q-format of PLL PI err */
    uint8_t  u1_q_afreq;                 /* Q-format of angular frequency */
} st_mtr_design_parameter_macro_t;

typedef struct
{
    float    f4_acr_nf_hz;               /* Current PI controller natural frequency [Hz] */
    float    f4_acr_lpf_cof_hz;          /* Current LPF cutoff frequency [Hz] */
    float    f4_acr_deadband_lsb;        /* Deadband of current PI calculation [LSB] */
    float    f4_asr_nf_hz;               /* Speed PI controller natural frequency [Hz] */
    float    f4_asr_lpf_cof_hz;          /* Speed LPF cutoff frequency [Hz] */
    float    f4_asr_deadband_lsb;        /* Deadband of speed PI calculation [LSB] */
    float    f4_asr_ki_aug;              /* Augmentation rate for integral part of ASR */
    float    f4_pll_nf_hz;               /* Speed estimator natural frequency [Hz] */
    float    f4_pll_deadband_lsb;        /* Deadband of speed estimator PI calculation [LSB] */
} st_mtr_design_parameter_com_t;

typedef struct
{
    st_mtr_design_parameter_macro_t
                st_macro;
    st_mtr_design_parameter_com_t
                st_com;
    float    f4_i_repro_cof_hz;          /* LPF cut-off frequency for current reproduction [Hz] */
    float    f4_r;                       /* Resistance [ohm] */
    float    f4_ld;                      /* d-axis inductance [H] */
    float    f4_lq;                      /* q-axis inductance [H] */
    float    f4_ke;                      /* Permanent magnetic Back-EMF constant [Vs/m] */
    float    f4_j;                       /* Rotor inertia [[kgm^2] */
    float    f4_ol_ref_id;               /* d-axis reference current for open-loop */
    float    f4_ol2cl_speed;             /* Speed of switching from open loop to sensorless [rpm] (mechanical) */
    float    f4_ramp_limit_speed;        /* Limit of acceleration [rpm/ms] (mechanical) */
    float    f4_do_lpf_cof_hz;           /* disturbance suppression LPF cutoff frequency [Hz] */
    float    f4_do_hpf_cof_hz;           /* disturbance suppression HPF cutoff frequency [Hz] */
    float    f4_d0_div_pm;               /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    float    f4_d1_div_p2m;              /* (1st order fric-coef) / (Pole pairs^2 * BEMF-const) [PU(A s/rad)] */
    float    f4_damp_hpf_cof_hz;         /* Damping control HPF cutoff frequency [Hz] */
    float    f4_damp_zeta;               /* Damping control damping factor */
    float    f4_pherr_lpf_cof_hz;        /* Cut off frequency[Hz] of phase error LPF */
    float    f4_ol2cl_switch_time;       /* Time[s] to switch open-loop to sensor-less */
    float    f4_fw_pi_nf_hz;             /* PI controller natural frequency for Field-Weakening Control [Hz] */
    float    f4_fw_speed_err_lpf_cof_hz; /* Speed error LPF cutoff frequency [Hz] */
    uint16_t u2_mtr_pp;                  /* Pole pairs */

} st_mtr_design_parameter_t;

/* Data structure for storing input gains calculated from control parameters */
typedef struct
{
    st_mtr_pi_t st_pi_acr_id;               /* D-axis current PI control gain */
    st_mtr_pi_t st_pi_acr_iq;               /* Q-axis current PI control gain */
    st_mtr_pi_t st_pi_asr;                  /* Speed current PI control gain */
    int32_t     s4_k_lpf_in_asr;            /* Speed LPF numerator */
    int32_t     s4_k_lpf_in_acr;            /* current LPF numerator */
    int32_t     s4_k_do_j_div_tc_p2m;       /* (Inertia) / (time contant of LPF * Pole pairs^2 * BEMF-const) [PU(A)] */
    int32_t     s4_k_lpf_in_do;             /* disturbance suppression LPF numerator */
    int32_t     s4_k_hpf_in_do;             /* disturbance suppression HPF numerator */
    int32_t     s4_coef_d0_div_pm;          /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    int32_t     s4_coef_d1_div_p2m;         /* (1st order fric-coef) / (Pole pairs^2 * BEMF-const) [PU(A s/rad)] */
    int32_t     s4_k_lpf_in_i_repro;        /* LPF numerator for current reproduction */
    st_mtr_pi_t st_pi_pll;                  /* Speed estimation PI control gain */
    int32_t     s4_k_damp;                  /* Open-loop damping control gain */
    int32_t     s4_k_hpf_in_damp;           /* Open-loop damping control HPF numerator */
    int32_t     s4_k0_ol2cl_theta2current;  /* Constant portion of reference current */
    int32_t     s4_k1_ol2cl_theta2current;  /* Angle error-dependent portion of reference current */
    int32_t     s4_k_lpf_in_pherr;          /* Phase error LPF numerator */
    int32_t     s4_coef_mtpa_current;       /* MTPA current coeficiency (ld - lq) / ke */
    int32_t     s4_kp_fw;                   /* FW PI proportional gain  */
    int32_t     s4_kidt_fw;                 /* FW PI ki * dt  */
    int32_t     s4_k_lpf_in_fw;             /* FW LPF numerator */
    int32_t     s4_lim_asr_err;             /* Speed PI control max error limit [PU(rad/s)] */
} st_mtr_ctrl_gain_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : RM_MTR_CtrlGain
* Description   : Calculate control gains(DO NOT call this function in interrupt)
* Arguments     : st_gain_buf - The pointer to the Control Gain parameters data structure
*               : st_ctrl_param - The pointer to the Control parameters data structure
* Return Value  : none
***********************************************************************************************************************/
void RM_MTR_CtrlGain (st_mtr_ctrl_gain_t * st_gain_buf, const st_mtr_design_parameter_t * st_ctrl_param);

#endif /* RM_MTR_CTRL_GAIN_H */
