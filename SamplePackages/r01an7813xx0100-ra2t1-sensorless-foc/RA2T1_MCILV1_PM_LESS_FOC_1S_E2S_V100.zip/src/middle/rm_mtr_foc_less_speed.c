/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_foc_less_speed.c
* Description : The processes of sensor-less FOC
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_common.h"
#include "rm_mtr_foc_less_speed.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "r_mtr_config.h"
#include "r_mtr_ra2t1.h"

#if (USE_OPENLOOP_DAMPING == MTR_SET)
#include "rm_mtr_ol2cl_ctrl.h"
#endif

#include "hal_data.h"
#include "r_mtr_common.h"

/***********************************************************************************************************************
* @fn             RM_MTR_FOCMotorDefaultInit
* @brief          Initializes motor drive modules with default configuration
* @param[in,out]  p_st_foc_common   The pointer to the structure for common data
* @return         None
***********************************************************************************************************************/
void RM_MTR_FOCMotorDefaultInit(st_mtr_common_foc_t *p_st_foc_common)
{
    st_mtr_foc_carrier_t * p_st_carrier;
    st_mtr_foc_speed_t   * p_st_speed;

    p_st_carrier = &p_st_foc_common->st_foc_carrier;
    p_st_speed   = &p_st_foc_common->st_foc_speed;

    /********************************************************/
    /* Initialize system state machines and state variables */
    p_st_foc_common->u1_state_ctrl = MTR_CTRL_NONE;
    p_st_carrier->u2_error_status  = MTR_ERROR_NONE;
    p_st_foc_common->s1_direction  = MTR_CW;

    /********************************************************/
    /* Initialize motor start-up sequence related variables */
    p_st_foc_common->u1_state_drive      = MTR_STOP;
    p_st_speed->u1_state_ref_id          = MTR_ID_ZERO_CONST;
    p_st_speed->u1_state_ref_iq          = MTR_IQ_ZERO_CONST;
    p_st_speed->u1_state_ref_speed       = MTR_SPEED_ZERO_CONST;
    p_st_carrier->u1_flg_offset_end      = MTR_CLR;
    p_st_speed->u2_cnt_draw_in_wait      = MTR_DRAW_IN_WAIT_CNT;
    p_st_speed->u2_cnt_draw_in_wait_buff = MTR_DRAW_IN_WAIT_CNT;
    p_st_speed->u2_cnt_draw_in_time_calc = 0;

    /***************************************/
    /* Initialize system protection limits */

    /**************************************/
    /* Initialize A/D converted variables */
    p_st_carrier->st_ad_i.ph_u   = 0;
    p_st_carrier->st_ad_i.ph_v   = 0;
    p_st_carrier->st_ad_i.ph_w   = 0;
    p_st_carrier->st_ad_i.ax_d   = 0;
    p_st_carrier->st_ad_i.ax_q   = 0;


    p_st_carrier->st_ad_i.st_angle.cos       = 1 << MTR_Q_SIN_COS_DSP;
    p_st_carrier->st_ad_i.st_angle.sin       = 0;
    p_st_carrier->st_ad_i.st_angle.angle_rad = 0;
    p_st_foc_common->s4_ad_vdc               = 0;

    p_st_carrier->st_ref_v.ph_u  = 0;
    p_st_carrier->st_ref_v.ph_v  = 0;
    p_st_carrier->st_ref_v.ph_w  = 0;
    p_st_carrier->st_ref_v.ax_d  = 0;
    p_st_carrier->st_ref_v.ax_q  = 0;

    p_st_carrier->st_ref_v.st_angle.cos       = 1 << MTR_Q_SIN_COS_DSP;
    p_st_carrier->st_ref_v.st_angle.sin       = 0;
    p_st_carrier->st_ref_v.st_angle.angle_rad = 0;

    p_st_carrier->st_ref_i.ax_d  = 0;
    p_st_carrier->st_ref_i.ax_q  = 0;

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    p_st_carrier->st_repro_i.ph_u = 0;
    p_st_carrier->st_repro_i.ph_v = 0;
    p_st_carrier->st_repro_i.ph_w = 0;
    p_st_carrier->st_repro_i.ax_d = 0;
    p_st_carrier->st_repro_i.ax_q = 0;

    p_st_carrier->st_repro_i.st_angle.cos       = 1 << MTR_Q_SIN_COS_DSP;
    p_st_carrier->st_repro_i.st_angle.sin       = 0;
    p_st_carrier->st_repro_i.st_angle.angle_rad = 0;
    p_st_carrier->st_repro_iq.s4_pre_out        = 0;
    p_st_carrier->st_repro_id.s4_pre_out        = 0;
#endif
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

    /**********************************************************/
    /* Initialize rotor position estimation related variables */
    p_st_carrier->st_phe.s4_est_ed       = 0;
    p_st_carrier->st_phe.s4_est_eq       = 0;
    p_st_carrier->st_phe.s4_est_e        = 0;
    p_st_foc_common->s4_phase_err_rad    = 0;
    p_st_carrier->st_phe.s4_coef_reci_ke = FIX_fromfloat(MTR_RECIM, MTR_Q_RECIM);

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    p_st_carrier->st_tscs.u4_offset_idc_adc    = 0;
    p_st_carrier->st_tscs.s4_offset_iu         = 0;
    p_st_carrier->st_tscs.s4_offset_iv         = 0;
    p_st_carrier->st_tscs.s4_offset_iw         = 0;
    p_st_carrier->st_tscs.u4_offset_calc_cnt   = CP_OFFSET_CALC_CNT;
    p_st_carrier->st_tscs.u4_offset_sample_cnt = 0;
    p_st_carrier->st_tscs.s2_duty_u            = 0;
    p_st_carrier->st_tscs.s2_duty_v            = 0;
    p_st_carrier->st_tscs.s2_duty_w            = 0;
    p_st_carrier->st_tscs.u2_ad_current_uph    = 0;
    p_st_carrier->st_tscs.u2_ad_current_vph    = 0;
    p_st_carrier->st_tscs.u2_ad_current_wph    = 0;
#endif

/* SINGLE_SHUNT == CURRENT_SENS_METHOD */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    p_st_carrier->st_sscs.u1_drv_pattern_get = MTR_DRV_UVW;
    p_st_carrier->st_sscs.u1_drv_pattern_set = MTR_DRV_UVW;
#if (0 == TRD_SKIPPING_COUNT)
    p_st_carrier->st_sscs.u1_drv_pattern_put = MTR_DRV_UVW;
#endif

    p_st_carrier->st_sscs.u1_flag_mod_2ph       = MTR_CLR;
    p_st_carrier->st_sscs.s2_duty_max           = 0;
    p_st_carrier->st_sscs.s2_duty_mid           = 0;
    p_st_carrier->st_sscs.s2_duty_min           = 0;
    p_st_carrier->st_sscs.s2_duty_u             = 0;
    p_st_carrier->st_sscs.s2_duty_v             = 0;
    p_st_carrier->st_sscs.s2_duty_w             = 0;
    p_st_carrier->st_sscs.s2_duty_max_adj       = 0;
    p_st_carrier->st_sscs.s2_duty_mid_adj       = 0;
    p_st_carrier->st_sscs.s2_duty_min_adj       = 0;
    p_st_carrier->st_sscs.s2_duty_max_adj_comp  = 0;
    p_st_carrier->st_sscs.s2_duty_mid_adj_comp  = 0;
    p_st_carrier->st_sscs.s2_duty_min_adj_comp  = 0;
    p_st_carrier->st_sscs.s2_duty_u_adj         = 0;
    p_st_carrier->st_sscs.s2_duty_v_adj         = 0;
    p_st_carrier->st_sscs.s2_duty_w_adj         = 0;
    p_st_carrier->st_sscs.s2_duty_u_adjc        = 0;
    p_st_carrier->st_sscs.s2_duty_v_adjc        = 0;
    p_st_carrier->st_sscs.s2_duty_w_adjc        = 0;
    p_st_carrier->st_sscs.s2_ad_point_a_cnt     = 0;
    p_st_carrier->st_sscs.s2_ad_point_b_cnt     = 0;

#if ((MOD_3PH_SPWM == MOD_METHOD) || (MOD_3PH_TOW == MOD_METHOD))
    p_st_carrier->st_sscs.s2_ad_point_a_adj_cnt     = CP_AD_POINT_A_ADJ_CNT;
    p_st_carrier->st_sscs.s2_ad_point_b_adj_cnt     = CP_AD_POINT_B_ADJ_CNT;
#elif (MOD_2PH_BOT == MOD_METHOD)
    p_st_carrier->st_sscs.s4_mod_3ph2ph_speed_rad
                                        = FIX_fromfloat(CP_MOD_3PH2PH_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    p_st_carrier->st_sscs.s4_mod_2ph3ph_speed_rad
                                        = FIX_fromfloat(CP_MOD_2PH3PH_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    p_st_carrier->st_sscs.s2_ad_point_a_adj_cnt     = CP_AD_POINT_A_ADJ_CNT;
    p_st_carrier->st_sscs.s2_ad_point_b_adj_cnt     = CP_AD_POINT_B_ADJ_CNT;
    p_st_carrier->st_sscs.s2_ad_point_a_adj_cnt_3ph = CP_AD_POINT_A_ADJ_CNT;
    p_st_carrier->st_sscs.s2_ad_point_b_adj_cnt_3ph = CP_AD_POINT_B_ADJ_CNT;
    p_st_carrier->st_sscs.s2_ad_point_a_adj_cnt_2ph = CP_AD_POINT_A_ADJ_2PH_CNT;
    p_st_carrier->st_sscs.s2_ad_point_b_adj_cnt_2ph = CP_AD_POINT_B_ADJ_2PH_CNT;
#endif

    p_st_carrier->st_sscs.s2_ad_ss_a           = 0;
    p_st_carrier->st_sscs.s2_ad_ss_b           = 0;
    p_st_carrier->st_sscs.s4_offset_ia         = 0;
    p_st_carrier->st_sscs.s4_offset_ib         = 0;
    p_st_carrier->st_sscs.u4_offset_calc_cnt   = CP_OFFSET_CALC_CNT;
    p_st_carrier->st_sscs.u4_offset_sample_cnt = 0;
    p_st_carrier->st_sscs.u2_crnt_ad_a         = 0;
    p_st_carrier->st_sscs.u2_crnt_ad_b         = 0;
#endif /* SINGLE_SHUNT == CURRENT_SENS_METHOD */

    /***********************************/
    /* Initialize current loop control */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    p_st_carrier->st_acr.u1_flg_err_zero         = MTR_CLR;
#endif
    p_st_carrier->st_acr.s4_ref_vd_pre           = 0;
    p_st_carrier->st_acr.s4_ref_vq_pre           = 0;
    p_st_carrier->st_acr.s4_ref_vd_buffer        = 0;
    p_st_carrier->st_acr.s4_ref_vq_buffer        = 0;
    p_st_carrier->st_acr.s4_ref_iq               = 0;
    p_st_carrier->st_acr.s4_ref_id_ol            = FIX_fromfloat(CP_OL_REF_ID * PU_SF_CURRENT, MTR_Q_CURRENT);
    p_st_carrier->st_acr.s4_lim_ramp_current     = FIX_fromfloat(CP_RAMP_LIMIT_CURRENT * PU_SF_CURRENT, MTR_Q_CURRENT);
#if  (USE_CURRENT_LPF_IQ == MTR_SET)
    p_st_carrier->st_acr.st_ad_iq_lpf.s4_pre_out = 0;
#endif
#if  (USE_CURRENT_LPF_ID == MTR_SET)
    p_st_carrier->st_acr.st_ad_id_lpf.s4_pre_out = 0;
#endif
    /* Initialize current PI controllers, gains will be calculated RM_MTR_CtrlGain */
    p_st_carrier->st_acr.st_pi_id.s4_kp       = 0;
    p_st_carrier->st_acr.st_pi_id.s4_kidt     = 0;
    p_st_carrier->st_acr.st_pi_id.s4_max_intg = FIX_fromfloat(MTR_I_LIMIT_VD * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
    p_st_carrier->st_acr.st_pi_id.s4_decimal  = 0;
    p_st_carrier->st_acr.st_pi_iq.s4_kp       = 0;
    p_st_carrier->st_acr.st_pi_iq.s4_kidt     = 0;
    p_st_carrier->st_acr.st_pi_iq.s4_max_intg = FIX_fromfloat(MTR_I_LIMIT_VQ * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
    p_st_carrier->st_acr.st_pi_id.s4_decimal  = 0;

    /*********************************/
    /* Initialize speed loop control */
    p_st_speed->st_asr.s1_ref_dir              = MTR_CW;
    p_st_speed->st_asr.s4_ref_speed            = 0;
    p_st_speed->st_asr.s4_ref_speed_ctrl       = 0;
    p_st_speed->st_asr.s4_speed                = 0;
    p_st_speed->st_asr.s4_lim_ramp_speed
                = FIX_fromfloat(CP_RAMP_LIMIT_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    p_st_speed->st_asr.s4_cnt_ramp_deci_sample = 0;
    p_st_speed->st_asr.s4_max_speed            = FIX_fromfloat(MTR_MAX_SPEED_RAD * PU_SF_AFREQ, MTR_Q_AFREQ);
    p_st_speed->st_asr.s4_init_intg            = FIX_fromfloat(CP_INIT_ASR_INTEG, MTR_Q_CURRENT);
    p_st_speed->st_asr.s4_th_cl2ol_speed       = FIX_fromfloat(MTR_CL2OL_SPEED_RAD * PU_SF_AFREQ, MTR_Q_AFREQ);
    p_st_speed->st_asr.s4_th_ol2cl_speed       = FIX_fromfloat(MTR_OL2CL_SPEED_RAD * PU_SF_AFREQ, MTR_Q_AFREQ);
    p_st_speed->st_asr.u2_cnt_cl2ol_judge_wait = 0;

    p_st_speed->st_asr.s4_coef_d0_div_pm
                = FIX_fromfloat(MP_FRICTION_0TH_ORDER / (MP_POLE_PAIRS * MP_BEMF_CONSTANT)
                                * PU_SF_CURRENT, MTR_Q_CURRENT);
    p_st_speed->st_asr.s4_coef_d1_div_p2m
                = FIX_fromfloat(MP_FRICTION_1ST_ORDER / (MP_POLE_PAIRS * MP_POLE_PAIRS * MP_BEMF_CONSTANT)
                                * PU_SF_D1_DIV_P2M, MTR_Q_D1_DIV_P2M);

    /* Initialize speed PI controller, gains will be calculated RM_MTR_CtrlGain */
    p_st_speed->st_asr.st_pi.s4_kp       = 0;
    p_st_speed->st_asr.st_pi.s4_kidt     = 0;
    p_st_speed->st_asr.st_pi.s4_max_intg = FIX_fromfloat(MTR_I_LIMIT_CURRENT * PU_SF_CURRENT, MTR_Q_CURRENT);
    p_st_speed->st_asr.st_pi.s4_decimal  = 0;
    p_st_speed->st_asr.s4_lim_asr_err    = 0;
#if (USE_SPEED_LPF == MTR_SET)
    p_st_speed->st_asr.st_lpf.s4_pre_out = 0;
#endif

    /*************************/
    /* Initialize modulation */
    p_st_carrier->st_mod.u1_flg_uvw_min_pattern     = MTR_PHASE_V;
    p_st_carrier->st_mod.u1_flg_uvw_min_pattern_pre = MTR_PHASE_U;
#if (MOD_2PH_BOT == MOD_METHOD)
    p_st_carrier->st_mod.s2_cnt_2ph_bot_change      = 0;
    p_st_carrier->st_mod.s4_v_diff_sum              = 0;
#endif
    p_st_carrier->st_mod.s4_mod_u                   = 0;
    p_st_carrier->st_mod.s4_mod_v                   = 0;
    p_st_carrier->st_mod.s4_mod_w                   = 0;
    p_st_carrier->st_mod.s4_ad_reci_vdc             = 0;
    p_st_carrier->st_mod.s4_lim_vout                = FIX_fromfloat(MTR_HALF_VDC * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

    /******************/
    /* Initialize pll */
    p_st_carrier->st_pll.st_pi.s4_kp       = 0;
    p_st_carrier->st_pll.st_pi.s4_kidt     = 0;
    p_st_carrier->st_pll.st_pi.s4_max_intg = FIX_fromfloat(MTR_SPEED_LIMIT_RAD * PU_SF_AFREQ, MTR_Q_AFREQ);
    p_st_carrier->st_pll.st_pi.s4_decimal  = 0;
    p_st_carrier->st_pll.s4_est_speed      = 0;


#if (USE_OPENLOOP_DAMPING == MTR_SET)
    /* Open-loop damping Control */
    p_st_speed->s4_damp_speed                               = 0;
    p_st_speed->st_asr.s4_ref_speed_damp_ctrl               = 0;
    p_st_speed->st_ol2cl.st_damp.s4_speed_lim_rate
                            = FIX_fromfloat(CP_DAMP_SPEED_LIMIT_RATE, MTR_Q_DAMP_SL_RATE);
    p_st_speed->st_ol2cl.st_damp.u1_q_damp_speed_calc       = (MTR_Q_VOLTAGE + MTR_Q_DAMP_K) - MTR_Q_AFREQ;
    p_st_speed->st_ol2cl.st_damp.u1_q_damp_speed_lim_calc   = (MTR_Q_AFREQ + MTR_Q_DAMP_SL_RATE) - MTR_Q_AFREQ;
    p_st_speed->st_ol2cl.st_damp.st_hpf.s4_pre_in           = 0;
    p_st_speed->st_ol2cl.st_damp.st_hpf.s4_pre_out          = 0;
    p_st_speed->st_ol2cl.st_damp.st_hpf.u1_q_k              = MTR_Q_DAMP_HPF_CO;
#endif

#if (USE_OL2CL_CTRL == MTR_SET)
    /* Open-loop to Closed-loop switch Control */
    p_st_speed->st_ol2cl.s4_lim_ramp_i
                                = (int32_t)((uint32_t)p_st_carrier->st_acr.s4_ref_id_ol / MTR_SWITCH_COUNT);
    p_st_speed->st_ol2cl.s4_iq_ol2cl            = 0;
    p_st_speed->st_ol2cl.s4_k0_angle2current    = 0;
    p_st_speed->st_ol2cl.s4_k1_angle2current    = 0;
    p_st_speed->st_ol2cl.s4_th_phase_err_rad_cl = 0;
    p_st_speed->st_ol2cl.u2_cnt_switch          = MTR_SWITCH_COUNT;
    p_st_speed->st_ol2cl.u1_q_k1_angle2current  = (MTR_Q_ANGLE + MTR_Q_OL2CL_K1) - MTR_Q_CURRENT;
    p_st_speed->st_ol2cl.u1_q_idelta_calc       = (MTR_Q_CURRENT + MTR_Q_SIN_COS_DSP) - MTR_Q_CURRENT;
    p_st_speed->st_ol2cl.st_ph_err.cos          = 1 << MTR_Q_SIN_COS_DSP;
    p_st_speed->st_ol2cl.st_ph_err.sin          = 0;
    p_st_speed->st_ol2cl.st_ph_err.angle_rad    = 0;
#endif

#if (USE_PWMOPA == MTR_SET)
    uint8_t ret;
    R_MTR_POEG_RecoverForcedShutdown(g_poeg0.p_ctrl, POEG_RECOVER_TIMEOUT, &ret);
#endif

} /* End of function RM_MTR_FOCMotorDefaultInit */

/***********************************************************************************************************************
* @fn             RM_MTR_FOCMotorReset
* @brief          Resets motor drive modules, configurations will not be reset
* @param[in,out]  p_st_foc_common   The pointer to the structure for common data
* @return         None
***********************************************************************************************************************/
void RM_MTR_FOCMotorReset(st_mtr_common_foc_t *p_st_foc_common)
{
    st_mtr_foc_carrier_t * p_st_carrier;
    st_mtr_foc_speed_t   * p_st_speed;

    p_st_carrier = &p_st_foc_common->st_foc_carrier;
    p_st_speed   = &p_st_foc_common->st_foc_speed;

    /***************************************************/
    /* Reset system state machines and state variables */
    p_st_foc_common->u1_state_ctrl = MTR_CTRL_NONE;

    /***************************************************/
    /* Reset motor start-up sequence related variables */
    p_st_foc_common->u1_state_drive      = MTR_STOP;
    p_st_speed->u1_state_ref_id          = MTR_ID_ZERO_CONST;
    p_st_speed->u1_state_ref_iq          = MTR_IQ_ZERO_CONST;
    p_st_speed->u1_state_ref_speed       = MTR_SPEED_ZERO_CONST;
    p_st_carrier->u1_flg_offset_end      = MTR_CLR;
    p_st_speed->u2_cnt_draw_in_wait      = p_st_speed->u2_cnt_draw_in_wait_buff;
    p_st_speed->u2_cnt_draw_in_time_calc = 0;

    /*********************************/
    /* Reset A/D converted variables */
    p_st_carrier->st_ad_i.ph_u   = 0;
    p_st_carrier->st_ad_i.ph_v   = 0;
    p_st_carrier->st_ad_i.ph_w   = 0;
    p_st_carrier->st_ad_i.ax_d   = 0;
    p_st_carrier->st_ad_i.ax_q   = 0;

    p_st_carrier->st_ad_i.st_angle.cos       = 1 << MTR_Q_SIN_COS_DSP;
    p_st_carrier->st_ad_i.st_angle.sin       = 0;
    p_st_carrier->st_ad_i.st_angle.angle_rad = 0;

    p_st_carrier->st_ref_v.ph_u  = 0;
    p_st_carrier->st_ref_v.ph_v  = 0;
    p_st_carrier->st_ref_v.ph_w  = 0;
    p_st_carrier->st_ref_v.ax_d  = 0;
    p_st_carrier->st_ref_v.ax_q  = 0;

    p_st_carrier->st_ref_v.st_angle.cos       = 1 << MTR_Q_SIN_COS_DSP;
    p_st_carrier->st_ref_v.st_angle.sin       = 0;
    p_st_carrier->st_ref_v.st_angle.angle_rad = 0;

    p_st_carrier->st_ref_i.ax_d  = 0;
    p_st_carrier->st_ref_i.ax_q  = 0;

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    p_st_carrier->st_repro_i.ph_u = 0;
    p_st_carrier->st_repro_i.ph_v = 0;
    p_st_carrier->st_repro_i.ph_w = 0;
    p_st_carrier->st_repro_i.ax_d = 0;
    p_st_carrier->st_repro_i.ax_q = 0;

    p_st_carrier->st_repro_i.st_angle.cos       = 1 << MTR_Q_SIN_COS_DSP;
    p_st_carrier->st_repro_i.st_angle.sin       = 0;
    p_st_carrier->st_repro_i.st_angle.angle_rad = 0;
    p_st_carrier->st_repro_iq.s4_pre_out        = 0;
    p_st_carrier->st_repro_id.s4_pre_out        = 0;
#endif
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

    /*****************************************************/
    /* Reset rotor position estimation related variables */
    p_st_carrier->st_phe.s4_est_ed    = 0;
    p_st_carrier->st_phe.s4_est_eq    = 0;
    p_st_carrier->st_phe.s4_est_e     = 0;
    p_st_foc_common->s4_phase_err_rad = 0;

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    p_st_carrier->st_tscs.s2_duty_u            = 0;
    p_st_carrier->st_tscs.s2_duty_v            = 0;
    p_st_carrier->st_tscs.s2_duty_w            = 0;
    p_st_carrier->st_tscs.u4_offset_sample_cnt = 0;
    p_st_carrier->st_tscs.u2_ad_current_uph    = 0;
    p_st_carrier->st_tscs.u2_ad_current_vph    = 0;
    p_st_carrier->st_tscs.u2_ad_current_wph    = 0;
#endif

/* SINGLE_SHUNT == CURRENT_SENS_METHOD */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    p_st_carrier->st_sscs.u1_drv_pattern_get = MTR_DRV_UVW;
    p_st_carrier->st_sscs.u1_drv_pattern_set = MTR_DRV_UVW;
#if (0 == TRD_SKIPPING_COUNT)
    p_st_carrier->st_sscs.u1_drv_pattern_put = MTR_DRV_UVW;
#endif

    p_st_carrier->st_sscs.u1_flag_mod_2ph    = MTR_CLR;

    p_st_carrier->st_sscs.s2_duty_max           = 0;
    p_st_carrier->st_sscs.s2_duty_mid           = 0;
    p_st_carrier->st_sscs.s2_duty_min           = 0;
    p_st_carrier->st_sscs.s2_duty_u             = 0;
    p_st_carrier->st_sscs.s2_duty_v             = 0;
    p_st_carrier->st_sscs.s2_duty_w             = 0;
    p_st_carrier->st_sscs.s2_duty_max_adj       = 0;
    p_st_carrier->st_sscs.s2_duty_mid_adj       = 0;
    p_st_carrier->st_sscs.s2_duty_min_adj       = 0;
    p_st_carrier->st_sscs.s2_duty_max_adj_comp  = 0;
    p_st_carrier->st_sscs.s2_duty_mid_adj_comp  = 0;
    p_st_carrier->st_sscs.s2_duty_min_adj_comp  = 0;
    p_st_carrier->st_sscs.s2_duty_u_adj         = 0;
    p_st_carrier->st_sscs.s2_duty_v_adj         = 0;
    p_st_carrier->st_sscs.s2_duty_w_adj         = 0;
    p_st_carrier->st_sscs.s2_duty_u_adjc        = 0;
    p_st_carrier->st_sscs.s2_duty_v_adjc        = 0;
    p_st_carrier->st_sscs.s2_duty_w_adjc        = 0;
    p_st_carrier->st_sscs.s2_ad_point_a_cnt     = 0;
    p_st_carrier->st_sscs.s2_ad_point_b_cnt     = 0;
#if (MOD_2PH_BOT == MOD_METHOD)
    p_st_carrier->st_sscs.s2_ad_point_a_adj_cnt = p_st_carrier->st_sscs.s2_ad_point_a_adj_cnt_3ph;
    p_st_carrier->st_sscs.s2_ad_point_b_adj_cnt = p_st_carrier->st_sscs.s2_ad_point_b_adj_cnt_3ph;
#endif
    p_st_carrier->st_sscs.u4_offset_sample_cnt  = 0;
    p_st_carrier->st_sscs.u2_crnt_ad_a          = 0;
    p_st_carrier->st_sscs.u2_crnt_ad_b          = 0;
#endif /* SINGLE_SHUNT == CURRENT_SENS_METHOD */

    /******************************/
    /* Reset current loop control */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    p_st_carrier->st_acr.u1_flg_err_zero      = MTR_CLR;
#endif
    p_st_carrier->st_acr.s4_ref_vd_pre        = 0;
    p_st_carrier->st_acr.s4_ref_vq_pre        = 0;
    p_st_carrier->st_acr.s4_ref_vd_buffer     = 0;
    p_st_carrier->st_acr.s4_ref_vq_buffer     = 0;
    p_st_carrier->st_acr.s4_ref_iq            = 0;
#if  (USE_CURRENT_LPF_IQ == MTR_SET)
    p_st_carrier->st_acr.st_ad_iq_lpf.s4_pre_out = 0;
#endif
#if  (USE_CURRENT_LPF_ID == MTR_SET)
    p_st_carrier->st_acr.st_ad_id_lpf.s4_pre_out = 0;
#endif
    p_st_carrier->st_acr.st_pi_id.s4_decimal  = 0;
    p_st_carrier->st_acr.st_pi_iq.s4_decimal  = 0;

    /****************************/
    /* Reset speed loop control */
    p_st_speed->st_asr.s4_ref_speed_ctrl       = 0;
    p_st_speed->st_asr.s4_speed                = 0;
    p_st_speed->st_asr.s4_cnt_ramp_deci_sample = 0;
    p_st_speed->st_asr.u2_cnt_cl2ol_judge_wait = 0;
    p_st_speed->st_asr.st_pi.s4_decimal        = 0;
#if (USE_SPEED_LPF == MTR_SET)
    p_st_speed->st_asr.st_lpf.s4_pre_out       = 0;
#endif
    /****************************/

    /********************/
    /* Reset modulation */
    p_st_carrier->st_mod.u1_flg_uvw_min_pattern     = MTR_PHASE_V;
    p_st_carrier->st_mod.u1_flg_uvw_min_pattern_pre = MTR_PHASE_U;
#if (MOD_2PH_BOT == MOD_METHOD)
    p_st_carrier->st_mod.s2_cnt_2ph_bot_change = 0;
    p_st_carrier->st_mod.s4_v_diff_sum         = 0;
#endif
    p_st_carrier->st_mod.s4_mod_u       = 0;
    p_st_carrier->st_mod.s4_mod_v       = 0;
    p_st_carrier->st_mod.s4_mod_w       = 0;
    p_st_carrier->st_mod.s4_ad_reci_vdc = 0;
#if (USE_DEADTIME_COMP == MTR_SET)
#endif
    /********************/

    /*************/
    /* Reset pll */
    p_st_carrier->st_pll.st_pi.s4_decimal = 0;
    p_st_carrier->st_pll.s4_est_speed     = 0;



#if (USE_OPENLOOP_DAMPING == MTR_SET)
    /* Open-loop damping Control */
    p_st_speed->s4_damp_speed                        = 0;
    p_st_speed->st_asr.s4_ref_speed_damp_ctrl        = 0;
    p_st_speed->st_ol2cl.st_damp.st_hpf.s4_pre_in    = 0;
    p_st_speed->st_ol2cl.st_damp.st_hpf.s4_pre_out   = 0;
#endif

#if (USE_OL2CL_CTRL == MTR_SET)
    /* Open-loop to Closed-loop switch Control */
    p_st_carrier->st_acr.s4_lim_ramp_current      = p_st_speed->st_ol2cl.s4_lim_ramp_i;
    p_st_speed->st_ol2cl.s4_th_phase_err_rad_cl   = 0;
    p_st_speed->st_ol2cl.st_ph_err.cos            = 1 << MTR_Q_SIN_COS_DSP;
    p_st_speed->st_ol2cl.st_ph_err.sin            = 0;
    p_st_speed->st_ol2cl.st_ph_err.angle_rad      = 0;
#endif
} /* End of function RM_MTR_FOCMotorReset */
