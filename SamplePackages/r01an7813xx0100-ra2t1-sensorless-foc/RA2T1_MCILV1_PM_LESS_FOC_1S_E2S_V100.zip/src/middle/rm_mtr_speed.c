/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_speed.c
* Description : The carrier interrupt handler of FOC
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_common.h"
#include "rm_mtr_driver.h"
#include "rm_mtr_foc_less_speed.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "r_mtr_config.h"
#include "r_mtr_ra2t1.h"
#include "r_mtr_ics.h"

#if (USE_OL2CL_CTRL == MTR_SET)
#include "rm_mtr_ol2cl_ctrl.h"
#endif

#include "hal_data.h"
#include "r_mtr_common.h"

/***********************************************************************************************************************
* Private variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/**********************************************************************************************************************
* global variables
***********************************************************************************************************************/
extern st_mtr_common_foc_t g_st_foc_common;

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/

#if (USE_OL2CL_CTRL == MTR_SET)
static int32_t mtr_lpf1_run (st_mtr_lpf1_t * p_st_lpf, int32_t s2_input, const uint8_t u1_q);
#endif
static int32_t mtr_ref_speed_get(st_mtr_foc_speed_t *p_st_speed);
static inline int32_t mtr_pi_run_asr (st_mtr_pi_t * p_st_pi, int32_t s4_err, const uint8_t u1_kp_q,
                                const uint8_t u1_q_err_shift, const uint8_t u1_q_kidt_shift,
                                const uint8_t u1_q_intg_shift);
static uint8_t mtr_speed_drive_ctrl (st_mtr_common_foc_t * p_st_foc_common);
static uint8_t mtr_speed_process_opl_ctrl (st_mtr_common_foc_t * p_st_foc_common,
                                        uint8_t u1_state_ctrl,
                                        int32_t s4_ref_temp_idq_ctrl[2],
                                        int32_t *p_s4_ref_temp_speed_ctrl);
static uint8_t mtr_speed_process_cll_ctrl (st_mtr_common_foc_t * p_st_foc_common,
                                        uint8_t u1_state_ctrl,
                                        int32_t s4_ref_temp_idq_ctrl[2],
                                        int32_t * p_s4_ref_temp_speed_ctrl);
static uint8_t mtr_speed_state_ctrl_get (void);
static int32_t mtr_ref_iq_get (st_mtr_foc_speed_t * p_st_speed, st_mtr_foc_carrier_t * p_st_carrier);
static int32_t mtr_ref_id_get (st_mtr_foc_speed_t * p_st_speed, st_mtr_foc_carrier_t * p_st_carrier);
static void    mtr_offset_calc_init ();
static uint8_t mtr_offset_calc_status_get ();
static void    mtr_error_check (st_mtr_foc_carrier_t * p_st_foc);
static int32_t mtr_abs (int32_t s4_value);
static int32_t mtr_limit_abs (int32_t s4_value, int32_t s4_limit_value);

/***********************************************************************************************************************
* @fn             mtr_speed_cyclic
* @brief          Cyclic process for motor speed control
* @param[in]      p_args   Pointer to timer callback arguments
* @return         None
***********************************************************************************************************************/
void mtr_speed_cyclic(timer_callback_args_t * p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);

    uint8_t u1_temp_stm_status;
    uint8_t u1_temp_state_drive;

    __enable_irq();  /* Enable interrupt */

    /* Get status information */
    u1_temp_stm_status  = mtr_statemachine_get_status(&g_st_foc_common.st_foc_carrier.st_stm);
    u1_temp_state_drive = g_st_foc_common.u1_state_drive;

    /* Update state based on state machine status */
    if ((MTR_MODE_STOP == u1_temp_stm_status) && (MTR_MASK_RUN_MODE & g_st_foc_common.u1_state_drive))
    {
        u1_temp_state_drive = MTR_DRIVE_END;
    }
    else if ((MTR_MODE_DRIVE == u1_temp_stm_status)
            && (!(MTR_MASK_RUN_MODE & g_st_foc_common.u1_state_drive)))
    {
        u1_temp_state_drive = MTR_DRIVE_INIT;
    }
    else
    {
        __NOP();  /* Do nothing */
    }

#if (USE_OL2CL_CTRL == MTR_SET)
    /* Open-loop to closed-loop transition calculations */
    if ((MTR_IQ_ZERO_CONST == g_st_foc_common.st_foc_speed.u1_state_ref_iq) ||
        (MTR_IQ_OL2CL == g_st_foc_common.st_foc_speed.u1_state_ref_iq))
    {
        int32_t s4_phase_err_lpf_rad;
        /* Calculate phase error LPF */
        s4_phase_err_lpf_rad = mtr_lpf1_run(&g_st_foc_common.st_foc_speed.st_phase_err_lpf,
                                                    g_st_foc_common.s4_phase_err_rad,
                                                    MTR_Q_PHERR_LPF_CO);

        /* Set the angle for switching from open-loop to sensor-less process */
        g_st_foc_common.st_foc_speed.st_ol2cl.st_ph_err.angle_rad = s4_phase_err_lpf_rad;
        R_motor_sincos_FIX28(&g_st_foc_common.st_foc_speed.st_ol2cl.st_ph_err);
    }
#endif

    /* State machine for motor drive control */
    switch (u1_temp_state_drive)
    {
        case MTR_DRIVE:
            /* Normal drive control */
            g_st_foc_common.u1_state_ctrl = mtr_speed_drive_ctrl(&g_st_foc_common);
            break;

        case MTR_DRIVE_INIT:
            /* Avoiding unintended duty output */
            /* Initialize offset calculation */
            mtr_offset_calc_init();
            u1_temp_state_drive = MTR_DRIVE_START;
            break;

        case MTR_DRIVE_START:
            /* Enable PWM output */
            R_MTR_GPT_THREE_PHASE_EnableOutputAll(g_three_phase0.p_ctrl);
            u1_temp_state_drive = MTR_OFFSET_CALC_EXE;
            break;

        case MTR_OFFSET_CALC_EXE:
            /* Check if offset calculation is completed */
            if (MTR_SET == mtr_offset_calc_status_get())
            {
                /* Initialize drive parameters */
                g_st_foc_common.st_foc_speed.u1_state_ref_speed = MTR_SPEED_ZERO_CONST;
                g_st_foc_common.st_foc_speed.u1_state_ref_iq    = MTR_IQ_ZERO_CONST;
                g_st_foc_common.st_foc_speed.u1_state_ref_id    = MTR_ID_MANUAL;
                g_st_foc_common.st_foc_carrier.st_acr.s4_ref_id
                    = g_st_foc_common.st_foc_carrier.st_acr.s4_ref_id_ol;

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if (MOD_2PH_BOT == MOD_METHOD)
                /* Configure single shunt settings */
                g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt
                    = g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt_3ph;
                g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt
                    = g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt_3ph;
#endif
#endif
                g_st_foc_common.u1_state_ctrl = MTR_CTRL_OPL_DRAWIN;
                u1_temp_state_drive           = MTR_DRIVE;
            }
            break;

        case MTR_DRIVE_END:
            /* Disable PWM output */
            R_MTR_GPT_THREE_PHASE_DisableOutputAll(g_three_phase0.p_ctrl);
            u1_temp_state_drive = MTR_STOP;
            break;

        default:
            break;
    }

    /* Update drive state */
    g_st_foc_common.u1_state_drive = u1_temp_state_drive;

    /* Update commands and configurations when trigger flag is set */
    RM_MTR_UpdatePollingSet();

    /*============================*/
    /* Error check               */
    /*============================*/
    mtr_error_check(&g_st_foc_common.st_foc_carrier);

} /* End of function mtr_speed_cyclic */


#if (USE_OL2CL_CTRL == MTR_SET)
/***********************************************************************************************************************
* @fn             mtr_lpf1_run
* @brief          Calculate output of 1st order IIR LPF
* @param[in,out]  st_lpf     The pointer to the IIR LPF structure
* @param[in]      s4_input   Input
* @param[in]      u1_q       Q parameter for LPF
* @return         Current output value
***********************************************************************************************************************/
static int32_t mtr_lpf1_run(st_mtr_lpf1_t *p_st_lpf, int32_t s4_input, const uint8_t u1_q)
{
    int32_t s4_temp;

    /* out(n) = in_k * input(n) + out_k * output(n-1) */
    s4_temp  = FIX_mul_rs(s4_input, p_st_lpf->s4_in_k, u1_q);
    s4_temp += FIX_mul_rs(p_st_lpf->s4_pre_out, p_st_lpf->s4_out_k, u1_q);

    p_st_lpf->s4_pre_out = s4_temp;

    return (s4_temp);
} /* End of function mtr_lpf1_run */
#endif

/***********************************************************************************************************************
* @fn             mtr_ref_speed_get
* @brief          Get speed reference
* @param[in]      p_st_speed  The pointer to the FOC speed control data structure
* @return         Speed reference
***********************************************************************************************************************/
static int32_t mtr_ref_speed_get(st_mtr_foc_speed_t *p_st_speed)
{
    int32_t s4_temp_err           = 0;
    int32_t s4_speed_rad_ref_buff = 0;

    switch (p_st_speed->u1_state_ref_speed)
    {
        case MTR_SPEED_ZERO_CONST:
            s4_speed_rad_ref_buff = 0;
            break;

        case MTR_SPEED_MANUAL:
            p_st_speed->st_asr.s4_cnt_ramp_deci_sample++;
            if (CP_RAMP_SPEED_CNT_DECIMATION < p_st_speed->st_asr.s4_cnt_ramp_deci_sample)
            {
                p_st_speed->st_asr.s4_cnt_ramp_deci_sample = 0;

                /* error */
                s4_temp_err = p_st_speed->st_asr.s4_ref_speed
                            - p_st_speed->st_asr.s4_ref_speed_ctrl;

                /* limit error */
                s4_temp_err = mtr_limit_abs(s4_temp_err, p_st_speed->st_asr.s4_lim_ramp_speed);

                /* Add error to control reference */
                s4_speed_rad_ref_buff = p_st_speed->st_asr.s4_ref_speed_ctrl + s4_temp_err;
            }
            else
            {
                s4_speed_rad_ref_buff = p_st_speed->st_asr.s4_ref_speed_ctrl;
            }
            break;

        default:
            break;
    }

    /* limit speed reference */
    s4_speed_rad_ref_buff = mtr_limit_abs(s4_speed_rad_ref_buff, g_st_foc_common.st_foc_speed.st_asr.s4_max_speed);

    /* return speed reference */
    return (s4_speed_rad_ref_buff);
} /* End of function mtr_ref_speed_get */

/***********************************************************************************************************************
* @fn             mtr_pi_run_asr
* @brief          Speed PI control
* @param[in,out]  p_st_pi          The pointer to PI controller parameter structure
* @param[in]      s4_err           Error number
* @param[in]      u1_kp_q          Q-format of PI proportional gain
* @param[in]      u1_q_err_shift   Shift count of error number
* @param[in]      u1_q_kidt_shift  Q-format of PI Integral gain
* @param[in]      u1_q_intg_shift  Shift count of decimal part
* @return         PI output
***********************************************************************************************************************/
static inline int32_t mtr_pi_run_asr(st_mtr_pi_t *p_st_pi, int32_t s4_err,
                                        const uint8_t u1_kp_q, const uint8_t u1_q_err_shift,
                                        const uint8_t u1_q_kidt_shift, const uint8_t u1_q_intg_shift)
{
    int32_t s4_pi_out;

    p_st_pi->s4_decimal += (s4_err >> u1_q_err_shift);

    /* Integral part saturation (symmetric) limiter */
    p_st_pi->s4_decimal = mtr_limit_abs(p_st_pi->s4_decimal, p_st_pi->s4_max_intg);

    int32_t s4_intg;
    s4_intg = (p_st_pi->s4_kidt >> u1_q_kidt_shift)
            * (p_st_pi->s4_decimal >> u1_q_intg_shift);

    int32_t s4_err_lim = mtr_limit_abs(s4_err, g_st_foc_common.st_foc_speed.st_asr.s4_lim_asr_err);

    s4_pi_out = s4_intg + FIX_mul_rs_sign(p_st_pi->s4_kp, s4_err_lim, u1_kp_q);
    return (s4_pi_out);
} /* End of function mtr_pi_run_asr */

/***********************************************************************************************************************
* @fn             mtr_speed_drive_ctrl
* @brief          Motor speed drive control function. Controls motor operation in open-loop and closed-loop modes
* @param[in,out]  p_st_foc_common   The pointer to FOC common structure
* @return         Current control state
***********************************************************************************************************************/
static uint8_t mtr_speed_drive_ctrl(st_mtr_common_foc_t *p_st_foc_common)
{
    /* Get current control state */
    uint8_t u1_state_ctrl = mtr_speed_state_ctrl_get();

    /* Get reference values */
    int32_t s4_ref_temp_speed_ctrl  = mtr_ref_speed_get(&p_st_foc_common->st_foc_speed);
    int32_t s4_ref_temp_idq_ctrl[2] = {0, 0};
    s4_ref_temp_idq_ctrl[MTR_ID] = mtr_ref_id_get(&p_st_foc_common->st_foc_speed,
                                                  &p_st_foc_common->st_foc_carrier);
    s4_ref_temp_idq_ctrl[MTR_IQ] = mtr_ref_iq_get(&p_st_foc_common->st_foc_speed,
                                                  &p_st_foc_common->st_foc_carrier);

    /* Open-Loop Control */
    if (MTR_DRIVE_OPL == (u1_state_ctrl & 0x80))
    {
        u1_state_ctrl = mtr_speed_process_opl_ctrl(p_st_foc_common, u1_state_ctrl,
                                                    s4_ref_temp_idq_ctrl, &s4_ref_temp_speed_ctrl);
    }
    /* Closed-Loop Control */
    else if (MTR_DRIVE_CLL == (u1_state_ctrl & 0x80))
    {
        u1_state_ctrl = mtr_speed_process_cll_ctrl(p_st_foc_common, u1_state_ctrl,
                                                    s4_ref_temp_idq_ctrl, &s4_ref_temp_speed_ctrl);
    }

    /* Update reference values */
    p_st_foc_common->st_foc_speed.st_asr.s4_ref_speed_ctrl = s4_ref_temp_speed_ctrl;
    p_st_foc_common->st_foc_carrier.st_ref_i.ax_d          = s4_ref_temp_idq_ctrl[MTR_ID];
    p_st_foc_common->st_foc_carrier.st_ref_i.ax_q          = s4_ref_temp_idq_ctrl[MTR_IQ];

    return u1_state_ctrl;
} /* End of function mtr_speed_drive_ctrl */

/***********************************************************************************************************************
* @fn             mtr_speed_process_opl_ctrl
* @brief          Motor speed control processing function for open-loop control modes
* @param[in,out]  p_st_foc_common               The pointer to FOC common structure
* @param[in]      u1_state_ctrl                 Current control state of the open-loop process
* @param[in,out]  s4_ref_temp_idq_ctrl          Reference values for Id and Iq current components [2]
* @param[in,out]  p_s4_ref_temp_speed_ctrl      Pointer to the reference speed control value
* @return         Updated control state
* @retval         MTR_CTRL_OPL_FORCE_SYNC       Force synchronization state
* @retval         MTR_CTRL_OPL_FORCE_SYNC_ACCEL Force synchronization and acceleration state
* @retval         MTR_CTRL_OPL_OPL2CLL          Transition state from open-loop to closed-loop
* @retval         MTR_CTRL_CLL_SPEED_CTRL       Closed-loop speed control state
***********************************************************************************************************************/
static uint8_t mtr_speed_process_opl_ctrl(st_mtr_common_foc_t *p_st_foc_common,
                                        uint8_t u1_state_ctrl,
                                        int32_t s4_ref_temp_idq_ctrl[2],
                                        int32_t *p_s4_ref_temp_speed_ctrl)
{
    int32_t  s4_temp0 = 0;
    int32_t  s4_temp1 = 0;

    /* Process based on current state */
    switch (u1_state_ctrl)
    {
        case MTR_CTRL_OPL_DRAWIN:
            /* Draw-in process */
            if (s4_ref_temp_idq_ctrl[MTR_ID] >= p_st_foc_common->st_foc_carrier.st_acr.s4_ref_id)
            {
                p_st_foc_common->st_foc_speed.u2_cnt_draw_in_time_calc++;

                if (p_st_foc_common->st_foc_speed.u2_cnt_draw_in_wait <=
                    p_st_foc_common->st_foc_speed.u2_cnt_draw_in_time_calc)
                {
                    s4_ref_temp_idq_ctrl[MTR_ID]                           = 0;
                    p_st_foc_common->st_foc_speed.u2_cnt_draw_in_time_calc = 0;

                    /* Set angle based on rotation direction */
                    if (MTR_CW == p_st_foc_common->st_foc_speed.st_asr.s1_ref_dir)
                    {
                        /* theta = 90 degrees */
                        p_st_foc_common->st_foc_carrier.st_ad_i.st_angle.angle_rad = MTR_ANGLE_QUAT_RANGE;
                    }
                    else
                    {
                        /* theta = -90 degrees */
                        p_st_foc_common->st_foc_carrier.st_ad_i.st_angle.angle_rad = -MTR_ANGLE_QUAT_RANGE;
                    }

                    u1_state_ctrl = MTR_CTRL_OPL_FORCE_SYNC;
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
                    p_st_foc_common->st_foc_carrier.st_repro_id.s4_pre_out = 0;
                    p_st_foc_common->st_foc_carrier.st_repro_iq.s4_pre_out = 0;
#endif
                }
            }
            break;

        case MTR_CTRL_OPL_FORCE_SYNC:
            /* Force synchronization */
            if (s4_ref_temp_idq_ctrl[MTR_ID] >= p_st_foc_common->st_foc_carrier.st_acr.s4_ref_id)
            {
                p_st_foc_common->st_foc_speed.u2_cnt_draw_in_time_calc++;

                if (p_st_foc_common->st_foc_speed.u2_cnt_draw_in_wait <=
                    p_st_foc_common->st_foc_speed.u2_cnt_draw_in_time_calc)
                {
                    p_st_foc_common->st_foc_speed.u1_state_ref_speed = MTR_SPEED_MANUAL;
                    u1_state_ctrl                                      = MTR_CTRL_OPL_FORCE_SYNC_ACCEL;
                }
            }
            break;

        case MTR_CTRL_OPL_CLL2OPL:
            /* Transition from closed-loop to open-loop */
            if (s4_ref_temp_idq_ctrl[MTR_ID] >= p_st_foc_common->st_foc_carrier.st_acr.s4_ref_id)
            {
                u1_state_ctrl = MTR_CTRL_OPL_FORCE_SYNC_ACCEL;
            }
            break;

        case MTR_CTRL_OPL_FORCE_SYNC_ACCEL:
            s4_temp0 = mtr_abs(p_st_foc_common->st_foc_speed.st_asr.s4_speed);

            /* Force sync and acceleration - OL to CL transition determination */
            if (s4_temp0 >= p_st_foc_common->st_foc_speed.st_asr.s4_th_ol2cl_speed)
            {
                /* Reset ID reference */
                p_st_foc_common->st_foc_carrier.st_acr.s4_ref_id = 0;

#if (MOD_2PH_BOT == MOD_METHOD)
                p_st_foc_common->st_foc_carrier.st_mod.s2_cnt_2ph_bot_change = CP_MOD_2PH_BOT_CHANGE_CNT;
#endif

#if (USE_OL2CL_CTRL == MTR_SET)
                /* Set current change limit */
                p_st_foc_common->st_foc_carrier.st_acr.s4_lim_ramp_current
                    = p_st_foc_common->st_foc_speed.st_ol2cl.s4_lim_ramp_i;

                /* Calculate IQ */
                RM_MTR_OplOL2CLIqCalc(&p_st_foc_common->st_foc_speed.st_ol2cl,
                                        s4_ref_temp_idq_ctrl[MTR_ID],
                                        p_st_foc_common->st_foc_speed.st_asr.s1_ref_dir);
                p_st_foc_common->st_foc_speed.u1_state_ref_iq = MTR_IQ_OL2CL;
                u1_state_ctrl                                   = MTR_CTRL_OPL_OPL2CLL;
#else
                /* Preparation for PLL */
                {
                    int32_t s4_temp_speed     = p_st_foc_common->st_foc_speed.st_asr.s4_speed;
                    int32_t s4_kidt           = p_st_foc_common->st_foc_carrier.st_pll.st_pi.s4_kidt;
                    int32_t s4_speed_div_kidt = s4_temp_speed
                            / (s4_kidt >> (MTR_Q_PLL_KIDT - (MTR_Q_AFREQ - MTR_Q_PI_RUN_ACR_INTG)));
                    p_st_foc_common->st_foc_carrier.st_pll.st_pi.s4_decimal
                            = s4_speed_div_kidt << (MTR_Q_PI_RUN_PLL_ERR - MTR_Q_PI_RUN_ACR_INTG);
                }
                p_st_foc_common->st_foc_speed.u1_state_ref_iq   = MTR_IQ_SPEED_PI_OUTPUT;
                u1_state_ctrl                                   = MTR_CTRL_CLL_OPL2CLL;
#endif
            }
            s4_temp1 = mtr_abs(*p_s4_ref_temp_speed_ctrl);

            /* Step-out process */
            if ((s4_temp1 > g_st_foc_common.st_foc_speed.st_asr.s4_th_ol2cl_speed) &&
                (s4_temp0 < g_st_foc_common.st_foc_speed.st_asr.s4_th_cl2ol_speed))
            {
                *p_s4_ref_temp_speed_ctrl = 0;
            }
            break;

#if (USE_OL2CL_CTRL == MTR_SET)
        case MTR_CTRL_OPL_OPL2CLL:
            if ((mtr_abs(p_st_foc_common->s4_phase_err_rad)
                    <= p_st_foc_common->st_foc_speed.st_ol2cl.s4_th_phase_err_rad_cl)
                    || (s4_ref_temp_idq_ctrl[MTR_ID] == 0))
            {
                /* Preparation for PLL */
                {
                    int32_t s4_temp_speed     = p_st_foc_common->st_foc_speed.st_asr.s4_speed;
                    int32_t s4_kidt           = p_st_foc_common->st_foc_carrier.st_pll.st_pi.s4_kidt;
                    int32_t s4_speed_div_kidt = s4_temp_speed /
                                    (s4_kidt >> (MTR_Q_PLL_KIDT - (MTR_Q_AFREQ - MTR_Q_PI_RUN_ACR_INTG)));
                    p_st_foc_common->st_foc_carrier.st_pll.st_pi.s4_decimal
                            = s4_speed_div_kidt << (MTR_Q_PI_RUN_PLL_ERR - MTR_Q_PI_RUN_ACR_INTG);
                }

                /* Prepare ASR for transition */
                {
                    int32_t s4_temp_current     = p_st_foc_common->st_foc_speed.st_ol2cl.s4_iq_ol2cl;
                    int32_t s4_kidt             = p_st_foc_common->st_foc_speed.st_asr.st_pi.s4_kidt;
                    int32_t s4_current_div_kidt = s4_temp_current /
                                    (s4_kidt >> (MTR_Q_ASR_KIDT - (MTR_Q_CURRENT - MTR_Q_PI_RUN_ASR_INTG)));
                    p_st_foc_common->st_foc_speed.st_asr.st_pi.s4_decimal
                            = s4_current_div_kidt << (MTR_Q_PI_RUN_ASR_ERR - MTR_Q_PI_RUN_ASR_INTG);
                }

                /* Update status */
                p_st_foc_common->st_foc_speed.u1_state_ref_iq   = MTR_IQ_SPEED_PI_OUTPUT;
                u1_state_ctrl                                   = MTR_CTRL_CLL_SPEED_CTRL;
            }
            break;
#endif /* (USE_OL2CL_CTRL == MTR_SET) */

        default:
            break;
    }


#if (USE_OPENLOOP_DAMPING == MTR_SET)
    /* Apply open-loop damping control */
    p_st_foc_common->st_foc_speed.s4_damp_speed
        = RM_MTR_OpenloopDampCtrl(&p_st_foc_common->st_foc_speed.st_ol2cl.st_damp,
                                p_st_foc_common->st_foc_carrier.st_phe.s4_est_ed,
                                *p_s4_ref_temp_speed_ctrl);

    p_st_foc_common->st_foc_speed.st_asr.s4_ref_speed_damp_ctrl
        = (*p_s4_ref_temp_speed_ctrl) - p_st_foc_common->st_foc_speed.s4_damp_speed;
#endif

    return u1_state_ctrl;
} /* End of function mtr_speed_process_opl_ctrl */

/***********************************************************************************************************************
* @fn             mtr_speed_process_cll_ctrl
* @brief          Motor speed control processing function for closed-loop control modes
* @param[in,out]  p_st_foc_common           The pointer to FOC common structure
* @param[in,out]  u1_state_ctrl             Current control state
* @param[in]      s4_ref_temp_idq_ctrl      Reference values for Id and Iq current components [2]
* @param[in,out]  p_s4_ref_temp_speed_ctrl  Speed reference value
* @return         Updated control state
***********************************************************************************************************************/
static uint8_t mtr_speed_process_cll_ctrl(st_mtr_common_foc_t *p_st_foc_common,
                                            uint8_t u1_state_ctrl,
                                            int32_t s4_ref_temp_idq_ctrl[2],
                                            int32_t *p_s4_ref_temp_speed_ctrl)
{
#if (USE_OL2CL_CTRL != MTR_CLR)
    FSP_PARAMETER_NOT_USED(s4_ref_temp_idq_ctrl);
#endif
    switch (u1_state_ctrl)
    {
#if (USE_OL2CL_CTRL == MTR_CLR)
        case MTR_CTRL_CLL_OPL2CLL:
            if (s4_ref_temp_idq_ctrl[MTR_ID] <= 0)
            {
                u1_state_ctrl = MTR_CTRL_CLL_SPEED_CTRL;
            }
            break;
#endif

        case MTR_CTRL_CLL_SPEED_CTRL:
            if (mtr_abs(g_st_foc_common.st_foc_speed.st_asr.s4_speed)
                    < p_st_foc_common->st_foc_speed.st_asr.s4_th_cl2ol_speed)
            {
                if (p_st_foc_common->st_foc_speed.st_asr.u2_cnt_cl2ol_judge_wait > MTR_CL2OL_JUDGE_WAIT_CNT)
                {
                    /* Reset parameters for CL to OL transition */
                    p_st_foc_common->st_foc_speed.u1_state_ref_id       = MTR_ID_MANUAL;
                    p_st_foc_common->st_foc_speed.u1_state_ref_iq       = MTR_IQ_ZERO_CONST;
                    p_st_foc_common->st_foc_carrier.st_pll.s4_est_speed = 0;

                    /* Set ID and IQ references */
                    p_st_foc_common->st_foc_carrier.st_acr.s4_ref_id
                                = p_st_foc_common->st_foc_carrier.st_acr.s4_ref_id_ol;
                    p_st_foc_common->st_foc_carrier.st_acr.s4_ref_iq             = 0;
                    p_st_foc_common->st_foc_speed.st_asr.u2_cnt_cl2ol_judge_wait = 0;

#if (MOD_2PH_BOT == MOD_METHOD)
                    p_st_foc_common->st_foc_carrier.st_mod.s2_cnt_2ph_bot_change = 0;
#endif

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
                    p_st_foc_common->st_foc_carrier.st_acr.u1_flg_err_zero = MTR_CLR;
                    p_st_foc_common->st_foc_carrier.st_acr.u1_flg_err_zero = MTR_CLR;
#endif

                    /* Step-out process - Reset speed if above threshold */
                    if (mtr_abs(*p_s4_ref_temp_speed_ctrl) > p_st_foc_common->st_foc_speed.st_asr.s4_th_ol2cl_speed)
                    {
                        *p_s4_ref_temp_speed_ctrl = 0;
                    }

                    u1_state_ctrl = MTR_CTRL_OPL_CLL2OPL;
                }
                else
                {
                    p_st_foc_common->st_foc_speed.st_asr.u2_cnt_cl2ol_judge_wait++;
                }
            }
            else
            {
                /* Reset CL to OL judgment counter */
                g_st_foc_common.st_foc_speed.st_asr.u2_cnt_cl2ol_judge_wait = 0;
            }
            break;
        default:
            break;
    }

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD && MOD_2PH_BOT == MOD_METHOD)
    /* Adjust parameters for single shunt current sensing */
    int32_t abs_speed = mtr_abs(p_st_foc_common->st_foc_speed.st_asr.s4_speed);

    if (abs_speed > p_st_foc_common->st_foc_carrier.st_sscs.s4_mod_3ph2ph_speed_rad)
    {
        if (s4_ref_temp_idq_ctrl[MTR_ID] <= 0)
        {
            /* Switch to 2-phase mode at high speed */
            p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt =
                p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt_2ph;
            p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt =
                p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt_2ph;
            p_st_foc_common->st_foc_carrier.st_sscs.u1_flag_mod_2ph = MTR_SET;
        }
    }
    else if (abs_speed < p_st_foc_common->st_foc_carrier.st_sscs.s4_mod_2ph3ph_speed_rad)
    {
        /* Switch to 3-phase mode at low speed */
        p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt =
            p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt_3ph;
        p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt =
            p_st_foc_common->st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt_3ph;
        p_st_foc_common->st_foc_carrier.st_sscs.u1_flag_mod_2ph = MTR_CLR;
    }
#endif

    return u1_state_ctrl;
} /* End of function mtr_speed_process_cll_ctrl */

/***********************************************************************************************************************
* @fn             mtr_speed_state_ctrl_get
* @brief          Get drive control state
* @return         Drive control state
***********************************************************************************************************************/
static uint8_t mtr_speed_state_ctrl_get(void)
{
    return g_st_foc_common.u1_state_ctrl;
} /* End of function mtr_speed_state_ctrl_get */

/***********************************************************************************************************************
* @fn             mtr_ref_iq_get
* @brief          Get Iq reference
* @param[in,out]  p_st_speed    The pointer to the Sensor-less FOC speed control data structure
* @param[in]      p_st_carrier  The pointer to the Sensor-less FOC carrier control data structure
* @return         Iq reference
***********************************************************************************************************************/
static int32_t mtr_ref_iq_get(st_mtr_foc_speed_t *p_st_speed, st_mtr_foc_carrier_t *p_st_carrier)
{
    int32_t s4_ref_iq_buff    = 0;
    int32_t s4_temp_err       = 0;
    int32_t s4_temp_d0_div_pm = 0;

    switch (p_st_speed->u1_state_ref_iq)
    {
        case MTR_IQ_ZERO_CONST:
            s4_ref_iq_buff = 0;             /*** constant zero set ***/
            break;

        case MTR_IQ_MANUAL:
            s4_temp_err = p_st_carrier->st_acr.s4_ref_iq - g_st_foc_common.st_foc_carrier.st_ref_i.ax_q; /* error */
            s4_temp_err = mtr_limit_abs(s4_temp_err, p_st_carrier->st_acr.s4_lim_ramp_current); /* limit error */

            /* Add error to control reference */
            s4_ref_iq_buff = g_st_foc_common.st_foc_carrier.st_ref_i.ax_q + s4_temp_err;
            break;

#if (USE_OL2CL_CTRL == MTR_SET)
        case MTR_IQ_OL2CL:
            s4_ref_iq_buff = RM_MTR_OplOL2CLRefIqGet(&p_st_speed->st_ol2cl,
                                        g_st_foc_common.st_foc_carrier.st_ref_i.ax_d);

            /*** limit iq reference ***/
            s4_ref_iq_buff = mtr_limit_abs(s4_ref_iq_buff, FIX_fromfloat(MTR_LIMIT_IQ * PU_SF_CURRENT, MTR_Q_CURRENT));
            break;
#endif
        case MTR_IQ_SPEED_PI_OUTPUT:

            /*** speed PI control ***/
            if (0 < g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed_ctrl)
            {
                s4_temp_d0_div_pm = p_st_speed->st_asr.s4_coef_d0_div_pm;
            }
            else
            {
                s4_temp_d0_div_pm = -p_st_speed->st_asr.s4_coef_d0_div_pm;
            }

            /* Speed error */
            s4_temp_err = g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed_ctrl
                        - g_st_foc_common.st_foc_speed.st_asr.s4_speed;

            /*** speed PI control ***/
            s4_ref_iq_buff  = mtr_pi_run_asr(&p_st_speed->st_asr.st_pi, s4_temp_err,
                                        (MTR_Q_AFREQ + MTR_Q_ASR_KP) - MTR_Q_CURRENT,/*kp_q*/
                                        (MTR_Q_AFREQ - MTR_Q_PI_RUN_ASR_ERR),
                                        MTR_Q_ASR_KIDT - (MTR_Q_CURRENT - MTR_Q_PI_RUN_ASR_INTG), /*q_err_shift*/
                                        MTR_Q_PI_RUN_ASR_ERR - MTR_Q_PI_RUN_ASR_INTG );
            s4_ref_iq_buff += s4_temp_d0_div_pm;

            /*** limit iq reference ***/
            s4_ref_iq_buff = mtr_limit_abs(s4_ref_iq_buff,
                                    FIX_fromfloat(MTR_LIMIT_IQ * PU_SF_CURRENT, MTR_Q_CURRENT));
            break;

        default:
            break;
    }

    /* return iq reference */
    return (s4_ref_iq_buff);
} /* End of function mtr_ref_iq_get */

/***********************************************************************************************************************
* @fn             mtr_ref_id_get
* @brief          Get Id reference
* @param[in,out]  p_st_speed    The pointer to the Sensor-less FOC speed control data structure
* @param[in]      p_st_carrier  The pointer to the Sensor-less FOC carrier control data structure
* @return         Id reference
***********************************************************************************************************************/
static int32_t mtr_ref_id_get(st_mtr_foc_speed_t *p_st_speed, st_mtr_foc_carrier_t *p_st_carrier)
{
    int32_t s4_ref_id_buff = 0;
    int32_t s4_temp_err    = 0;

    /* using at start-up */
    switch (p_st_speed->u1_state_ref_id)
    {
        case MTR_ID_ZERO_CONST:
            s4_ref_id_buff = 0;            /*** constant zero set ***/
            break;

        case MTR_ID_MANUAL:
            s4_temp_err = p_st_carrier->st_acr.s4_ref_id - g_st_foc_common.st_foc_carrier.st_ref_i.ax_d;
            s4_temp_err = mtr_limit_abs(s4_temp_err, p_st_carrier->st_acr.s4_lim_ramp_current); /* limit error */

            /* Add error to control reference */
            s4_ref_id_buff = g_st_foc_common.st_foc_carrier.st_ref_i.ax_d + s4_temp_err;
            break;

        case MTR_ID_MTPA2FW:
            s4_ref_id_buff = g_st_foc_common.st_foc_carrier.st_ref_i.ax_d;
            break;

        default:
            break;
    }

    /* return id reference */
    return (s4_ref_id_buff);
} /* End of function mtr_ref_id_get */

/***********************************************************************************************************************
* @fn             mtr_offset_calc_init
* @brief          Initialize the offset calculation for current sensing
* @return         None
***********************************************************************************************************************/
static void mtr_offset_calc_init(void)
{
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    /* Calculate duty cycle values for single shunt configuration */
    uint32_t u4_half_duty    = (MTR_HALF_CARRIER_CNT + MTR_HALF_DEADTIME_CNT) - 1;
    uint32_t u4_adjust_cnt_a = (uint32_t)(MTR_PWM_SHIFT_DEADTIME + MTR_PWM_SHIFT_AD_CONVERT_CNT
                                    + g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt);
    uint32_t u4_adjust_cnt_b = (uint32_t)(MTR_PWM_SHIFT_DEADTIME + MTR_PWM_SHIFT_AD_CONVERT_CNT
                                    + g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt);


    /* Configure duty cycles for all three phases */
    three_phase_duty_cycle_t duty_cycle;
    duty_cycle.duty[THREE_PHASE_CHANNEL_U] = u4_half_duty + u4_adjust_cnt_a;
    duty_cycle.duty[THREE_PHASE_CHANNEL_V] = u4_half_duty;
    duty_cycle.duty[THREE_PHASE_CHANNEL_W] = u4_half_duty - u4_adjust_cnt_b;
    duty_cycle.duty_buffer[THREE_PHASE_CHANNEL_U] = u4_half_duty - u4_adjust_cnt_a;
    duty_cycle.duty_buffer[THREE_PHASE_CHANNEL_V] = u4_half_duty;
    duty_cycle.duty_buffer[THREE_PHASE_CHANNEL_W] = u4_half_duty + u4_adjust_cnt_b;

    /* Set the duty cycle for three-phase PWM in CompMode3 */
    R_MTR_GPT_THREE_PHASE_CompMode3_DutyCycleSet(g_three_phase0.p_ctrl, &duty_cycle);

    /* Configure ADC trigger points for current sensing */
    R_MTR_GPT_THREE_PHASE_SetADCTrigger(g_three_phase0.p_ctrl,
        (uint16_t)( u4_half_duty                 + MTR_PWM_SHIFT_AD_CONVERT_CNT),
        (uint16_t)((u4_half_duty - u4_adjust_cnt_b) + MTR_PWM_SHIFT_AD_CONVERT_CNT));
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    /* Configure ADC scan mask based on phase current configuration */
    g_st_foc_common.st_foc_carrier.st_tscs.s4_offset_iv = 0;
    g_st_foc_common.st_foc_carrier.st_tscs.s4_offset_iw = 0;
#if (USE_U_PHASE_CURRENT == MTR_SET)
	g_st_foc_common.st_foc_carrier.st_tscs.s4_offset_iu = 0;
    uint32_t scan_mask_a = R_MTR_ADC_SCAN_MASK_UVW;
#else
    uint32_t scan_mask_a = R_MTR_ADC_SCAN_MASK_VW_IDC;
#endif
    uint32_t scan_mask_b = R_MTR_ADC_SCAN_MASK_VDC;

    /* Set ADC channels for current sampling */
    R_MTR_ADC_SetChannels(g_adc0.p_ctrl, scan_mask_a, scan_mask_b);

    /* Configure duty cycles for all three phases */
    three_phase_duty_cycle_t duty_cycle;
    duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = MTR_OFFSET_CENTER_AMPLITUDE_CNT - 1;
    duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = MTR_OFFSET_CENTER_AMPLITUDE_CNT - 1;
    duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = MTR_OFFSET_CENTER_AMPLITUDE_CNT - 1;

    /* Set the duty cycle for three-phase PWM in CompMode2 */
    R_GPT_THREE_PHASE_CompMode2_DutyCycleSet(g_three_phase0.p_ctrl, &duty_cycle);

#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */
} /* End of function mtr_offset_calc_init */

/***********************************************************************************************************************
* @fn             mtr_offset_calc_status_get
* @brief          Get the status of offset calculation completion
* @return         Offset calculation end flag (0: not completed, 1: completed)
***********************************************************************************************************************/
static uint8_t mtr_offset_calc_status_get(void)
{
    return g_st_foc_common.st_foc_carrier.u1_flg_offset_end;
} /* End of function mtr_offset_calc_status_get */

/***********************************************************************************************************************
* @fn             mtr_error_check
* @brief          Check error status
* @param[in,out]  p_st_carrier  The pointer to the Sensor-less FOC main data structure
* @return         None
***********************************************************************************************************************/
static void mtr_error_check(st_mtr_foc_carrier_t *p_st_carrier)
{
#if (USE_PWMOPA == MTR_SET)
    /*=====================================*/
    /*     HW over current error check     */
    /*=====================================*/
    uint8_t ret;
    R_MTR_POEG_RecoverForcedShutdown(g_poeg0.p_ctrl, POEG_RECOVER_TIMEOUT, &ret);
    if (MTR_SET == ret)
    {
        p_st_carrier->u2_error_status |= MTR_ERROR_OVER_CURRENT_HW;
    }
#endif

    /*==================================*/
    /*     over voltage error check     */
    /*==================================*/
    if (g_st_foc_common.s4_ad_vdc > FIX_fromfloat(MTR_OVERVOLTAGE_LIMIT * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
    {
        p_st_carrier->u2_error_status |= MTR_ERROR_OVER_VOLTAGE;
    }

    /*==================================*/
    /*     under voltage error check    */
    /*==================================*/
    if (MTR_CLR != p_st_carrier->u1_flg_charge_cap)    /* Check "capacitor charge completed" */
    {
        if (g_st_foc_common.s4_ad_vdc < FIX_fromfloat(MTR_UNDERVOLTAGE_LIMIT * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
        {
            p_st_carrier->u2_error_status |= MTR_ERROR_UNDER_VOLTAGE;
        }
    }

    /*==================================*/
    /*     over speed error check       */
    /*==================================*/
    if (MTR_DRIVE_CLL == (g_st_foc_common.u1_state_ctrl & 0x80))
    {
        if (mtr_abs(g_st_foc_common.st_foc_speed.st_asr.s4_speed)
                    > FIX_fromfloat(MTR_SPEED_LIMIT_RAD * PU_SF_AFREQ, MTR_Q_AFREQ))
        {
            p_st_carrier->u2_error_status |= MTR_ERROR_OVER_SPEED;
        }
    }

    if (MTR_ERROR_NONE != p_st_carrier->u2_error_status)
    {
        /* execute error event */
        RM_MTR_EventExec(MTR_EVENT_ERROR);
    }
} /* End of function mtr_error_check */

/***********************************************************************************************************************
* @fn             mtr_abs
* @brief          Absolute value
* @param[in]      s4_value   Target value
* @return         Absolute value
***********************************************************************************************************************/
static inline int32_t mtr_abs(int32_t s4_value)
{
    return ((s4_value ^ (s4_value >> 31)) - (s4_value >> 31));
} /* End of function mtr_abs */

/***********************************************************************************************************************
* @fn             mtr_limit_abs
* @brief          Limit with absolute value
* @param[in]      s4_value         Target value
* @param[in]      s4_limit_value   Limit value
* @return         Limited value
***********************************************************************************************************************/
static int32_t mtr_limit_abs(int32_t s4_value, int32_t s4_limit_value)
{
    if (s4_value > s4_limit_value)
    {
        return (s4_limit_value);
    }
    else if (s4_value < (-s4_limit_value))
    {
        return (-s4_limit_value);
    }
    else
    {
        return (s4_value);
    }
} /* End of function mtr_limit_abs */

