/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name        : RM_DSP_RA2_GCC_32BIT.h
* Version          : 1.00
* Description      : This file implements arithmetic operation for motor control.
************************************************************************************************************************/

#ifndef RM_DSP_RA2_GCC_32BIT_H_
#define RM_DSP_RA2_GCC_32BIT_H_

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include <stdint.h>

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Convert x in Q28 format to float */
#define FIX28_tofloat(x) ((float)(x)/(float)(1L<<(28)))
/* Convert x in Q29 format to float */
#define FIX29_tofloat(x) ((float)(x)/(float)(1L<<(29)))
/* Convert x in Q30 format to float */
#define FIX30_tofloat(x) ((float)(x)/(float)(1L<<(30)))
/* Convert x in Q31 format to float */
#define FIX31_tofloat(x) ((float)(x)/(float)(1L<<(31)))

/* Convert x in float to Q28 format  */
#define FIX28_fromfloat(x) ((int32_t)((x)*(float)(1L<<(28))))
/* Convert x in float to Q29 format  */
#define FIX29_fromfloat(x) ((int32_t)((x)*(float)(1L<<(29))))
/* Convert x in float to Q30 format  */
#define FIX30_fromfloat(x) ((int32_t)((x)*(float)(1L<<(30))))
/* Convert x in float to Q31 format  */
#define FIX31_fromfloat(x) ((int32_t)((x)*(float)(1L<<(31))))

/* Convert x in Qn format to float */
#define FIX_tofloat(x, n)          (ldexpf((float)(x),-((int)(n))))

/* Convert float x to int16_t in Qn format  */
#define FIX_fromfloat(x, n)        ((int32_t)ldexpf((float)(x),(n)))


/* right shift operation (predefined number of shift bits) */
#define FIX_rs(a, sar)             ((int32_t)((a)  >> (sar)))
/* left shift operation (predefined number of shift bits) */
#define FIX_ls(a, sal)             ((int32_t)((a)  << (sal)))
/* Multiplication followed by right shift operation (predefined number of shift bits) */
#define FIX_mul_rs(a, b, sar)      ((int32_t)(((int32_t)(a) >> ((sar)>>1)) * ((int32_t)(b) >> ((sar)-((sar)>>1)))))


/* Multiplication followed by right shift operation (predefined number of shift bits)
   (Add 1 bit when the right shift of negative numbers. ) */
#define FIX_mul_rs_sign(a, b, sar) ((int32_t)(((b)>=0)? ((int32_t)(((int32_t)(a) >> ((sar)>>1)) * ((int32_t)(b) >> ((sar)-((sar)>>1))))) \
                                                    :~((int32_t)(((int32_t)(a) >> ((sar)>>1)) * ((int32_t)(~(b)+1) >> ((sar)-((sar)>>1))))+1)))
/* Multiplication followed by left shift operation (predefined number of shift bits) */
#define FIX_mul_ls(a, b, sal)      ((int16_t)(((int32_t)(a) * (int32_t)(b)) << (sal)))
/* Multiplication followed by right shift operation (predefined number of shift bits) */
#define FIX_mul32_rs(a, b, sar)    (((int32_t)(a) * (int32_t)(b)) >> (sar))
/* Multiplication followed by left shift operation (predefined number of shift bits) */
#define FIX_mul32_ls(a, b, sal)    (((int32_t)(a) * (int32_t)(b)) << (sal))
/* Multiplication */
#define FIX_mul(a, b)              ((int16_t)((int32_t)(a) * (int32_t)(b)))
/* Multiplication */
#define FIX_mul32(a, b)            ((int32_t)(a) * (int32_t)(b))
/* Division */
#define FIX_div_uint16(a, b)       (((uint16_t)(a) / (uint16_t)(b)))

#define FIX_div(a, b)              ((((unsigned long long)(a)<<32) / (unsigned long long)(b))) /* uint32 Division */

/* Addition with saturation countermeasures */
#define FIX_add_int16(a,b)         (((a) > 0) ? \
                                        (((b) > 0) && ((a) + (b) < 0)) ? 32767  : (a) + (b) : \
                                        (((b) < 0) && ((a) + (b) > 0)) ? -32768 : (a) + (b))
/* Addition with saturation countermeasures */
#define FIX_add_int32(a,b)         (((a) > 0) ? \
                                        (((b) > 0) && ((a) + (b) < 0)) ? 2147483647  : (a) + (b) : \
                                        (((b) < 0) && ((a) + (b) > 0)) ? -2147483648 : (a) + (b))

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/
typedef int32_t FIX28;
typedef int32_t FIX29;
typedef int32_t FIX30;

typedef struct
{
    FIX28 sin;
    FIX28 cos;
    FIX28 angle_rad;
} st_sincos28;
typedef struct
{
    FIX28 ph_u;
    FIX28 ph_v;
    FIX28 ph_w;
    FIX28 ax_d;
    FIX28 ax_q;
    st_sincos28 st_angle;
} st_coordinate28;

/**********************************************************************************************************************
 * Exported global variables
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Public APIs
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * @brief       d =  sqrt(3/2) * u * cos - sqrt(2) * (1/2 * u + w) * sin
 *              q = -sqrt(3/2) * u * sin - sqrt(2) * (1/2 * u + w) * cos
 *
 * @param[in]   p_uw2dq
 *                  u     FIX28, where -4*sqrt(2/3) <  u   <= 4*sqrt(2/3)
 *                  w     FIX28, where -4*sqrt(2/3) <  w   <= 4*sqrt(2/3)
 *                  sin   FIX28, where -1.0         <= sin <= 1.0
 *                  cos   FIX28, where -1.0         <= cos <= 1.0
 * @param[out]  p_uw2dq
 *                  d     FIX28, where -4 <= d <= 4
 *                  q     FIX28, where -4 <= q <= 4
 **********************************************************************************************************************/
void R_motor_uw2dq_abs_FIX28 (st_coordinate28 * p_uw2dq);

/***********************************************************************************************************************
 * @brief       u =   sqrt(2/3) * (cos * d - sin * q)
*               v =   sqrt(1/6) * (sin * q - cos * d) + sqrt(1/2) * (sin * d + cos * q)
*               w =   sqrt(1/6) * (sin * q - cos * d) - sqrt(1/2) * (sin * d + cos * q)
 *
 * @param[in]   p_dq2uvw
 *                  d     FIX28, where -4.0 <= d   <= 4.0
 *                  q     FIX28, where -4.0 <= q   <= 4.0
 *                  sin   FIX28, where -1.0 <= sin <= 1.0
 *                  cos   FIX28, where -1.0 <= cos <= 1.0
 * @param[out]  p_dq2uvw
 *                  u     FIX28, where -4*sqrt(2/3) <= u <= 4*sqrt(2/3)
 *                  v     FIX28, where -4*sqrt(2/3) <= v <= 4*sqrt(2/3)
 *                  w     FIX28, where -4*sqrt(2/3) <= w <= 4*sqrt(2/3)
 **********************************************************************************************************************/
void R_motor_dq2uvw_abs_FIX28 (st_coordinate28 * p_dq2uvw);

/***********************************************************************************************************************
 * @brief       sin = sin(theta) / cos = cos(theta)
 *
 * @param[in]   p_sincos
 *                  theta FIX28, where -2*pi <= theta <= 2*pi [rad]
 * @param[out]  p_sincos
 *                  sin   FIX28, where -1.0  <= sin   <= 1.0
 *                  cos   FIX28, where -1.0  <= cos   <= 1.0
 **********************************************************************************************************************/
void R_motor_sincos_FIX28 (st_sincos28 * p_sincos);

/***********************************************************************************************************************
 * @brief       atan(x/y)(x < y) or atan(y/x)(y < x)
 *
 * @param[in]   x   FIX28, where -4.0 <= x      <= 4.0
 * @param[in]   y   FIX28, where -4.0 <= y      <= 4.0
 * @return          FIX28, where -pi  <= return <= pi
 **********************************************************************************************************************/
FIX28 R_motor_atan2_FIX28 (FIX28 x, FIX28 y);

/***********************************************************************************************************************
 * @brief       sqrt(x^2 + y^2)
 *
 * @param[in]   x   FIX28, where -4.0 <= x      <= 4.0
 * @param[in]   y   FIX28, where -4.0 <= y      <= 4.0
 * @return          FIX28, where    0 <= return <= 4.0*sqrt(2)
 **********************************************************************************************************************/
FIX28 R_motor_sqrt_sum_FIX28 (FIX28 x, FIX28 y);

/***********************************************************************************************************************
 * @brief       sqrt(x^2 - y^2)
 *
 * @param[in]   x   FIX28, where -4.0 <= x      <= 4.0
 * @param[in]   y   FIX28, where -4.0 <= y      <= 4.0
 * @return          FIX28, where    0 <= return <= 4.0
 **********************************************************************************************************************/
FIX28 R_motor_sqrt_dif_FIX28 (FIX28 x, FIX28 y);

#endif /* RM_DSP_RA2_GCC_32BIT_H_ */
