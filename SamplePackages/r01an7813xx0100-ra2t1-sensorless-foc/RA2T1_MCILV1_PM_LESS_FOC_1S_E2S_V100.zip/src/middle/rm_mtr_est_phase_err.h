/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_est_phase_err.h
* Description : Definitions of Phase error estimator module
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

#ifndef RM_MTR_EST_PHASE_ERR_H
#define RM_MTR_EST_PHASE_ERR_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/
/* Phase error estimator data structure */
typedef struct{
    int32_t       s4_est_ed;                  /* d-qxis BEMF [PU(V)] */
    int32_t       s4_est_eq;                  /* q-axis BEMF [PU(V)] */
    int32_t       s4_est_e;                   /* BEMF amplitude of permanent magnet [PU(V)] */
    int32_t       s4_coef_reci_ke;            /* Reciprocal of Back-EMF constant [PU(1/Vs/m)] */
} st_mtr_estimate_phe_t;

typedef struct{
    int32_t       s4_ref_vd;                  /* vd [PU(V)] */
    int32_t       s4_ref_vq;                  /* vq [PU(V)] */
    int32_t       s4_est_r_id;                /* R*id [PU(V)] */
    int32_t       s4_est_r_iq;                /* R*iq [PU(V)] */
    int32_t       s4_est_speed_ld_id;         /* speed*Ld*id [PU(V)] */
    int32_t       s4_est_speed_lq_iq;         /* speed*Lq*iq [PU(V)] */
} st_mtr_est_vect_t;

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : RM_MTR_ESTIMATE_AngleSpeedGet
* Description   : Acquire phase error
* Arguments     : p_st_phe              - The pointer to the Phase error estimator data structure
*               : s4_est_speed          - Speed  [PU(rad)]
*               : p_st_est_vect         - The pointer to the structure for Phase error estimator data
* Return Value  : s4_phe_phase_err_red  - Phase error [PU(rad)]
***********************************************************************************************************************/
int32_t RM_MTR_ESTIMATE_AngleSpeedGet (st_mtr_estimate_phe_t *p_st_phe, int32_t s4_est_speed,
                            st_mtr_est_vect_t* p_st_est_vect);

#endif /* RM_MTR_EST_PHASE_ERR_H */
