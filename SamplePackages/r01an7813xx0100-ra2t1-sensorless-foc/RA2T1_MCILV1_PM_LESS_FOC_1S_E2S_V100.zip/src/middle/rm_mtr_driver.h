/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_driver.h
* Description : Definitions of the processing of accessing driver
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef RM_MTR_DRIVER_H
#define RM_MTR_DRIVER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_ctrl_gain.h"
#include "rm_mtr_parameter.h"
#include <stdint.h>

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/* Data structure for storing system configuration inputs */
typedef struct
{
    int8_t                       s1_ref_direction;          /* Reference rotation direction */
    uint16_t                     u2_cnt_offset_calc;        /* Calculation counter for current offset [cnt] */
    int32_t                      s4_ref_speed;              /* Reference speed [PU(rad/s)] */
    int32_t                      s4_lim_accel;              /* Change speed limit [PU(rad/s)] */
    int32_t                      s4_max_speed;              /* Maximum speed [PU(rad/s)] */
    int32_t                      s4_th_speed_cl2ol;         /* Speed of switching from sensorless to open loop [PU(rad/s)] */
    int32_t                      s4_th_speed_ol2cl;         /* Speed of switching from open loop to sensorless [PU(rad/s)] */
    int32_t                      s4_ref_id_ol;              /* Reference d-axis current [PU(A)] */
    int32_t                      s4_cnt_wait_draw_in;       /* Draw-in wait time count value */
    int32_t                      s4_coef_init_intg;         /* q-axis pi control initial integral parameter */
    int32_t                      s4_lim_current;            /* Limit of current value change A/ms] */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if (MOD_2PH_BOT == MOD_METHOD)
    int32_t                      s4_mod_3ph2ph_speed_rad;   /* Switching speed from 3-phase to 2-phase modulation */
    int32_t                      s4_mod_2ph3ph_speed_rad;   /* Switching speed from 2-phase to 3-phase modulation */
    int16_t                      s2_ad_point_a_adj_cnt_3ph; /* A point delay adjustment count of
                                                               A/D for 3phase modulation */
    int16_t                      s2_ad_point_b_adj_cnt_3ph; /* B point delay adjustment count of
                                                               A/D for 3phase modulation */
    int16_t                      s2_ad_point_a_adj_cnt_2ph; /* A point delay adjustment count of
                                                               A/D for 2phase modulation */
    int16_t                      s2_ad_point_b_adj_cnt_2ph; /* B point delay adjustment count of
                                                               A/D for 2phase modulation */
#else
    int16_t                      s2_ad_point_a_adj_cnt;     /* A point delay adjustment count of A/D */
    int16_t                      s2_ad_point_b_adj_cnt;     /* B point delay adjustment count of A/D */
#endif
#endif
    int16_t                      s2_mod_2ph_bot_change_cnt; /* 2-phase modulation phase switching judgment counter */
#if (USE_OPENLOOP_DAMPING == MTR_SET)
    int32_t                      s4_speed_limit_rate; /* Speed limit rate */
#endif
    st_mtr_parameter_t           st_motor;        /* Motor parameters */
} st_mtr_ctrl_input_t;

extern st_mtr_ctrl_input_t st_ics;               /* structure for ICS input */
extern st_mtr_design_parameter_t    g_st_ctrl_params;  /* Control parameters */
extern st_mtr_ctrl_gain_t           g_st_gain_buf;     /* Calculated gains in PI unit */

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : RM_MTR_ControlInit
* Description   : Initializes FOC motor controller
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void RM_MTR_ControlInit (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_EventExec
* Description   : Execute event of FOC control
* Arguments     : u1_event - the event index
* Return Value  : None
***********************************************************************************************************************/
void RM_MTR_EventExec (uint8_t  u1_event);

/***********************************************************************************************************************
* Function Name : RM_MTR_CapacitorCharge
* Description   : Wait for charging capacitor
* Arguments     : None
* Return Value  : u2_charge_cap_error - charge capacitor timeout error
***********************************************************************************************************************/
uint16_t RM_MTR_CapacitorCharge (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_SpeedSet
* Description   : Set speed reference for board UI
* Arguments     : s2_ref_speed_rpm - Speed reference[rpm]
*               : s2_min_speed_rpm - minimum speed [rpm]
* Return Value  : u1_stop_req - stop request flag
***********************************************************************************************************************/
uint8_t RM_MTR_SpeedSet (int32_t s4_ref_speed_rpm, int32_t s4_ref_min_speed_rpm);

/***********************************************************************************************************************
* Function Name : RM_MTR_SpeedGet
* Description   : Get speed value
* Arguments     : none
* Return Value  : Speed [rpm]
***********************************************************************************************************************/
uint32_t RM_MTR_SpeedGet (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_DirSet
* Description   : Set rotation direction
* Arguments     : s1_dir - rotation direction
* Return Value  : none
***********************************************************************************************************************/
void RM_MTR_DirSet (int8_t s1_dir);

/***********************************************************************************************************************
* Function Name : RM_MTR_DirGet
* Description   : Get current rotation direction
* Arguments     : none
* Return Value  : g_u1_direction - current rotation direction
***********************************************************************************************************************/
uint8_t RM_MTR_DirGet (void);

/***********************************************************************************************************************
* Function Name : R_MTR_GetVr1
* Description   : Get A/D converted value of VR1
* Arguments     : None
* Return Value  : A/D converted value of VR1
***********************************************************************************************************************/
int16_t R_MTR_GetVr1 (void);

/***********************************************************************************************************************
* Function Name : R_MTR_UseVr1
* Description   : Get VR1 use flag
* Arguments     : u1_flag - VR1 use flag
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_UseVr1 (int8_t u1_flag);

/***********************************************************************************************************************
* Function Name : RM_MTR_StatusGet
* Description   : Get status of motor control system
* Arguments     : none
* Return Value  : g_u1_system_mode - Motor status
***********************************************************************************************************************/
uint8_t RM_MTR_StatusGet (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_StatusErrorGet
* Description   : Get status of motor error
* Arguments     : none
* Return Value  : g_u1_event_system - Motor status
***********************************************************************************************************************/
uint16_t RM_MTR_StatusErrorGet (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_IcsBufferSet
* Description   : Set value to buffer
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void RM_MTR_IcsBufferSet (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_VariablesSet
* Description   : Set variables
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void RM_MTR_VariablesSet (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_InputBuffParamReset
* Description   : Reset input buffer variables when motor control reset
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void RM_MTR_InputBuffParamReset (void);

/***********************************************************************************************************************
* Function Name : RM_MTR_UpdatePollingSet
* Description   : Polling u1_trig_enable_write to update configurations and commands
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void RM_MTR_UpdatePollingSet (void);

#endif /* RM_MTR_DRIVER_H */
