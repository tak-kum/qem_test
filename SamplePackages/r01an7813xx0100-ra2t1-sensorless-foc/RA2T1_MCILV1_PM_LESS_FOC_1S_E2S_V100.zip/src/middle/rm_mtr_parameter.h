/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_parameter.h
* Description : Definitions of parameters used in control
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef RM_MTR_PARAMETER_H
#define RM_MTR_PARAMETER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_config.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Voltage parameter */
#define     MTR_PWM_DUTY_RANGE     ((1L << MTR_Q_VMOD)-1)  /* modulation ratio represents 100% duty PWM (2^MTR_Q_VMOD) */
#define     MTR_INPUT_V            (IP_INPUT_V)            /* input DC voltage [V] */
#define     MTR_HALF_VDC           (MTR_INPUT_V * 0.5f)    /* vdc/2 */
#define     MTR_MCU_ON_V           (MTR_INPUT_V * 0.8f)    /* MCU power on voltage , 80% of input DC voltage default */
#define     MTR_OVERVOLTAGE_LIMIT  (IP_OVERVOLTAGE_LIMIT)  /* over voltage limit [V] */
#define     MTR_UNDERVOLTAGE_LIMIT (IP_UNDERVOLTAGE_LIMIT) /* under voltage limit [V] */

/* Coefficient for finding the reciprocal of voltage */
#define     MTR_RECIV_COEF         ((int32_t)(2 * PU_BASE_VOLTAGE_V / IP_VDC_RANGE * (1 << MTR_Q_RECIV)))

/* Angle parameter */
/* MTR_ANGLE_RANGE is integer */
#define     MTR_ANGLE_RANGE        ((int32_t)(MTR_TWOPI * PU_SF_ANGLE * (1 << MTR_Q_ANGLE)))/* Motor angle 2^12 */
/* MTR_ANGLE_QUAT_RANGE is integer */
#define     MTR_ANGLE_QUAT_RANGE   ((int32_t)(MTR_ANGLE_RANGE / 4)) /* Motor angle 2^12 */

/* Current parameter */
#define     MTR_OVERCURRENT_LIMIT  (CP_OC_LIMIT)                  /* over current limit [A] */
#define     MTR_I_LIMIT_VD         (1.5f * IP_INPUT_V * 0.5f)            /* current PI integral term limit for vd */
#define     MTR_I_LIMIT_VQ         (1.5f * IP_INPUT_V * 0.5f)            /* current PI integral term limit for vq */

/* Speed parameter */
#define     MTR_RPM_RAD            ((MP_POLE_PAIRS * MTR_TWOPI) / 60.0f)/* [rpm]->[rad/s] */
#define     MTR_SPEED_LIMIT_RAD    (CP_SPEED_LIMIT_RPM * MTR_RPM_RAD)/* over speed limit [rad/s] */

#define     MTR_MAX_SPEED_RAD      (CP_MAX_SPEED_RPM * MTR_RPM_RAD)/* maximum speed (electrical) [rad/s] */
#define     MTR_LIMIT_IQ           (MP_RATED_CURRENT * MTR_SQRT_3) /* speed PI limit for iq */
#define     MTR_I_LIMIT_CURRENT    (MP_RATED_CURRENT * MTR_SQRT_3) /* speed PI integral term limit for current */

#define     MTR_CL2OL_SPEED_RAD    (CP_CL2OL_SPEED_RPM * MTR_RPM_RAD)/* [rad/s] */
#define     MTR_OL2CL_SPEED_RAD    (CP_OL2CL_SPEED_RPM * MTR_RPM_RAD)/* [rad/s] */

#define     MTR_RECIM              (1.0f / (MP_BEMF_CONSTANT * PU_SF_BEMF_CONST))

#define     MTR_DRAW_IN_WAIT_CNT   (CP_DRAW_IN_WAIT_TIME / MTR_SPEED_CTRL_PERIOD)
                                                                /* Draw-in wait time count value */

/* MTR_SWITICH_COUNT is unsigned*/
#define     MTR_SWITCH_COUNT       ((uint16_t)(CP_OL2CL_SWITCH_TIME / MTR_SPEED_CTRL_PERIOD))
                                                                /* Time[cnt] to switch open-loop to closed-loop */
#define     MTR_CL2OL_JUDGE_WAIT_CNT ((uint16_t)(CP_CL2OL_JUDGE_WAIT_TIME / (CP_SPEED_CTRL_PERIOD * 1000)))
                                                                /* Wating counts to judge down to open-loop */

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    uint16_t u2_mtr_pp;            /* Number of pole pairs */
    int32_t  s4_mtr_r;             /* Resistance [ohm] */
    int32_t  s4_mtr_ld;            /* Inductance for d-axis [H] */
    int32_t  s4_mtr_lq;            /* Inductance for q-axis [H] */
    int32_t  s4_mtr_ke;            /* Magnetic Back-EMF constant [Vs/m] */
    int32_t  s4_mtr_j;             /* Rotor inertia [kgm^2] */
} st_mtr_parameter_t;

#endif /* RM_MTR_PARAMETER_H */
