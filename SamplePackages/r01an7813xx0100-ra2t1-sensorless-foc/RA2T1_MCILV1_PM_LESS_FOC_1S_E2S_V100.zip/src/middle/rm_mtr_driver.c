/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_driver.c
* Description : The processes of accessing driver
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdlib.h>
#include <math.h>
#include "rm_mtr_common.h"
#include "rm_mtr_driver.h"
#include "rm_mtr_foc_less_speed.h"
#include "rm_mtr_statemachine.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "r_mtr_config.h"
#include "r_mtr_ra2t1.h"

#if (USE_OPENLOOP_DAMPING == MTR_SET)
#include "rm_mtr_ol2cl_ctrl.h"
#endif

#include "hal_data.h"
#include "r_mtr_GPT_THREE_PHASE.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
st_mtr_design_parameter_t    g_st_ctrl_params;  /* Control parameters */
st_mtr_ctrl_gain_t           g_st_gain_buf;     /* Calculated gains in PI unit */

uint8_t  g_u1_trig_enable_write;       /* flag to request the reflection of user input parameters */
uint8_t  g_u1_stop_req;                /* Stop request flag */
int16_t  g_s2_cnt;                     /* Counter to remove chattering */

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern st_mtr_common_foc_t g_st_foc_common;

static uint8_t s_state_transition_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* Event / State         0:MTR_MODE_INIT, 1:MTR_MODE_DRIVE,  2:MTR_MODE_STOP */
/* 0:MTR_EVENT_STOP  */{   MTR_MODE_STOP,   MTR_MODE_STOP,     MTR_MODE_STOP  },
/* 1:MTR_EVENT_DRIVE */{   MTR_MODE_INIT,   MTR_MODE_DRIVE,    MTR_MODE_DRIVE },
/* 2:MTR_EVENT_ERROR */{   MTR_MODE_STOP,   MTR_MODE_STOP,     MTR_MODE_STOP  },
/* 3:MTR_EVENT_RESET */{   MTR_MODE_INIT,   MTR_MODE_DRIVE,    MTR_MODE_INIT  },};

static mtr_action_t s_action_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* Event / State         0:MTR_MODE_INIT,     1:MTR_MODE_DRIVE,  2:MTR_MODE_STOP */
/* 0:MTR_EVENT_STOP  */{   mtr_act_stop,       mtr_act_stop,       mtr_act_none  },
/* 1:MTR_EVENT_DRIVE */{   mtr_act_none,       mtr_act_none,       mtr_act_drive },
/* 2:MTR_EVENT_ERROR */{   mtr_act_error,      mtr_act_error,      mtr_act_error },
/* 3:MTR_EVENT_RESET */{   mtr_act_init,       mtr_act_none,       mtr_act_init  },};

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/


/***********************************************************************************************************************
* @fn             mtr_statemachine_init
* @brief          Initializes state machine for motor drive system
* @param[out]     p_state_machine   the pointer to the state machine data structure
* @return         None
***********************************************************************************************************************/
void mtr_statemachine_init(st_mtr_statemachine_t *p_state_machine)
{
    mtr_statemachine_reset(p_state_machine);
} /* End of function mtr_statemachine_init */

/***********************************************************************************************************************
* @fn             mtr_statemachine_reset
* @brief          Resets state machine
* @param[out]     p_state_machine   the pointer to the state machine data structure
* @return         None
***********************************************************************************************************************/
void mtr_statemachine_reset(st_mtr_statemachine_t *p_state_machine)
{
    p_state_machine->u1_status          = MTR_MODE_INIT;
    p_state_machine->u1_status_next     = MTR_MODE_INIT;
    p_state_machine->u2_status_error    = MTR_STATEMACHINE_ERROR_NONE;
} /* End of function mtr_statemachine_reset */

/***********************************************************************************************************************
* @fn             mtr_statemachine_event
* @brief          Performs state transition and execute corresponding action when
*                 specified event happen
* @param[in,out]  p_state_machine   The pointer to the state machine data structure
* @param[in]      p_object          The pointer to parameters passed to the action handler
* @param[in]      u1_event          The event index to be executed
*                       MTR_EVENT_INACTIVE  Stop the motor drive system
*                       MTR_EVENT_ACTIVE    Activate the motor drive system
*                       MTR_EVENT_ERROR     Throw an error and stop driving
*                       MTR_EVENT_RESET     Reset the configurations of motor drive system
* @return         The error flags of the state machine
* @retval         BIT0  Event index is out of bound, please check the u1_event
* @retval         BIT1  State index is out of bound
* @retval         BIT2  Action error (value other than 0 returned from action)
***********************************************************************************************************************/
uint8_t mtr_statemachine_event(st_mtr_statemachine_t *p_state_machine, void *p_object, uint8_t u1_event)
{
    mtr_action_t func_action;
    uint8_t      action_ret;

    /* Check if accessing state transition table out of bound */
    if (MTR_SIZE_EVENT <= u1_event)
    {
        /* Event is out of bound */
        u1_event = MTR_EVENT_ERROR;

        p_state_machine->u2_status_error |= MTR_STATEMACHINE_ERROR_EVENTOUTBOUND;
    }
    if (MTR_SIZE_STATE <= p_state_machine->u1_status)
    {
        /* State is out of bound */
        u1_event = MTR_EVENT_ERROR;

        p_state_machine->u1_status        = MTR_MODE_INIT;
        p_state_machine->u2_status_error |= MTR_STATEMACHINE_ERROR_STATEOUTBOUND;
    }

    /*
     * u1_current_event : Event happening
     * u1_status        : Current status
     * u1_status_next   : Status after action executed
     */
    p_state_machine->u2_crnt_event = u1_event;
    p_state_machine->u1_status_next   = s_state_transition_table[u1_event][p_state_machine->u1_status];

    /* Get action function from action table and execute action */
    func_action = s_action_table[u1_event][p_state_machine->u1_status];
    action_ret  = func_action(p_state_machine, p_object);

    /* If return value is not zero, set the Action Exception flag */
    if (action_ret)
    {
        p_state_machine->u2_status_error |= MTR_STATEMACHINE_ERROR_ACTIONEXCEPTION;
    }
    p_state_machine->u1_status = p_state_machine->u1_status_next;

    return ((uint8_t)(p_state_machine->u2_status_error));
} /* End of function mtr_statemachine_event */

/***********************************************************************************************************************
* @fn             mtr_statemachine_get_status
* @brief          Gets the status of system
* @param[in]      p_state_machine   the pointer to the state machine data structure
* @return         Status of system
***********************************************************************************************************************/
uint8_t mtr_statemachine_get_status(st_mtr_statemachine_t *p_state_machine)
{
    return (p_state_machine->u1_status);
} /* End of function mtr_statemachine_get_status */


/***********************************************************************************************************************
* @fn             mtr_act_drive
* @brief          Activates the motor control system and enables PWM output
* @param[in]      st_stm     The pointer to the state machine structure
* @param[out]     p_params   The pointer to the FOC data
* @return         The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_drive(st_mtr_statemachine_t *st_stm, void *p_params)
{
    FSP_PARAMETER_NOT_USED(st_stm);

    st_mtr_common_foc_t * p_common = p_params;

    RM_MTR_FOCMotorReset(p_common);  /* Initialize variables when motor control start */

    return (0);
} /* End of function mtr_act_drive */

/***********************************************************************************************************************
* @fn             mtr_act_stop
* @brief          Deactivates the motor control system and disables PWM output
* @param[in]      st_stm     The pointer to the state machine structure
* @param[in]      p_params   The pointer to the FOC data
* @return         The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_stop(st_mtr_statemachine_t *st_stm, void *p_params)
{
    FSP_PARAMETER_NOT_USED(st_stm);
    FSP_PARAMETER_NOT_USED(p_params);

    /* Do Nothing */

    return (0);
} /* End of function mtr_act_stop */

/***********************************************************************************************************************
* @fn             mtr_act_none
* @brief          The empty dummy function used to fill the blank in action table
* @param[in]      st_stm     The pointer to the state machine structure
* @param[in]      p_params   The pointer to the FOC data
* @return         Always success (0)
***********************************************************************************************************************/
uint8_t mtr_act_none(st_mtr_statemachine_t *st_stm, void *p_params)
{
    FSP_PARAMETER_NOT_USED(st_stm);
    FSP_PARAMETER_NOT_USED(p_params);

    /* Do Nothing */

    return (0);
} /* End of function mtr_act_none */

/***********************************************************************************************************************
* @fn             mtr_act_init
* @brief          Resets the configurations to default and clear error flags
* @param[in]      st_stm     The pointer to the state machine structure
* @param[out]     p_params   The pointer to the FOC data
* @return         The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_init(st_mtr_statemachine_t *st_stm, void *p_params)
{
    FSP_PARAMETER_NOT_USED(st_stm);

    st_mtr_common_foc_t * p_common = p_params;

    RM_MTR_FOCMotorDefaultInit(p_common);
    mtr_statemachine_event(&p_common->st_foc_carrier.st_stm, p_params, MTR_EVENT_STOP);

    return (0);
} /* End of function mtr_act_init */

/***********************************************************************************************************************
* @fn             mtr_act_error
* @brief          Executes the post-processing (include stopping the PWM output) when an error has been detected
* @param[in]      st_stm     The pointer to the state machine structure
* @param[in]      p_params   The pointer to the FOC data
* @return         The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t mtr_act_error(st_mtr_statemachine_t *st_stm, void *p_params)
{
    FSP_PARAMETER_NOT_USED(st_stm);
    FSP_PARAMETER_NOT_USED(p_params);

    R_MTR_GPT_THREE_PHASE_DisableOutputAll(g_three_phase0.p_ctrl);    /* PWM output disable */

    return (0);
} /* End of function mtr_act_error */


/***********************************************************************************************************************
* @fn             RM_MTR_ControlInit
* @brief          Initializes FOC motor controller by given motor ID
* @return         None
***********************************************************************************************************************/
void RM_MTR_ControlInit(void)
{
    /* Initialize system state machine */
    mtr_statemachine_init(&g_st_foc_common.st_foc_carrier.st_stm);
} /* End of function RM_MTR_ControlInit */

/***********************************************************************************************************************
* @fn             RM_MTR_EventExec
* @brief          Execute event of FOC control
* @param[in]      u1_event   the event index
* @return         None
***********************************************************************************************************************/
void RM_MTR_EventExec(uint8_t u1_event)
{
    mtr_statemachine_event(&g_st_foc_common.st_foc_carrier.st_stm, &g_st_foc_common, u1_event);
} /* End of function RM_MTR_EventExec */

/***********************************************************************************************************************
* @fn             RM_MTR_CapacitorCharge
* @brief          Wait for charging capacitor
* @return         Charge capacitor timeout error
* @retval         ERROR_NONE                No error
* @retval         ERROR_CHARGE_CAP_TIMEOUT  Timeout error has occurred
***********************************************************************************************************************/
uint16_t RM_MTR_CapacitorCharge(void)
{
    uint16_t i;

    uint16_t u2_charge_cap_error;
    uint16_t u2_charge_cap_cnt   = 0;
    int32_t  s4_thrsld;

    u2_charge_cap_error        = MTR_ERROR_NONE;
    g_st_foc_common.st_foc_carrier.u1_flg_charge_cap = MTR_CLR;

    s4_thrsld = FIX_fromfloat(MTR_MCU_ON_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

    /* wait until Vdc exceeds MCU power on voltage */
    while (s4_thrsld > g_st_foc_common.s4_ad_vdc)
    {
        R_WDT_Refresh(g_wdt0.p_ctrl);                       /* watch dog timer clear */

        for (i = 0; i < MTR_WAIT_CNT_300US; i++)                           /* wait about 300 us */
        {
            __NOP();
        }

        u2_charge_cap_cnt++;

        if (u2_charge_cap_cnt > MTR_CHARGE_CAP_WAIT_CNT)
        {
            u2_charge_cap_error = MTR_ERROR_CHARGE_CAP_TIMEOUT;
            break;
        }
    }
    
    g_st_foc_common.st_foc_carrier.u1_flg_charge_cap = MTR_SET;

    return (u2_charge_cap_error);
} /* End of function RM_MTR_CapacitorCharge */

/***********************************************************************************************************************
* @fn             RM_MTR_SpeedSet
* @brief          Set speed reference for board UI
* @param[in]      s4_ref_speed_rpm       Speed reference[rpm]
* @param[in]      s4_ref_min_speed_rpm   Minimum speed reference[rpm]
* @return         Stop request flag
* @retval         MTR_CLR  Stop request flag clear
* @retval         MTR_SET  Stop request flag set
***********************************************************************************************************************/
uint8_t RM_MTR_SpeedSet(int32_t s4_ref_speed_rpm, int32_t s4_ref_min_speed_rpm)
{
    int32_t s4_temp = 0;

    s4_temp = s4_ref_speed_rpm;
    if ((s4_ref_min_speed_rpm > s4_temp) && ((-s4_ref_min_speed_rpm) < s4_temp))
    {
        g_s2_cnt++;
        if (g_s2_cnt >= 100)
        {
            s4_temp       = 0;
            g_u1_stop_req = MTR_SET;
            g_s2_cnt      = 100;
        }
    }
    else
    {
        g_s2_cnt--;
        if (g_s2_cnt <= 0)
        {
            g_u1_stop_req = MTR_CLR;
            g_s2_cnt      = 0;
        }
    }

    g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed = FIX_fromfloat((float)s4_temp * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    if (s4_temp < 0)
    {
        g_st_foc_common.st_foc_speed.st_asr.s1_ref_dir = MTR_CCW;
    }
    else
    {
        g_st_foc_common.st_foc_speed.st_asr.s1_ref_dir = MTR_CW;
    }

    return (g_u1_stop_req);
} /* End of function RM_MTR_SpeedSet */

/***********************************************************************************************************************
* @fn             RM_MTR_SpeedGet
* @brief          Get speed value
* @return         Speed [rpm]
***********************************************************************************************************************/
uint32_t RM_MTR_SpeedGet(void)
{
    return ((uint32_t)fabsf(FIX_tofloat(g_st_foc_common.st_foc_speed.st_asr.s4_speed * PU_SF_RAD_RPM, MTR_Q_AFREQ)));
} /* End of function RM_MTR_SpeedGet */

/***********************************************************************************************************************
* @fn             RM_MTR_DirSet
* @brief          Set rotation direction
* @param[in]      s1_dir   Rotation direction
* @return         None
***********************************************************************************************************************/
void RM_MTR_DirSet(int8_t s1_dir)
{
    g_st_foc_common.st_foc_speed.st_asr.s1_ref_dir = s1_dir;
    if (MTR_CW == s1_dir)
    {
        g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed
                = (int32_t)(abs(g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed));
    }
    else if (MTR_CCW == s1_dir)
    {
        g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed
                = (int32_t)(-abs(g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed));
    }
    else
    {
        __NOP(); /* Do nothing */
    }
} /* End of function RM_MTR_DirSet */

/***********************************************************************************************************************
* @fn             RM_MTR_DirGet
* @brief          Get current rotation direction
* @return         Current rotation direction
***********************************************************************************************************************/
uint8_t RM_MTR_DirGet(void)
{
    return ((uint8_t)(g_st_foc_common.s1_direction));
} /* End of function RM_MTR_DirGet */

/***********************************************************************************************************************
* @fn             RM_MTR_StatusGet
* @brief          Get status of motor control system
* @return         Motor status
***********************************************************************************************************************/
uint8_t RM_MTR_StatusGet(void)
{
    return (mtr_statemachine_get_status(&g_st_foc_common.st_foc_carrier.st_stm));
} /* End of function RM_MTR_StatusGet */

/***********************************************************************************************************************
* @fn             RM_MTR_StatusErrorGet
* @brief          Get status of motor error
* @return         Motor status
***********************************************************************************************************************/
uint16_t RM_MTR_StatusErrorGet(void)
{
    return (g_st_foc_common.st_foc_carrier.u2_error_status);
} /* End of function RM_MTR_StatusErrorGet */

/***********************************************************************************************************************
* @fn             RM_MTR_IcsBufferSet
* @brief          Set value to buffer
* @return         None
***********************************************************************************************************************/
void RM_MTR_IcsBufferSet(void)
{
    /* calculate gains from input parameters */
    RM_MTR_CtrlGain(&g_st_gain_buf, &g_st_ctrl_params);

    /* set trigger enable write flag */
    g_u1_trig_enable_write = MTR_SET;
} /* End of function RM_MTR_IcsBufferSet */

/***********************************************************************************************************************
* @fn             RM_MTR_VariablesSet
* @brief          Set variables
* @return         None
***********************************************************************************************************************/
void RM_MTR_VariablesSet(void)
{
    /* rotation direction */
    g_st_foc_common.st_foc_speed.st_asr.s1_ref_dir = st_ics.s1_ref_direction;

    /* Copy motor parameters from ICS buffer */
    g_st_foc_common.st_foc_carrier.st_motor = st_ics.st_motor;

    /* reference speed */
    g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed = st_ics.s4_ref_speed;
    if (MTR_CCW == g_st_foc_common.st_foc_speed.st_asr.s1_ref_dir)
    {
        g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed = -g_st_foc_common.st_foc_speed.st_asr.s4_ref_speed;
    }

    /* current offset calculation time */
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    g_st_foc_common.st_foc_carrier.st_tscs.u4_offset_calc_cnt = st_ics.u2_cnt_offset_calc;
#endif
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    g_st_foc_common.st_foc_carrier.st_sscs.u4_offset_calc_cnt = st_ics.u2_cnt_offset_calc;
#endif

    /* limit of speed change */
    g_st_foc_common.st_foc_speed.st_asr.s4_lim_ramp_speed = st_ics.s4_lim_accel;

    /* max speed */
    g_st_foc_common.st_foc_speed.st_asr.s4_max_speed = st_ics.s4_max_speed;

    /* speed to start increasing id */
    g_st_foc_common.st_foc_speed.st_asr.s4_th_cl2ol_speed = st_ics.s4_th_speed_cl2ol;

    /* speed to start decreasing id */
    g_st_foc_common.st_foc_speed.st_asr.s4_th_ol2cl_speed = st_ics.s4_th_speed_ol2cl;

    /* Id reference when low speed */
    g_st_foc_common.st_foc_carrier.st_acr.s4_ref_id_ol = st_ics.s4_ref_id_ol;

    /* Draw-in wait time count value */
    g_st_foc_common.st_foc_speed.u2_cnt_draw_in_wait_buff = (uint16_t)(st_ics.s4_cnt_wait_draw_in);

    /* q-axis pi control initial integral parameter */
    g_st_foc_common.st_foc_speed.st_asr.s4_init_intg = st_ics.s4_coef_init_intg;

    /* Limit of current value change [PU(A/ms)] */
    g_st_foc_common.st_foc_carrier.st_acr.s4_lim_ramp_current = st_ics.s4_lim_current;

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    /* For 1shunt */
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    g_st_foc_common.st_foc_carrier.st_repro_id.s4_in_k  = g_st_gain_buf.s4_k_lpf_in_i_repro;
    g_st_foc_common.st_foc_carrier.st_repro_iq.s4_in_k  = g_st_gain_buf.s4_k_lpf_in_i_repro;
#if (MTR_Q_CURRENT_REPO_LPF_CO == 15)
    if (0 == g_st_foc_common.st_foc_carrier.st_repro_id.s4_in_k)
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_repro_id.s4_out_k
                = (int16_t)((uint16_t)(1 << MTR_Q_CURRENT_REPO_LPF_CO) - 1);

        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_repro_iq.s4_out_k
                = (int16_t)((uint16_t)(1 << MTR_Q_CURRENT_REPO_LPF_CO) - 1);
    }
    else
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_repro_id.s4_out_k = (int16_t)((uint16_t)(1 << MTR_Q_CURRENT_REPO_LPF_CO)
                                    - g_st_foc_common.st_foc_carrier.st_repro_id.s4_in_k);

        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_repro_iq.s4_out_k = (int16_t)((uint16_t)(1 << MTR_Q_CURRENT_REPO_LPF_CO)
                                    - g_st_foc_common.st_foc_carrier.st_repro_iq.s4_in_k);
    }
#else
    g_st_foc_common.st_foc_carrier.st_repro_id.s4_out_k
            = (1 << MTR_Q_CURRENT_REPO_LPF_CO) - g_st_foc_common.st_foc_carrier.st_repro_id.s4_in_k;
    g_st_foc_common.st_foc_carrier.st_repro_iq.s4_out_k
            = (1 << MTR_Q_CURRENT_REPO_LPF_CO) - g_st_foc_common.st_foc_carrier.st_repro_iq.s4_in_k;
#endif
#endif
#if (MOD_2PH_BOT == MOD_METHOD)
    g_st_foc_common.st_foc_carrier.st_sscs.s4_mod_3ph2ph_speed_rad    = st_ics.s4_mod_3ph2ph_speed_rad;
    g_st_foc_common.st_foc_carrier.st_sscs.s4_mod_2ph3ph_speed_rad    = st_ics.s4_mod_2ph3ph_speed_rad;
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt_3ph  = st_ics.s2_ad_point_a_adj_cnt_3ph;
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt_3ph  = st_ics.s2_ad_point_b_adj_cnt_3ph;
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt_2ph  = st_ics.s2_ad_point_a_adj_cnt_2ph;
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt_2ph  = st_ics.s2_ad_point_b_adj_cnt_2ph;
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt      = st_ics.s2_ad_point_a_adj_cnt_3ph;
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt      = st_ics.s2_ad_point_b_adj_cnt_3ph;
#else
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_a_adj_cnt      = st_ics.s2_ad_point_a_adj_cnt;
    g_st_foc_common.st_foc_carrier.st_sscs.s2_ad_point_b_adj_cnt      = st_ics.s2_ad_point_b_adj_cnt;
#endif
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */
#if (MOD_2PH_BOT == MOD_METHOD)
    g_st_foc_common.st_foc_carrier.st_mod.s2_cnt_2ph_bot_change = st_ics.s2_mod_2ph_bot_change_cnt;
#endif


    /* Reciprocal of Back-EMF constant */
    g_st_foc_common.st_foc_carrier.st_phe.s4_coef_reci_ke
                    = FIX_fromfloat(1.0f / FIX_tofloat(st_ics.st_motor.s4_mtr_ke, MTR_Q_BEMF_CONST), MTR_Q_RECIM);

    /* Apply PI gain */
    g_st_foc_common.st_foc_carrier.st_acr.st_pi_id.s4_kp       = g_st_gain_buf.st_pi_acr_id.s4_kp;
    g_st_foc_common.st_foc_carrier.st_acr.st_pi_id.s4_kidt     = g_st_gain_buf.st_pi_acr_id.s4_kidt;
    g_st_foc_common.st_foc_carrier.st_acr.st_pi_id.s4_max_intg = g_st_gain_buf.st_pi_acr_id.s4_max_intg;
    g_st_foc_common.st_foc_carrier.st_acr.st_pi_iq.s4_kp       = g_st_gain_buf.st_pi_acr_iq.s4_kp;
    g_st_foc_common.st_foc_carrier.st_acr.st_pi_iq.s4_kidt     = g_st_gain_buf.st_pi_acr_iq.s4_kidt;
    g_st_foc_common.st_foc_carrier.st_acr.st_pi_iq.s4_max_intg = g_st_gain_buf.st_pi_acr_iq.s4_max_intg;
    g_st_foc_common.st_foc_speed.st_asr.st_pi.s4_kp            = g_st_gain_buf.st_pi_asr.s4_kp;
    g_st_foc_common.st_foc_speed.st_asr.st_pi.s4_kidt          = g_st_gain_buf.st_pi_asr.s4_kidt;
    g_st_foc_common.st_foc_speed.st_asr.st_pi.s4_max_intg      = g_st_gain_buf.st_pi_asr.s4_max_intg;
    g_st_foc_common.st_foc_speed.st_asr.s4_lim_asr_err         = g_st_gain_buf.s4_lim_asr_err;

    /* Apply speed estimate PLL gain */
    g_st_foc_common.st_foc_carrier.st_pll.st_pi.s4_kp       = g_st_gain_buf.st_pi_pll.s4_kp;
    g_st_foc_common.st_foc_carrier.st_pll.st_pi.s4_kidt     = g_st_gain_buf.st_pi_pll.s4_kidt;
    g_st_foc_common.st_foc_carrier.st_pll.st_pi.s4_max_intg = g_st_gain_buf.st_pi_pll.s4_max_intg;

    /* calculate the terms related to friction */
    g_st_foc_common.st_foc_speed.st_asr.s4_coef_d0_div_pm  = g_st_gain_buf.s4_coef_d0_div_pm;
    g_st_foc_common.st_foc_speed.st_asr.s4_coef_d1_div_p2m = g_st_gain_buf.s4_coef_d1_div_p2m;

    /* Apply LPF coefficient */
#if (USE_SPEED_LPF == MTR_SET)
    g_st_foc_common.st_foc_speed.st_asr.st_lpf.s4_in_k     = g_st_gain_buf.s4_k_lpf_in_asr;
#if (MTR_Q_SPEED_LPF_CO == 31)
    if (0 == g_st_foc_common.st_foc_speed.st_asr.st_lpf.s4_in_k)
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_speed.st_asr.st_lpf.s4_out_k = (int32_t)((uint32_t)(1 << MTR_Q_SPEED_LPF_CO) - 1);
    }
    else
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_speed.st_asr.st_lpf.s4_out_k = (int32_t)((1 << MTR_Q_SPEED_LPF_CO)
                - g_st_foc_common.st_foc_speed.st_asr.st_lpf.s4_in_k);
    }
#else
    g_st_foc_common.st_foc_speed.st_asr.st_lpf.s4_out_k
            = (1 << MTR_Q_SPEED_LPF_CO) - g_st_foc_common.st_foc_speed.st_asr.st_lpf.s4_in_k;
#endif
#endif
#if (USE_CURRENT_LPF_ID == MTR_SET)
    g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf.s4_in_k  = g_st_gain_buf.s4_k_lpf_in_acr;
#if (MTR_Q_CURRENT_LPF_CO == 31)
    if (0 == g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf.s4_in_k)
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf.s4_out_k
                = (int32_t)((uint32_t)(1 << MTR_Q_CURRENT_LPF_CO) - 1);
    }
    else
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf.s4_out_k = (int32_t)((1 << MTR_Q_CURRENT_LPF_CO)
                - g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf.s4_in_k);
    }
#else
        g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf.s4_out_k
                = (1 << MTR_Q_CURRENT_LPF_CO) - g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf.s4_in_k;
#endif
#endif
#if (USE_CURRENT_LPF_IQ == MTR_SET)
    g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf.s4_in_k  = g_st_gain_buf.s4_k_lpf_in_acr;
#if (MTR_Q_CURRENT_LPF_CO == 31)
    if (0 == g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf.s4_in_k)
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf.s4_out_k
                = (int32_t)((uint32_t)(1 << MTR_Q_CURRENT_LPF_CO) - 1);
    }
    else
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf.s4_out_k = (int32_t)((1 << MTR_Q_CURRENT_LPF_CO)
                - g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf.s4_in_k);
    }
#else
    g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf.s4_out_k
            = (1 << MTR_Q_CURRENT_LPF_CO) - g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf.s4_in_k;
#endif
#endif
#if (USE_OPENLOOP_DAMPING == MTR_SET)
    g_st_foc_common.st_foc_speed.st_ol2cl.st_damp.s4_k                = g_st_gain_buf.s4_k_damp;
    g_st_foc_common.st_foc_speed.st_ol2cl.st_damp.st_hpf.s4_k         = g_st_gain_buf.s4_k_hpf_in_damp;
    g_st_foc_common.st_foc_speed.st_ol2cl.st_damp.s4_speed_lim_rate = st_ics.s4_speed_limit_rate;
#endif
#if (USE_OL2CL_CTRL == MTR_SET)
    g_st_foc_common.st_foc_speed.st_ol2cl.s4_k0_angle2current           = g_st_gain_buf.s4_k0_ol2cl_theta2current;
    g_st_foc_common.st_foc_speed.st_ol2cl.s4_k1_angle2current           = g_st_gain_buf.s4_k1_ol2cl_theta2current;

    /* switch_cnt is unsigned integer */
    g_st_foc_common.st_foc_speed.st_ol2cl.u2_cnt_switch
            = (uint16_t)(g_st_ctrl_params.f4_ol2cl_switch_time
            / g_st_ctrl_params.st_macro.f4_dt_speed);

    /* limit_current is signed integer */
    g_st_foc_common.st_foc_speed.st_ol2cl.s4_lim_ramp_i
            = (int32_t)((uint32_t)g_st_foc_common.st_foc_carrier.st_acr.s4_ref_id_ol
            / g_st_foc_common.st_foc_speed.st_ol2cl.u2_cnt_switch);
    g_st_foc_common.st_foc_speed.st_phase_err_lpf.s4_in_k                   = g_st_gain_buf.s4_k_lpf_in_pherr;
#if (MTR_Q_PHERR_LPF_CO == 31)
    if (0 == g_st_foc_common.st_foc_speed.st_phase_err_lpf.s4_in_k)
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_speed.st_phase_err_lpf.s4_out_k
                = (int32_t)((uint32_t)(1 << MTR_Q_PHERR_LPF_CO) - 1);
    }
    else
    {
        /* out_k is signed integer */
        g_st_foc_common.st_foc_speed.st_phase_err_lpf.s4_out_k
                = (int32_t)((1 << MTR_Q_PHERR_LPF_CO) - g_st_foc_common.st_foc_speed.st_phase_err_lpf.s4_in_k);
    }
#else
    g_st_foc_common.st_foc_carrier.st_phase_err_lpf.s4_out_k
            = (1 << MTR_Q_PHERR_LPF_CO) - g_st_foc_common.st_foc_carrier.st_phase_err_lpf.s4_in_k;
#endif
#endif /* (USE_OL2CL_CTRL == MTR_SET) */

} /* End of function RM_MTR_VariablesSet */

/***********************************************************************************************************************
* @fn             RM_MTR_InputBuffParamReset
* @brief          Reset input buffer variables when motor control reset
* @return         None
***********************************************************************************************************************/
void RM_MTR_InputBuffParamReset(void)
{
    /* Initialize members of ICS input buffer structure */
    st_ics.s1_ref_direction            = MTR_CW;
    st_ics.u2_cnt_offset_calc      = CP_OFFSET_CALC_CNT;
    st_ics.s4_ref_speed        = 0;
    st_ics.s4_lim_accel = FIX_fromfloat(CP_RAMP_LIMIT_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    st_ics.s4_max_speed        = FIX_fromfloat(CP_MAX_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    st_ics.s4_th_speed_cl2ol      = FIX_fromfloat(CP_CL2OL_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    st_ics.s4_th_speed_ol2cl      = FIX_fromfloat(CP_OL2CL_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    st_ics.s4_ref_id_ol            = FIX_fromfloat(CP_OL_REF_ID * PU_SF_CURRENT, MTR_Q_CURRENT);
    st_ics.s4_cnt_wait_draw_in     = MTR_DRAW_IN_WAIT_CNT;
    st_ics.s4_coef_init_intg            = FIX_fromfloat(CP_INIT_ASR_INTEG, MTR_Q_CURRENT);
    st_ics.s4_lim_current   = FIX_fromfloat(CP_RAMP_LIMIT_CURRENT * PU_SF_CURRENT, MTR_Q_CURRENT);
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if ((MOD_3PH_SPWM == MOD_METHOD) || (MOD_3PH_TOW == MOD_METHOD))
    st_ics.s2_ad_point_a_adj_cnt   = CP_AD_POINT_A_ADJ_CNT;
    st_ics.s2_ad_point_b_adj_cnt   = CP_AD_POINT_B_ADJ_CNT;
#elif (MOD_2PH_BOT == MOD_METHOD)
    st_ics.s4_mod_3ph2ph_speed_rad     = FIX_fromfloat(CP_MOD_3PH2PH_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    st_ics.s4_mod_2ph3ph_speed_rad     = FIX_fromfloat(CP_MOD_2PH3PH_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    st_ics.s2_ad_point_a_adj_cnt_3ph   = CP_AD_POINT_A_ADJ_CNT;
    st_ics.s2_ad_point_b_adj_cnt_3ph   = CP_AD_POINT_B_ADJ_CNT;
    st_ics.s2_ad_point_a_adj_cnt_2ph   = CP_AD_POINT_A_ADJ_2PH_CNT;
    st_ics.s2_ad_point_b_adj_cnt_2ph   = CP_AD_POINT_B_ADJ_2PH_CNT;
#endif
#endif
    st_ics.s2_mod_2ph_bot_change_cnt = CP_MOD_2PH_BOT_CHANGE_CNT;

#if (USE_OPENLOOP_DAMPING == MTR_SET)
    st_ics.s4_speed_limit_rate       = FIX_fromfloat(CP_DAMP_SPEED_LIMIT_RATE, MTR_Q_DAMP_SL_RATE);
#endif

    st_ics.st_motor.s4_mtr_r       = FIX_fromfloat(MP_RESISTANCE * PU_SF_RES, MTR_Q_RESISTANCE);
    st_ics.st_motor.s4_mtr_ld      = FIX_fromfloat(MP_D_INDUCTANCE * PU_SF_IND, MTR_Q_INDUCTANCE);
    st_ics.st_motor.s4_mtr_lq      = FIX_fromfloat(MP_Q_INDUCTANCE * PU_SF_IND, MTR_Q_INDUCTANCE);
    st_ics.st_motor.s4_mtr_ke      = FIX_fromfloat(MP_BEMF_CONSTANT * PU_SF_BEMF_CONST, MTR_Q_BEMF_CONST);
    st_ics.st_motor.s4_mtr_j       = FIX_fromfloat(MP_ROTOR_INERTIA * PU_SF_INERTIA, MTR_Q_INERTIA);
    st_ics.st_motor.u2_mtr_pp      = MP_POLE_PAIRS;

    g_st_ctrl_params.st_com.f4_acr_nf_hz      = CP_ACR_NF_HZ;
    g_st_ctrl_params.st_com.f4_asr_nf_hz      = CP_ASR_NF_HZ;
    g_st_ctrl_params.st_com.f4_acr_lpf_cof_hz = CP_ACR_LPF_COF_HZ;
    g_st_ctrl_params.st_com.f4_asr_lpf_cof_hz = CP_ASR_LPF_COF_HZ;
    g_st_ctrl_params.st_com.f4_asr_ki_aug     = CP_ASR_KI_AUG;
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    g_st_ctrl_params.f4_i_repro_cof_hz = CP_I_REPRO_COF_HZ;
#endif
    g_st_ctrl_params.st_com.f4_asr_deadband_lsb = CP_ASR_DEADBAND_LSB;
    g_st_ctrl_params.st_com.f4_acr_deadband_lsb = CP_ACR_DEADBAND_LSB;
    g_st_ctrl_params.st_com.f4_pll_deadband_lsb = CP_PLL_DEADBAND_LSB;
    g_st_ctrl_params.st_com.f4_pll_nf_hz        = CP_PLL_NF_HZ;
    g_st_ctrl_params.st_macro.f4_dt               = MTR_CTRL_PERIOD * PU_SF_TIME;
    g_st_ctrl_params.st_macro.f4_dt_speed         = MTR_SPEED_CTRL_PERIOD * PU_SF_TIME;
    g_st_ctrl_params.f4_ol_ref_id        = CP_OL_REF_ID * PU_SF_CURRENT;
    g_st_ctrl_params.f4_ol2cl_speed      = CP_OL2CL_SPEED_RPM * PU_SF_RPM_RAD;
    g_st_ctrl_params.f4_ramp_limit_speed = CP_RAMP_LIMIT_SPEED_RPM * PU_SF_RPM_RAD * PU_SF_AFREQ * 1000;
    g_st_ctrl_params.f4_damp_hpf_cof_hz  = CP_DAMP_HPF_COF_HZ;
    g_st_ctrl_params.f4_damp_zeta        = CP_DAMP_ZETA;
    g_st_ctrl_params.st_macro.f4_pu_sf_afreq      = PU_SF_AFREQ;
    g_st_ctrl_params.st_macro.u1_q_acr_kp         = MTR_Q_ACR_KP;
    g_st_ctrl_params.st_macro.u1_q_acr_kidt       = MTR_Q_ACR_KIDT;
    g_st_ctrl_params.st_macro.u1_q_acr_deadband   = (MTR_Q_ACR_KIDT - MTR_Q_VOLTAGE) + MTR_Q_CURRENT;
    g_st_ctrl_params.st_macro.u1_q_asr_kp         = MTR_Q_ASR_KP;
    g_st_ctrl_params.st_macro.u1_q_asr_kidt       = MTR_Q_ASR_KIDT;
    g_st_ctrl_params.st_macro.u1_q_asr_deadband   = (MTR_Q_ASR_KIDT - MTR_Q_CURRENT) + MTR_Q_AFREQ;
    g_st_ctrl_params.st_macro.u1_q_pll_kp         = MTR_Q_PLL_KP;
    g_st_ctrl_params.st_macro.u1_q_pll_kidt       = MTR_Q_PLL_KIDT;
    g_st_ctrl_params.st_macro.u1_q_pll_deadband   = (MTR_Q_PLL_KIDT - MTR_Q_AFREQ) + MTR_Q_ANGLE;
    g_st_ctrl_params.st_macro.u1_q_asr_lpf_k      = MTR_Q_SPEED_LPF_CO;
    g_st_ctrl_params.st_macro.u1_q_acr_lpf_k      = MTR_Q_CURRENT_LPF_CO;

    g_st_ctrl_params.f4_d0_div_pm
            = (MP_FRICTION_0TH_ORDER / (MP_POLE_PAIRS * MP_BEMF_CONSTANT)) * PU_SF_CURRENT;
    g_st_ctrl_params.f4_d1_div_p2m
            = (MP_FRICTION_1ST_ORDER / (MP_POLE_PAIRS * MP_POLE_PAIRS * MP_BEMF_CONSTANT)) * PU_SF_D1_DIV_P2M;
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    g_st_ctrl_params.st_macro.u1_q_i_repro_lpf_k    = MTR_Q_CURRENT_REPO_LPF_CO;
#endif
#if (USE_OPENLOOP_DAMPING == MTR_SET)
    g_st_ctrl_params.st_macro.u1_q_damp_k       = MTR_Q_DAMP_K;
    g_st_ctrl_params.st_macro.u1_q_damp_hpf_k   = MTR_Q_DAMP_HPF_CO;
#endif
#if (USE_OL2CL_CTRL == MTR_SET)
    g_st_ctrl_params.f4_ol2cl_switch_time  = CP_OL2CL_SWITCH_TIME * PU_SF_TIME;
    g_st_ctrl_params.st_macro.u1_q_ol2cl_current_k1 = MTR_Q_OL2CL_K1;
    g_st_ctrl_params.st_macro.u1_q_pherr_lpf_k      = MTR_Q_PHERR_LPF_CO;
#endif


    RM_MTR_CtrlGain(&g_st_gain_buf, &g_st_ctrl_params);

    /* initialize write enable switch */
    g_u1_trig_enable_write = 0;
} /* End of function RM_MTR_InputBuffParamReset */

/***********************************************************************************************************************
* @fn             RM_MTR_UpdatePollingSet
* @brief          Polling u1_trig_enable_write to update configurations and commands
* @return         None
***********************************************************************************************************************/
void RM_MTR_UpdatePollingSet(void)
{
    /*** set variables ***/
    if (MTR_SET == g_u1_trig_enable_write)
    {
        RM_MTR_VariablesSet();
        g_u1_trig_enable_write = MTR_CLR;
    }
} /* End of function RM_MTR_UpdatePollingSet */
