/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_common.h
* Description : This header includes common definitions
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/
/* guard against multiple inclusion */
#ifndef RM_MTR_COMMON_H
#define RM_MTR_COMMON_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>

/**********************************************************************************************************************
* Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* value for calculation */
#define     MTR_TWOPI                   (2 * 3.14159265f)               /* 2 * pi */
#define     MTR_SQRT_3                  (1.7320508f)                    /* sqrt(3) */

/* rotational direction */
#define     MTR_CW                      (1)
#define     MTR_CCW                     (-1)

#define     MTR_ON                      (0)                             /* active level of SW */
#define     MTR_OFF                     (1)                             /* inactive level of SW */

/* flag state */
#define     MTR_CLR                     (0)                             /* for flag clear */
#define     MTR_SET                     (1)                             /* for flag set */

/* control loop flag */
#define     MTR_OPL                     (0)                             /* Open-loop */
#define     MTR_CLL                     (1)                             /* Closed-loop */

/* draw-in flag */
#define     MTR_UNREACHED               (0)                             /* Unreached flag */
#define     MTR_REACHED                 (1)                             /* reached flag */

/* NOP wait cnt */
#define     MTR_WAIT_CNT_300US          (1500)                          /* wait 300us */

/* ADC bit */
#define     MTR_ADC_12BIT               (12)                            /* 12 bit ADC */

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/

/* 1st order LPF structure , the transfer function is out(n) = in_k * input(n) + out_k * output(n-1) */
typedef struct{
    int32_t       s4_in_k;                 /* Proportion of current input to output */
    int32_t       s4_out_k;                /* Proportion of previous output to output */
    int32_t       s4_pre_out;              /* Previous output value of LPF */
} st_mtr_lpf1_t;

/* 1st order HPF structure , the transfer function is output(n) = k * input(n) - k * input(n-1) + k * output(n-1)*/
typedef struct
{
    int32_t       s4_k;                    /* Proportion of input */
    int32_t       s4_pre_in;               /* Previous input value of HPF */
    int32_t       s4_pre_out;              /* Previous output value of HPF */
    uint8_t       u1_q_k;                  /* Q-format of HPF */
} st_mtr_hpf1_t;

#endif /* RM_MTR_COMMON_H */
