/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_foc_less_speed.h
* Description : Definitions of sensor-less FOC
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef RM_MTR_FOC_LESS_SPEED_H
#define RM_MTR_FOC_LESS_SPEED_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_common.h"
#include "rm_mtr_est_phase_err.h"
#include "rm_mtr_parameter.h"
#include "rm_mtr_statemachine.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include <stdint.h>
#include "r_mtr_config.h"
#include "r_mtr_ra2t1.h"


#if (USE_OL2CL_CTRL == MTR_SET) || (USE_OPENLOOP_DAMPING == MTR_SET)
#include "rm_mtr_ol2cl_ctrl.h"
#endif


/***********************************************************************************************************************
* Macro definitions for sequence control
***********************************************************************************************************************/

/* error status */
#define     MTR_ERROR_NONE              (0x0000)
#define     MTR_ERROR_OVER_CURRENT_HW   (0x0001)
#define     MTR_ERROR_OVER_VOLTAGE      (0x0002)
#define     MTR_ERROR_OVER_SPEED        (0x0004)
#define     MTR_ERROR_HALL_TIMEOUT      (0x0008)
#define     MTR_ERROR_BEMF_TIMEOUT      (0x0010)
#define     MTR_ERROR_HALL_PATTERN      (0x0020)
#define     MTR_ERROR_BEMF_PATTERN      (0x0040)
#define     MTR_ERROR_UNDER_VOLTAGE     (0x0080)
#define     MTR_ERROR_OVER_CURRENT_SW   (0x0100)
#define     MTR_ERROR_CHARGE_CAP_TIMEOUT (0x0400)
#define     MTR_ERROR_UNKNOWN           (0xffff)

/* Id reference status */
#define     MTR_ID_ZERO_CONST           (0)
#define     MTR_ID_MANUAL               (1)
#define     MTR_ID_MTPA2FW              (2)

/* Iq reference status */
#define     MTR_IQ_ZERO_CONST           (0)
#define     MTR_IQ_MANUAL               (1)
#define     MTR_IQ_OL2CL                (2)
#define     MTR_IQ_SPEED_PI_OUTPUT      (3)

/* speed reference status */
#define     MTR_SPEED_ZERO_CONST        (0)
#define     MTR_SPEED_MANUAL            (1)

/* Drive mode status */
#define     MTR_STOP                    (0x00)
#define     MTR_DRIVE                   (0x81)
#define     MTR_DRIVE_INIT              (0x82)
#define     MTR_DRIVE_START             (0x83)
#define     MTR_OFFSET_CALC_EXE         (0x84)
#define     MTR_DRIVE_END               (0x01)
#define     MTR_MASK_RUN_MODE           (0x80)

#define     MTR_CTRL_NONE                 (0x00)
#define     MTR_CTRL_OPL_DRAWIN           (0x01)
#define     MTR_CTRL_OPL_FORCE_SYNC       (0x02)
#define     MTR_CTRL_OPL_OPL2CLL          (0x03)
#define     MTR_CTRL_OPL_CLL2OPL          (0x04)
#define     MTR_CTRL_OPL_FORCE_SYNC_ACCEL (0x05)
#define     MTR_CTRL_CLL_OPL2CLL          (0x80)
#define     MTR_CTRL_CLL_SPEED_CTRL       (0x81)

#define     MTR_DRIVE_OPL               (0x00)
#define     MTR_DRIVE_CLL               (0x80)


/* Three phase status */
#define     MTR_PHASE_U         (0)
#define     MTR_PHASE_V         (1)
#define     MTR_PHASE_W         (2)

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/* modulation drive pattern */
#define     MTR_DRV_UVW                 (1)      /* U>V>W */
#define     MTR_DRV_UWV                 (2)      /* U>W>V */
#define     MTR_DRV_VUW                 (3)      /* V>U>W */
#define     MTR_DRV_VWU                 (4)      /* V>W>U */
#define     MTR_DRV_WUV                 (5)      /* W>U>V */
#define     MTR_DRV_WVU                 (6)      /* W>V>U */

#define     MTR_DRV_MASK                (0x0F)   /* Mask of modulation drive pattern */
#define     MTR_DRV_CURRENT_UNAVAILABLE (0x10)   /* Flag of current unavailable */
#define     MTR_DRV_DUTY_SHIFT_RUN      (0x20)   /* Flag of Duty-Shift run */
#define     MTR_DRV_PWM_SHIFT_RUN       (0x40)   /* Flag of Duty-Shift run */

#define     MTR_CROSS_MID_MIN           (1)      /* Duty cross for middle and minimum */
#define     MTR_CROSS_MAX_MID           (2)      /* Duty cross for maximum and middle */
#endif

/* PWM shift */
#define MTR_PWM_SHIFT_TIMER_HALF     ((uint16_t)(MTR_CARRIER_CNT)) /* Triangle wave one-sided count *MTR_CARRIER_CNT is the maximum count value of the carrier waveform */
#define MTR_PWM_SHIFT_DEADTIME       ((uint16_t)(MTR_DEADTIME_CNT))
#define MTR_PWM_SHIFT_AD_CONVERT_CNT ((uint16_t)(MTR_PWM_TIMER_FREQ * CP_AD_CONVERSION_TIME))
#define MTR_PWM_SHIFT_TIMER_SET_100  ((uint16_t)(0))
#define MTR_PWM_SHIFT_TIMER_NEAR_100 ((uint16_t)(MTR_DEADTIME_CNT))
#define MTR_PWM_SHIFT_TIMER_NEAR_0   ((uint16_t)(MTR_CARRIER_CNT))
#define MTR_PWM_SHIFT_TIMER_SET_0    ((uint16_t)(MTR_CARRIER_CNT + MTR_DEADTIME_CNT))

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/

/* PI controller parameter structure */
typedef struct{
    int32_t       s4_kp;                   /* Proportional gain */
    int32_t       s4_kidt;                 /* Integral gain multiply sampling period */
    int32_t       s4_max_intg;             /* Integral part saturation limit (symmetric) */
    int32_t       s4_min_intg;             /* Integral part saturation limit (asymmetric) */
    int32_t       s4_decimal;              /* Stored decimal part */
} st_mtr_pi_t;

/* Auto current regulator parameter structure */
typedef struct{
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    uint8_t       u1_flg_err_zero;         /* current error zero flag */
#endif

    int32_t       s4_ref_id;               /* command d-axis current value for current PI control [PU(A)] */
    int32_t       s4_ref_iq;               /* command q-axis current value for current PI control [PU(A)] */
    int32_t       s4_ref_id_ol;            /* d-axis current command value in open loop mode [PU(A)] */
    int32_t       s4_lim_ramp_current;     /* Limit of current value change [PU(A/ms)] */

    int32_t       s4_ref_vd_pre;           /* Previous value of d-axis voltage [PU(V)] */
    int32_t       s4_ref_vq_pre;           /* Previous value of q-axis voltage [PU(V)] */

    int32_t       s4_ref_vd_buffer;        /* Buffer value of d-axis voltage [PU(V)] */
    int32_t       s4_ref_vq_buffer;        /* Buffer value of q-axis voltage [PU(V)] */

#if  (USE_CURRENT_LPF_IQ == MTR_SET)
    st_mtr_lpf1_t st_ad_iq_lpf;            /* Current LPF structure */
#endif
#if (USE_CURRENT_LPF_ID == MTR_SET)
    st_mtr_lpf1_t st_ad_id_lpf;            /* Current LPF structure */
#endif

    st_mtr_pi_t   st_pi_id;                /* D-axis current PI control structure */
    st_mtr_pi_t   st_pi_iq;                /* Q-axis current PI control structure */
} st_mtr_acr_t;

/* PLL parameter structure */
typedef struct
{
    int32_t       s4_est_speed;            /* PLL calculate speed */
    st_mtr_pi_t   st_pi;                   /* PLL PI control structure */
} st_mtr_pll_t;

#if (USE_DEADTIME_COMP == MTR_SET)
/* Deadtime compensation parameter structure */
typedef struct
{
    int32_t       s4_comp_vu;               /* u-phase compensation voltage [V] */
    int32_t       s4_comp_vv;               /* v-phase compensation voltage [V] */
    int32_t       s4_comp_vw;               /* w-phase compensation voltage [V] */
} st_mtr_s4_comp_t;
#endif

/* Auto speed regulator parameter structure */
typedef struct{
    int8_t        s1_ref_dir;                /* Stored reference rotation direction */
    int32_t       s4_ref_speed;              /* Reference speed value [PU(rad/s)] */
    int32_t       s4_ref_speed_ctrl;         /* Command speed value for speed PI control[PU(rad/s)] */
    int32_t       s4_speed;                  /* Speed operation value [PU(rad/s)] */
    int32_t       s4_lim_ramp_speed;         /* Reference speed max change limit [PU(rad/s/ms)] */
    int32_t       s4_cnt_ramp_deci_sample;   /* Number of decimation counter samples acquired in the speed change step */
    int32_t       s4_max_speed;              /* Maximum speed command value [PU(rad/s)] */
    int32_t       s4_init_intg;              /* q-axis pi control initial integral parameter */
    int32_t       s4_th_cl2ol_speed;         /* Speed of switching from sensorless to open loop [PU(rad/s)] */
    int32_t       s4_th_ol2cl_speed;         /* Speed of switching from open loop to sensorless [PU(rad/s)] */
    int32_t       s4_coef_d0_div_pm;         /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    int32_t       s4_coef_d1_div_p2m;        /* (1st order fric-coef) / (Pole pairs^2 * BEMF-const) [PU(A s/rad)] */
    uint16_t      u2_cnt_cl2ol_judge_wait;   /* Waiting counter for start to judge closed-loop to open-loop */
    st_mtr_pi_t   st_pi;                     /* Speed PI control structure */
    int32_t       s4_lim_asr_err;            /* Speed PI control max error limit [PU(rad/s)] */
#if (USE_SPEED_LPF == MTR_SET)
    st_mtr_lpf1_t st_lpf;                    /* Speed LPF structure */
#endif

#if (USE_OPENLOOP_DAMPING == MTR_SET)
    int32_t       s4_ref_speed_damp_ctrl;    /* reference speed for Open-loop Damping Control */
#endif
} st_mtr_asr_t;

/* modulation structure */
typedef struct
{
    uint8_t       u1_flg_uvw_min_pattern;      /* minimum voltage pattern */
    uint8_t       u1_flg_uvw_min_pattern_pre;  /* minimum voltage pattern */
#if (MOD_2PH_BOT == MOD_METHOD)
    int16_t       s2_cnt_2ph_bot_change;       /* 2-phase modulation phase switching judgment counter */
    int32_t       s4_v_diff_sum;               /* 2-phase voltage difference for middle to minimum */
#endif
    int32_t       s4_mod_u;                    /* U-phase modulation factor  */
    int32_t       s4_mod_v;                    /* V-phase modulation factor */
    int32_t       s4_mod_w;                    /* W-phase modulation factor */
    int32_t       s4_ad_reci_vdc;              /* Reciprocal (bus voltage)/2 */
    int32_t       s4_lim_vout;                 /* Phase voltage limit value [PU(V)] */
} st_mtr_mod_t;

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
/* Three-shunt current sensing structure */
typedef struct{
    uint32_t      u4_offset_idc_adc;       /* Current A/D data offset value */
    uint32_t      u4_offset_calc_cnt;      /* Number of samples for current offset calibration */
    uint32_t      u4_offset_sample_cnt;    /* Number of samples acquired for the calibration */
    int32_t       s4_offset_iu;            /* U-phase current offset value [A] */
    int32_t       s4_offset_iv;            /* V-phase current offset value [A] */
    int32_t       s4_offset_iw;            /* W-phase current offset value [A] */
    int16_t       s2_duty_u;               /* U-phase duty */
    int16_t       s2_duty_v;               /* V-phase duty */
    int16_t       s2_duty_w;               /* W-phase duty */
    uint16_t      u2_ad_current_uph;       /* u-phase current A/D data */
    uint16_t      u2_ad_current_vph;       /* v-phase current A/D data */
    uint16_t      u2_ad_current_wph;       /* w-phase current A/D data */
} st_mtr_tscs_t;

#endif

/* SINGLE_SHUNT == CURRENT_SENS_METHOD */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/* Single-shunt current sensing structure */
typedef struct{
    uint32_t      u4_offset_calc_cnt;      /* Number of samples for current offset calibration */
    uint32_t      u4_offset_sample_cnt;    /* Number of samples acquired for the calibration */
    uint8_t       u1_drv_pattern_get;      /* PWM drive pattern to get */
    uint8_t       u1_drv_pattern_set;      /* PWM drive pattern to set */
#if (0 == TRD_SKIPPING_COUNT)
    uint8_t       u1_drv_pattern_put;      /* PWM drive pattern to put */
#endif

    uint8_t       u1_flag_mod_2ph;         /* 2-phase modulation flag */

    int16_t       s2_duty_max;             /* Buffer of maximum duty */
    int16_t       s2_duty_mid;             /* Buffer of medium duty */
    int16_t       s2_duty_min;             /* Buffer of minimum duty */
    int16_t       s2_duty_u;               /* U-phase duty */
    int16_t       s2_duty_v;               /* V-phase duty */
    int16_t       s2_duty_w;               /* W-phase duty */
    int16_t       s2_duty_max_adj;         /* Adjustment maximum duty */
    int16_t       s2_duty_mid_adj;         /* Adjustment medium duty */
    int16_t       s2_duty_min_adj;         /* Adjustment minimum duty */
    int16_t       s2_duty_max_adj_comp;    /* Adjustment compensation maximum duty */
    int16_t       s2_duty_mid_adj_comp;    /* Adjustment compensation medium duty */
    int16_t       s2_duty_min_adj_comp;    /* Adjustment compensation minimum duty */
    int16_t       s2_duty_u_adj;           /* Adjustment u phase duty */
    int16_t       s2_duty_v_adj;           /* Adjustment v phase duty */
    int16_t       s2_duty_w_adj;           /* Adjustment w phase duty */
    int16_t       s2_duty_u_adjc;          /* Adjustment compensation u phase duty */
    int16_t       s2_duty_v_adjc;          /* Adjustment compensation v phase duty */
    int16_t       s2_duty_w_adjc;          /* Adjustment compensation w phase duty */

    int16_t       s2_ad_point_a_cnt;       /* A point delay count of A/D */
    int16_t       s2_ad_point_b_cnt;       /* A point delay count of A/D */
#if (MOD_2PH_BOT == MOD_METHOD)
    int32_t       s4_mod_3ph2ph_speed_rad;  /* Speed of switching from 3-phase to 2-phase modulation */
    int32_t       s4_mod_2ph3ph_speed_rad;  /* Speed of switching from 2-phase to 3-phase modulation */
    int16_t       s2_ad_point_a_adj_cnt_2ph;/* A point delay adjustment count of A/D for 2phase modulation */
    int16_t       s2_ad_point_b_adj_cnt_2ph;/* B point delay adjustment count of A/D for 2phase modulation */
    int16_t       s2_ad_point_a_adj_cnt_3ph;/* A point delay adjustment count of A/D for 3phase modulation */
    int16_t       s2_ad_point_b_adj_cnt_3ph;/* B point delay adjustment count of A/D for 3phase modulation */
#endif
    int16_t       s2_ad_point_a_adj_cnt;   /* A point delay adjustment count of A/D */
    int16_t       s2_ad_point_b_adj_cnt;   /* B point delay adjustment count of A/D */
    int16_t       s2_ad_ss_a;              /* 1shunt A/D data of A point */
    int16_t       s2_ad_ss_b;              /* 1shunt A/D data of B point */
    int32_t       s4_offset_ia;            /* Current offset value */
    int32_t       s4_offset_ib;            /* Current offset value */

    uint16_t      u2_crnt_ad_a;           /* Current A/D data */
    uint16_t      u2_crnt_ad_b;
} st_mtr_sscs_t;
#endif /* SINGLE_SHUNT == CURRENT_SENS_METHOD */

/* Sensor-less FOC main data structure */
typedef struct{
    uint8_t                u1_flg_charge_cap;         /* Flag for capacitor charging completed */
    uint8_t                u1_flg_offset_end;         /* Complete offset flag */


    uint16_t               u2_error_status;            /* Error status */

    st_mtr_statemachine_t  st_stm;            /* Action structure */

    st_coordinate28        st_ad_i;           /* Coordinate system of ADC Current */
    st_coordinate28        st_ref_v;          /* Coordinate system of reference Voltage */
    st_coordinate28        st_ref_i;          /* Coordinate system of reference Current */
    st_mtr_parameter_t     st_motor;          /* Motor parameters structure */
    st_mtr_estimate_phe_t  st_phe;            /* estimate phase error structure */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    st_mtr_tscs_t          st_tscs;           /* Three-shunt current sensing structure */
#else
    st_mtr_sscs_t          st_sscs;           /* Single-shunt current sensing structure */
#endif

    st_mtr_acr_t           st_acr;            /* Current loop control structure */

    st_mtr_mod_t           st_mod;            /* Modulation structure */
    st_mtr_pll_t           st_pll;            /* Tracking PLL */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    st_coordinate28        st_repro_i;        /* Coordinate system of reproduct Current */
    st_mtr_lpf1_t          st_repro_iq;       /* LPF for q-axis current reproduction structure */
    st_mtr_lpf1_t          st_repro_id;       /* LPF for d-axis current reproduction structure */
#endif
} st_mtr_foc_carrier_t;

/* Sensor-less FOC main data structure for FAA */
typedef struct{
    uint8_t                u1_state_ref_id;            /* d-axis current command value management state */
    uint8_t                u1_state_ref_iq;            /* q-axis current command value management state */
    uint8_t                u1_state_ref_speed;         /* Speed command value management state */

    uint16_t               u2_cnt_draw_in_wait;        /* Draw-in wait time count value */
    uint16_t               u2_cnt_draw_in_wait_buff;   /* Draw-in wait time count value */
    uint16_t               u2_cnt_draw_in_time_calc;   /* Draw-in time counter */
    st_mtr_asr_t            st_asr;            /* Speed loop control structure */

#if (USE_OL2CL_CTRL == MTR_SET) || (USE_OPENLOOP_DAMPING == MTR_SET)
    st_mtr_ol2cl_t         st_ol2cl;             /* Open-loop to Closed-loop switch Control structure */
    st_mtr_lpf1_t          st_phase_err_lpf;     /* 1st order LPF structure */
#endif
#if (USE_OPENLOOP_DAMPING == MTR_SET)
    int32_t                s4_damp_speed;     /* Damping calculation speed for Open-loop Damping Control */
#endif

} st_mtr_foc_speed_t;

/* Common data structure for CPU */
typedef struct{
    uint8_t              u1_state_drive;   /* Drive mode state */
    uint8_t              u1_state_ctrl;    /* Drive control state */
    int8_t               s1_direction;     /* Rotation direction */
    int32_t              s4_ad_vdc;        /* Bus voltage [PU(V)] */
    int32_t              s4_phase_err_rad; /* Phase error [PU(rad)] */
    st_mtr_foc_carrier_t st_foc_carrier;   /* Carrier cycle control data */
    st_mtr_foc_speed_t   st_foc_speed;     /* Speed control data */
} st_mtr_common_foc_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : RM_MTR_FOCMotorDefaultInit
* Description   : Initializes motor drive modules with default configuration
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void RM_MTR_FOCMotorDefaultInit (st_mtr_common_foc_t *p_st_foc_common);

/***********************************************************************************************************************
* Function Name : RM_MTR_FOCMotorReset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void RM_MTR_FOCMotorReset (st_mtr_common_foc_t *p_st_foc_common);

#endif /* RM_MTR_FOC_LESS_SPEED_H */
