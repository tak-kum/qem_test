/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_carrier.c
* Description : The sequence of FOC
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_common.h"
#include "rm_mtr_driver.h"
#include "rm_mtr_foc_less_speed.h"
#include "rm_mtr_statemachine.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "r_mtr_config.h"
#include "r_mtr_ra2t1.h"
#include "r_mtr_ics.h"

#if (USE_OL2CL_CTRL == MTR_SET)
#include "rm_mtr_ol2cl_ctrl.h"
#endif

#include "hal_data.h"
#include "r_mtr_common.h"

/**********************************************************************************************************************
* Extern global variables
***********************************************************************************************************************/

/**********************************************************************************************************************
* global variables
***********************************************************************************************************************/
st_mtr_common_foc_t g_st_foc_common;

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/

static void mtr_carrier_vdc_get (int32_t * p_s4_vdc_ad, st_mtr_mod_t * p_st_mod);

static void mtr_carrier_foc_sequence (void);

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static inline void mtr_carrier_current_ss_get (st_mtr_sscs_t * p_st_sscs,
                                                st_coordinate28 * p_st_ad_i,
                                                st_coordinate28 * p_st_repro_i);

#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
static void mtr_carrier_current_ts_get (st_mtr_tscs_t * p_st_tscs, st_coordinate28 * p_st_ad_i);
#endif

static uint16_t mtr_carrier_lim_sw_over_current (st_coordinate28 * p_st_ad_i);

static void    mtr_carrier_uvw2dq (st_coordinate28 * p_st_ad_i, st_sincos28 * p_ad_i_angle);
static int32_t mtr_carrier_est_phase_err (st_coordinate28 * p_st_ad_i, st_mtr_parameter_t * p_st_motor,
                        st_mtr_estimate_phe_t * p_st_phe,
                        int32_t * p_s4_vdq,
                        st_mtr_asr_t * p_st_asr);
static void    mtr_carrier_est_speed_cll (st_mtr_pll_t * p_st_pll, st_mtr_asr_t * p_st_asr,
                        int32_t * p_ad_i_angle_rad, int32_t * p_ref_v_angle_rad,
                        st_mtr_common_foc_t * p_st_common);
static void    mtr_carrier_est_speed_opl (st_mtr_estimate_phe_t * p_st_phe,
                                            st_mtr_asr_t * p_st_asr,
                                            st_mtr_pll_t * p_st_pll,
                                            int32_t * p_ad_i_angle_rad, int32_t * p_ref_v_angle_rad);
static int8_t  mtr_carrier_get_direction (int32_t s4_speed);
static void    mtr_carrier_ctrl_pi (int32_t * p_s4_ad_idq,
                        st_coordinate28 * p_st_ref_i, st_coordinate28 * p_st_ref_v,
                        st_mtr_acr_t * p_st_acr);
static void    mtr_carrier_ctrl_decoupling (st_mtr_parameter_t * p_st_motor,
                        int32_t * p_s4_ad_idq, st_coordinate28 * p_st_ref_v,
                        st_mtr_asr_t* p_st_asr);
static void    mtr_carrier_dq2uvw_voltage (st_coordinate28 * p_st_ref_v);

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static void mtr_carrier_set_pwm_ss (st_coordinate28 * p_st_ref_v, st_mtr_mod_t * p_st_mod,
                            st_mtr_sscs_t * p_st_sscs, st_coordinate28 * p_st_ref_i);
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
static void mtr_carrier_set_pwm_ts (st_coordinate28 * p_st_ref_v, st_mtr_mod_t * p_st_mod,
                            st_mtr_tscs_t * p_st_tscs, st_coordinate28 * p_st_ref_i);
#endif

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static void mtr_conv_ad_ss (st_mtr_sscs_t * p_st_sscs);
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
static void mtr_2phase_duty_cross (st_coordinate28* p_st_ad_i, st_coordinate28* p_st_repro_i,
                                    st_mtr_lpf1_t* p_st_repro_id, st_mtr_lpf1_t* p_st_repro_iq);
#endif
#endif

#if (USE_DEADTIME_COMP == MTR_SET)
static void mtr_carrier_deadtime_comp (st_coordinate28 *p_st_ref_i,
                                    st_coordinate28 *p_st_ref_v, st_mtr_s4_comp_t * p_st_s4_comp);
#endif

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static void mtr_carrier_mod_ss (st_mtr_mod_t * p_st_mod, st_coordinate28 * p_st_ref_v, uint8_t * p_u1_drv_pat,
                        st_mtr_sscs_t * p_st_sscs, st_coordinate28 * p_st_ref_i);
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
static void mtr_carrier_mod_ts (st_mtr_mod_t * p_st_mod, st_coordinate28 * p_st_ref_v, st_coordinate28 * p_st_ref_i);
#endif

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static inline void mtr_carrier_pwm_duty_ss (st_mtr_sscs_t * p_st_sscs);
static inline void mtr_carrier_pwm_duty_nonadc_ss(st_mtr_sscs_t *p_st_sscs);
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
static void mtr_carrier_pwm_duty_ts (st_mtr_tscs_t * p_st_tscs, st_mtr_mod_t * p_st_mod);
#endif

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static inline void mtr_set_duty_adj_ss (st_mtr_sscs_t * st_sscs);
#endif

static void mtr_carrier_lim_uvw_voltage (int32_t * p_s4_ref_v_uvw, int32_t s4_voltage_limit);

static void mtr_carrier_startup_sequence (void);

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static uint8_t mtr_carrier_offset_ss (st_mtr_sscs_t * p_st_sscs);
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
static uint8_t mtr_carrier_offset_ts (st_mtr_tscs_t * p_st_tscs);
#endif


#if (THREE_SHUNT == CURRENT_SENS_METHOD)
#if (MOD_2PH_BOT == MOD_METHOD)
static int16_t mtr_carrier_pwm_duty_calc (int32_t s4_value, uint8_t u1_flg_uvw_min_pattern, uint8_t phase);
#else
static int16_t mtr_carrier_pwm_duty_calc (int32_t s4_value);
#endif
#endif

static int32_t mtr_limit (int32_t s4_value, int32_t s4_max, int32_t s4_min);

#if (MOD_2PH_BOT == MOD_METHOD)
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
static int16_t mtr_limit_or_zero (int16_t s2_value, int16_t s2_max, int16_t s2_min, int16_t s2_zero_line);
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */
#endif

static int32_t mtr_lpf1_run (st_mtr_lpf1_t * p_st_lpf, int32_t s4_input, const uint8_t u1_q);

static int32_t mtr_pi_run_acr (st_mtr_pi_t * p_st_pi, int32_t s4_err, const uint8_t u1_kp_q,
                            const uint8_t u1_q_err_shift, const uint8_t u1_q_kidt_shift, const uint8_t u1_q_intg_shift);

static int32_t mtr_abs (int32_t s4_value);
static int32_t mtr_limit_abs (int32_t s4_value, int32_t s4_limit_value);


/***********************************************************************************************************************
* Macro functions definitions
***********************************************************************************************************************/

/**********************************************************************************************************************
* @fn             mtr_carrier_cyclic
* @brief          callback for carrier interrupt
* @param[in]      p_args  Callback argument
* @return         None
***********************************************************************************************************************/
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
void mtr_carrier_cyclic(timer_callback_args_t *p_args)
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
void mtr_carrier_cyclic(adc_callback_args_t * p_args)
#endif
{
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    if (TIMER_EVENT_TROUGH != p_args->event)
    {
        return;
    }
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    if (ADC_EVENT_SCAN_COMPLETE != p_args->event)
    {
        return;
    }
#endif


__enable_irq();

    if (MTR_DRIVE == g_st_foc_common.u1_state_drive)
    {
        /* FOC control sequence */
        mtr_carrier_foc_sequence();

        /* Copy variables on sequence after */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
        /* 20khz, 40khz, 16khz */
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_pre = g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_buffer;
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vq_pre = g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vq_buffer;
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_buffer = (int32_t)g_st_foc_common.st_foc_carrier.st_ref_v.ax_d;
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vq_buffer = (int32_t)g_st_foc_common.st_foc_carrier.st_ref_v.ax_q;

#if ((CP_CARRIER_FREQ_20KHZ != CP_CARRIER_FREQ_SEL) && (CP_CARRIER_FREQ_40KHZ != CP_CARRIER_FREQ_SEL) && (CP_CARRIER_FREQ_16KHZ != CP_CARRIER_FREQ_SEL))
#error "Unsupported CP_CARRIER_FREQ_SEL value. Please select CP_CARRIER_FREQ_20KHZ, CP_CARRIER_FREQ_40KHZ, or CP_CARRIER_FREQ_16KHZ."
#endif
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
#if ((CP_CARRIER_FREQ_16KHZ == CP_CARRIER_FREQ_SEL) || (CP_CARRIER_FREQ_20KHZ == CP_CARRIER_FREQ_SEL))
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_pre = (int32_t)g_st_foc_common.st_foc_carrier.st_ref_v.ax_d;
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vq_pre = (int32_t)g_st_foc_common.st_foc_carrier.st_ref_v.ax_q;
#elif (CP_CARRIER_FREQ_40KHZ == CP_CARRIER_FREQ_SEL)
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_pre = g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_buffer;
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vq_pre = g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vq_buffer;
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_buffer = (int32_t)g_st_foc_common.st_foc_carrier.st_ref_v.ax_d;
        g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vq_buffer = (int32_t)g_st_foc_common.st_foc_carrier.st_ref_v.ax_q;
#else
#error "Unsupported CP_CARRIER_FREQ_SEL value. Please select CP_CARRIER_FREQ_20KHZ, CP_CARRIER_FREQ_40KHZ, or CP_CARRIER_FREQ_16KHZ."
#endif
#endif

        /* ICS setting */
        R_MTR_SetIcs();
    }
    else
    {
        /* Stop sequence */
        mtr_carrier_startup_sequence();
    }
    /* Get Vdc */
    mtr_carrier_vdc_get(&g_st_foc_common.s4_ad_vdc, &g_st_foc_common.st_foc_carrier.st_mod);

} /* End of function mtr_carrier_cyclic */

/***********************************************************************************************************************
* @fn             mtr_carrier_vdc_get
* @brief          Get VDC
* @param[out]     p_s2_vdc_ad   The pointer to VDC
* @param[out]     p_st_mod      The pointer to the structure for modulation
* @return         None
***********************************************************************************************************************/
static void mtr_carrier_vdc_get(int32_t* p_s4_vdc_ad, st_mtr_mod_t* p_st_mod)
{
    uint32_t u4_vdc_temp;

    /* Get Vdc */
    R_ADC_Read32(g_adc0.p_ctrl, R_MTR_ADCR_VDC, &u4_vdc_temp);

    /* Calcurate  Vdc voltage(signed) */
    (*p_s4_vdc_ad) = ((int32_t)u4_vdc_temp * (FP_SF_VOLTAGE >> MTR_ADC_12BIT));

    /* Update voltage limit */
    p_st_mod->s4_lim_vout = ((*p_s4_vdc_ad) >> 1) - MTR_VOLTAGE_LIMIT_OFFSET;

    /* Calculate reciprocal (bus voltage)/2  */
    p_st_mod->s4_ad_reci_vdc = (MTR_RECIV_COEF / (int32_t)u4_vdc_temp) << MTR_ADC_12BIT;
} /* End of function mtr_carrier_vdc_get */

/**********************************************************************************************************************
* @fn             mtr_carrier_foc_sequence
* @brief          FOC control and set PWM moduration at PWM cycle timing
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_foc_sequence(void)
{
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    /* Detect 1-shunt currents */
    mtr_carrier_current_ss_get(&g_st_foc_common.st_foc_carrier.st_sscs,
                                &g_st_foc_common.st_foc_carrier.st_ad_i,
                                &g_st_foc_common.st_foc_carrier.st_repro_i);
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    /* Detect 3-shunt currents */
    mtr_carrier_current_ts_get(&g_st_foc_common.st_foc_carrier.st_tscs,
                                &g_st_foc_common.st_foc_carrier.st_ad_i);
#endif

    /* Software over current error check */
    g_st_foc_common.st_foc_carrier.u2_error_status
        |= mtr_carrier_lim_sw_over_current(&g_st_foc_common.st_foc_carrier.st_ad_i);

    /* Transform UVW to dq */
    mtr_carrier_uvw2dq(&g_st_foc_common.st_foc_carrier.st_ad_i, &g_st_foc_common.st_foc_carrier.st_ad_i.st_angle);

    /* Estimate phase errors */
    g_st_foc_common.s4_phase_err_rad
        = mtr_carrier_est_phase_err(&g_st_foc_common.st_foc_carrier.st_ad_i, &g_st_foc_common.st_foc_carrier.st_motor,
                        &g_st_foc_common.st_foc_carrier.st_phe, &g_st_foc_common.st_foc_carrier.st_acr.s4_ref_vd_pre,
                        &g_st_foc_common.st_foc_speed.st_asr);

    if (MTR_DRIVE_CLL == (g_st_foc_common.u1_state_ctrl & 0x80))
    {
        /* Control a motor speed */
        mtr_carrier_est_speed_cll(&g_st_foc_common.st_foc_carrier.st_pll, &g_st_foc_common.st_foc_speed.st_asr,
                        (int32_t*)&g_st_foc_common.st_foc_carrier.st_ad_i.st_angle.angle_rad,
                        (int32_t*)&g_st_foc_common.st_foc_carrier.st_ref_v.st_angle.angle_rad,
                        &g_st_foc_common);
    }
    else if (MTR_DRIVE_OPL == (g_st_foc_common.u1_state_ctrl & 0x80))
    {
        /* Control a motor current */
        mtr_carrier_est_speed_opl(&g_st_foc_common.st_foc_carrier.st_phe,
                                    &g_st_foc_common.st_foc_speed.st_asr,
                                    &g_st_foc_common.st_foc_carrier.st_pll,
                                    (int32_t*)&g_st_foc_common.st_foc_carrier.st_ad_i.st_angle.angle_rad,
                                    (int32_t*)&g_st_foc_common.st_foc_carrier.st_ref_v.st_angle.angle_rad);
    }

    /* Get a direction of the motor rotation */
    g_st_foc_common.s1_direction = mtr_carrier_get_direction(g_st_foc_common.st_foc_speed.st_asr.s4_speed);
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    if (MTR_DRIVE_CLL == (g_st_foc_common.u1_state_ctrl & 0x80))
    {
        if (0 != (((st_mtr_sscs_t *)(&g_st_foc_common.st_foc_carrier.st_sscs))->u1_drv_pattern_get
                    & MTR_DRV_CURRENT_UNAVAILABLE))
        {
            g_st_foc_common.st_foc_carrier.st_acr.u1_flg_err_zero = MTR_SET; /* ASR is working */
        }
        else
        {
            g_st_foc_common.st_foc_carrier.st_acr.u1_flg_err_zero = MTR_CLR; /* ASR is not working */
        }
    }
#endif

    /* Calculate idq LPF */
    int32_t s4_ad_idq[2] = {0, 0};
#if (USE_CURRENT_LPF_ID == MTR_SET)
    s4_ad_idq[MTR_ID] = mtr_lpf1_run(&g_st_foc_common.st_foc_carrier.st_acr.st_ad_id_lpf,
                                        (int32_t)g_st_foc_common.st_foc_carrier.st_ad_i.ax_d,
                                        MTR_Q_CURRENT_LPF_CO);
#else
    s4_ad_idq[MTR_ID] = g_st_foc_common.st_foc_carrier.st_ad_i.ax_d;
#endif
#if (USE_CURRENT_LPF_IQ == MTR_SET)
    s4_ad_idq[MTR_IQ] = mtr_lpf1_run(&g_st_foc_common.st_foc_carrier.st_acr.st_ad_iq_lpf,
                                        (int32_t)g_st_foc_common.st_foc_carrier.st_ad_i.ax_q,
                                        MTR_Q_CURRENT_LPF_CO);
#else
    s4_ad_idq[MTR_IQ] = g_st_foc_common.st_foc_carrier.st_ad_i.ax_q;
#endif
    /* Control PI */
    mtr_carrier_ctrl_pi(s4_ad_idq, &g_st_foc_common.st_foc_carrier.st_ref_i,
                        &g_st_foc_common.st_foc_carrier.st_ref_v, &g_st_foc_common.st_foc_carrier.st_acr);

    /* Control decoupling */
    mtr_carrier_ctrl_decoupling(&g_st_foc_common.st_foc_carrier.st_motor,
                        s4_ad_idq, &g_st_foc_common.st_foc_carrier.st_ref_v,
                        &g_st_foc_common.st_foc_speed.st_asr);

    /* Transform dq to UVW */
    mtr_carrier_dq2uvw_voltage(&g_st_foc_common.st_foc_carrier.st_ref_v);

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    /* Set PWM for 1-shunt */
    mtr_carrier_set_pwm_ss(&g_st_foc_common.st_foc_carrier.st_ref_v, &g_st_foc_common.st_foc_carrier.st_mod,
                            &g_st_foc_common.st_foc_carrier.st_sscs, &g_st_foc_common.st_foc_carrier.st_ref_i);

    /* Execute AD conversion for 1-shunt */
    mtr_conv_ad_ss(&g_st_foc_common.st_foc_carrier.st_sscs);
#endif

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    /*  Set PWM for 3-shunt */
    mtr_carrier_set_pwm_ts(&g_st_foc_common.st_foc_carrier.st_ref_v, &g_st_foc_common.st_foc_carrier.st_mod,
                            &g_st_foc_common.st_foc_carrier.st_tscs, &g_st_foc_common.st_foc_carrier.st_ref_i);
#endif

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    /* Update the drive-pattern */
#if (0 == TRD_SKIPPING_COUNT)
    g_st_foc_common.st_foc_carrier.st_sscs.u1_drv_pattern_get
        = g_st_foc_common.st_foc_carrier.st_sscs.u1_drv_pattern_put;
    g_st_foc_common.st_foc_carrier.st_sscs.u1_drv_pattern_put
        = g_st_foc_common.st_foc_carrier.st_sscs.u1_drv_pattern_set;
#else
    ((st_mtr_sscs_t *)(&g_st_foc_common.st_foc_carrier.st_sscs))->u1_drv_pattern_get
        = ((st_mtr_sscs_t *)(&g_st_foc_common.st_foc_carrier.st_sscs))->u1_drv_pattern_set;
#endif
#endif

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    /* Execute a 2-phase duty-cross */
    mtr_2phase_duty_cross(&g_st_foc_common.st_foc_carrier.st_ad_i, &g_st_foc_common.st_foc_carrier.st_repro_i,
                            &g_st_foc_common.st_foc_carrier.st_repro_id, &g_st_foc_common.st_foc_carrier.st_repro_iq);
#endif
#endif
} /* End of function mtr_carrier_foc_sequence */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_current_ss_get
* @brief          Detect 1-shunt currents
* @param[in,out]  p_st_sscs      The pointer to the structure for sensing 1-shunt currents
* @param[out]     p_st_ad_i      The pointer to three phase currents
* @param[in]      p_st_repro_i   The pointer to the coordinate system of reproduct current
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_current_ss_get(st_mtr_sscs_t* p_st_sscs,
                                                st_coordinate28* p_st_ad_i,
                                                st_coordinate28* p_st_repro_i)
{
    int32_t s4_conv_a;
    int32_t s4_conv_b;
    int32_t s4_conv_c;

    if (0 == (p_st_sscs->u1_drv_pattern_get & MTR_DRV_CURRENT_UNAVAILABLE))
    {
        /* Get sampled current */

        /* Get Idc of ADC value */
        R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IDC, &p_st_sscs->u2_crnt_ad_a);
        R_MTR_ADC_ReadDuplex(g_adc0.p_ctrl, &p_st_sscs->u2_crnt_ad_b);
        /* calculate Adc(signed) to Adc value(unsigned) */
        p_st_sscs->s2_ad_ss_a = ((int16_t)p_st_sscs->u2_crnt_ad_a >> MTR_ADC_DATA_SHIFT);

        s4_conv_a  = -(MTR_ADC_OFFSET - p_st_sscs->s2_ad_ss_a);
        s4_conv_a -= p_st_sscs->s4_offset_ia;

        /* round float value */
        s4_conv_a  = -((s4_conv_a * FP_SF_CURRENT_AD));

        /* calculate Adc(signed) to Adc value(unsigned) */
        p_st_sscs->s2_ad_ss_b = ((int16_t)p_st_sscs->u2_crnt_ad_b >> MTR_ADC_DATA_SHIFT);

        s4_conv_b  = -(MTR_ADC_OFFSET - p_st_sscs->s2_ad_ss_b);
        s4_conv_b -= p_st_sscs->s4_offset_ib;

        /* round float value */
        s4_conv_b  = ((s4_conv_b * FP_SF_CURRENT_AD));

        s4_conv_c = -(s4_conv_a + s4_conv_b);

        /* calculate from 1shunt */
        switch (p_st_sscs->u1_drv_pattern_get)
        {
            case MTR_DRV_UVW:
                p_st_ad_i->ph_u = s4_conv_b;
                p_st_ad_i->ph_v = s4_conv_c;
                p_st_ad_i->ph_w = s4_conv_a;
                break;

            case MTR_DRV_UWV:
                p_st_ad_i->ph_u = s4_conv_b;
                p_st_ad_i->ph_v = s4_conv_a;
                p_st_ad_i->ph_w = s4_conv_c;
                break;

            case MTR_DRV_VUW:
                p_st_ad_i->ph_u = s4_conv_c;
                p_st_ad_i->ph_v = s4_conv_b;
                p_st_ad_i->ph_w = s4_conv_a;
                break;

            case MTR_DRV_VWU:
                p_st_ad_i->ph_u = s4_conv_a;
                p_st_ad_i->ph_v = s4_conv_b;
                p_st_ad_i->ph_w = s4_conv_c;
                break;

            case MTR_DRV_WUV:
                p_st_ad_i->ph_u = s4_conv_c;
                p_st_ad_i->ph_v = s4_conv_a;
                p_st_ad_i->ph_w = s4_conv_b;
                break;

            case MTR_DRV_WVU:
                p_st_ad_i->ph_u = s4_conv_a;
                p_st_ad_i->ph_v = s4_conv_c;
                p_st_ad_i->ph_w = s4_conv_b;
                break;

            default:
                break;
        }
    }
    else
    {
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
        /* Get reproduction current */
        p_st_ad_i->ph_u = p_st_repro_i->ph_u;
        p_st_ad_i->ph_v = p_st_repro_i->ph_v;
        p_st_ad_i->ph_w = p_st_repro_i->ph_w;
#endif
    }
} /* End of function mtr_carrier_current_ss_get */
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_current_ts_get
* @brief          Detect 1-shunt currents
* @param[in,out]  p_st_tscs   The pointer to the structure for sensing 3-shunt currents
* @param[out]     p_st_ad_i   The pointer to three phase currents
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_current_ts_get(st_mtr_tscs_t * p_st_tscs, st_coordinate28 * p_st_ad_i)
{
#if (USE_U_PHASE_CURRENT == MTR_SET)
    int32_t s4_temp_iu;
#endif
    int32_t s4_temp_iv;
    int32_t s4_temp_iw;

    /* Get Iuvw of ADC value */
#if (USE_U_PHASE_CURRENT == MTR_SET)
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IU, &p_st_tscs->u2_ad_current_uph);
#endif
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IV, &p_st_tscs->u2_ad_current_vph);
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IW, &p_st_tscs->u2_ad_current_wph);

    /* Current offset adjustment */
#if (USE_U_PHASE_CURRENT == MTR_SET)
    /* s2_temp_iu is signed integer */
    s4_temp_iu    = (int32_t)(MTR_ADC_OFFSET - (p_st_tscs->u2_ad_current_uph - p_st_tscs->s4_offset_iu));
#endif

    /* s2_temp_iv is signed integer */
    s4_temp_iv    = (int32_t)(MTR_ADC_OFFSET - (p_st_tscs->u2_ad_current_vph - p_st_tscs->s4_offset_iv));

    /* s2_temp_iw is signed integer */
    s4_temp_iw    = (int32_t)(MTR_ADC_OFFSET - (p_st_tscs->u2_ad_current_wph - p_st_tscs->s4_offset_iw));

    p_st_ad_i->ph_v = ((int32_t)s4_temp_iv * FP_SF_CURRENT_AD);  /* V-phase current */
    p_st_ad_i->ph_w = ((int32_t)s4_temp_iw * FP_SF_CURRENT_AD);  /* W-phase current */
#if (USE_U_PHASE_CURRENT == MTR_SET)
    p_st_ad_i->ph_u = ((int32_t)s4_temp_iu * FP_SF_CURRENT_AD);  /* U-phase current */
#else
    /* Calculate s2_temp_iu with iv and iw */
    p_st_ad_i->ph_u = -(p_st_ad_i->ph_v + p_st_ad_i->ph_w);
#endif
} /* End of function mtr_carrier_current_ts_get */
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */

/***********************************************************************************************************************
* @fn             mtr_carrier_lim_sw_over_current
* @brief          Software over current error check
* @param[in]      p_st_ad_i   The pointer to three phase currents
* @retval         MTR_ERROR_NONE             No error
* @retval         MTR_ERROR_OVER_CURRENT_SW  Over current error has occurred
***********************************************************************************************************************/
static inline uint16_t mtr_carrier_lim_sw_over_current(st_coordinate28 * p_st_ad_i)
{
    const int32_t s4_lim_over_current = FIX_fromfloat(MTR_OVERCURRENT_LIMIT * PU_SF_CURRENT, MTR_Q_CURRENT);
    int32_t       s4_temp;

    /*=====================================*/
    /*     SW over current error check     */
    /*=====================================*/
    s4_temp  = (mtr_abs(p_st_ad_i->ph_u) > s4_lim_over_current);
    s4_temp |= (mtr_abs(p_st_ad_i->ph_v) > s4_lim_over_current);
    s4_temp |= (mtr_abs(p_st_ad_i->ph_w) > s4_lim_over_current);

    if (s4_temp)
    {
        return (MTR_ERROR_OVER_CURRENT_SW);             /* over current error */
    }

    return (MTR_ERROR_NONE);
} /* End of function mtr_carrier_lim_sw_over_current */

/***********************************************************************************************************************
* @fn             mtr_carrier_uvw2dq
* @brief          Transform UVW to dq
* @param[in,out]  p_st_ad_i      The pointer to the structure for ADC current
* @param[in,out]  p_ad_i_angle   The pointer to the structure for an angle of ADC current
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_uvw2dq(st_coordinate28* p_st_ad_i, st_sincos28* p_ad_i_angle)
{
    /*=============================================*/
    /*     Coordinate transformation (UVW->dq)     */
    /*=============================================*/
    /* Update Coordinate transformation (UVW->dq) rotor angle */
    R_motor_sincos_FIX28(p_ad_i_angle);
    R_motor_uw2dq_abs_FIX28(p_st_ad_i);
} /* End of function mtr_carrier_uvw2dq */

/***********************************************************************************************************************
* @fn             mtr_carrier_est_phase_err
* @brief          Estimate phase errors
* @param[in]      p_st_ad_i     The pointer to the structure for ADC current
* @param[in]      p_st_motor    The pointer to the structure for motor parameters
* @param[out]     p_st_phe      The pointer to the structure for error estimation
* @param[in]      p_s2_vdq      The pointer to the two reference voltages
* @param[in]      p_st_asr      The pointer to the structure for auto speed regulator
* @return         s4_phase_err_rad
***********************************************************************************************************************/
static inline int32_t mtr_carrier_est_phase_err(st_coordinate28* p_st_ad_i, st_mtr_parameter_t* p_st_motor,
                        st_mtr_estimate_phe_t* p_st_phe,
                        int32_t* p_s4_vdq, st_mtr_asr_t* p_st_asr)
{
    st_mtr_est_vect_t s4_est;
    int32_t           s4_temp_1;
    int32_t           s4_temp_2;
    int32_t           s4_phase_err_rad;

    s4_est.s4_ref_vd = p_s4_vdq[0];
    s4_est.s4_ref_vq = p_s4_vdq[1];

    /*================================*/
    /*     phase error estimation     */
    /*================================*/
    s4_est.s4_est_r_iq = FIX_mul_rs(p_st_ad_i->ax_q,
                                    p_st_motor->s4_mtr_r,
                                    MTR_Q_CURRENT + MTR_Q_RESISTANCE - MTR_Q_VOLTAGE);/* vq-R*iq */
    s4_est.s4_est_r_id = FIX_mul_rs(p_st_ad_i->ax_d,
                                    p_st_motor->s4_mtr_r,
                                    MTR_Q_CURRENT + MTR_Q_RESISTANCE - MTR_Q_VOLTAGE);/* vd-R*id */

    s4_temp_1 = FIX_mul_rs(p_st_asr->s4_speed,
                            p_st_motor->s4_mtr_lq,
                            MTR_Q_AFREQ + MTR_Q_INDUCTANCE - MTR_Q_RESISTANCE);/* speed*Lq */
    s4_temp_2 = FIX_mul_rs(p_st_asr->s4_speed,
                            p_st_motor->s4_mtr_ld,
                            MTR_Q_AFREQ + MTR_Q_INDUCTANCE - MTR_Q_RESISTANCE);/* speed*Ld */

    s4_est.s4_est_speed_lq_iq = FIX_mul_rs(s4_temp_1,
                                            p_st_ad_i->ax_q,
                                            MTR_Q_CURRENT + MTR_Q_RESISTANCE - MTR_Q_VOLTAGE);/* speed*Lq*iq */
    s4_est.s4_est_speed_ld_id = FIX_mul_rs(s4_temp_2,
                                            p_st_ad_i->ax_d,
                                            MTR_Q_CURRENT + MTR_Q_RESISTANCE - MTR_Q_VOLTAGE);/* speed*Ld*id */
    s4_phase_err_rad = RM_MTR_ESTIMATE_AngleSpeedGet(p_st_phe, p_st_asr->s4_speed, &s4_est);

    return s4_phase_err_rad;
} /* End of function mtr_carrier_est_phase_err */

/***********************************************************************************************************************
* @fn             mtr_carrier_est_speed_cll
* @brief          Control a motor speed
* @param[in,out]  p_st_pll          The pointer to the structure for PLL parameters
* @param[in,out]  p_st_asr          The pointer to the structure for auto speed regulator
* @param[in,out]  p_ad_i_angle_rad  The pointer to an angle degree of ADC current
* @param[in,out]  p_ref_v_angle_rad The pointer to an angle degree of reference voltage
* @param[in]      p_st_common       The pointer to the structure for common data
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_est_speed_cll(st_mtr_pll_t* p_st_pll, st_mtr_asr_t* p_st_asr,
                    int32_t* p_ad_i_angle_rad, int32_t* p_ref_v_angle_rad,
                    st_mtr_common_foc_t* p_st_common)
{
    int32_t s4_wt = 0;
    int32_t s4_wt_advance;

    /* PLL */
    p_st_pll->s4_est_speed = mtr_pi_run_acr(&p_st_pll->st_pi,
                        - (p_st_common->s4_phase_err_rad),
                        (MTR_Q_ANGLE + MTR_Q_PLL_KP) - MTR_Q_AFREQ,
                        MTR_Q_ANGLE - MTR_Q_PI_RUN_PLL_ERR,
                        MTR_Q_PLL_KIDT - (MTR_Q_AFREQ - MTR_Q_PI_RUN_ACR_INTG),
                        MTR_Q_PI_RUN_PLL_ERR - MTR_Q_PI_RUN_ACR_INTG);

#if (USE_SPEED_LPF == MTR_SET)
    /* Speed LPF */
    p_st_asr->s4_speed = mtr_lpf1_run(&p_st_asr->st_lpf, p_st_pll->s4_est_speed, MTR_Q_SPEED_LPF_CO);
#else
    p_st_asr->s4_speed = p_st_pll->s4_est_speed;
#endif

    /* Rotor position update */
    s4_wt = FIX_mul_rs(p_st_asr->s4_speed,
                        FIX_fromfloat(MTR_CTRL_PERIOD * PU_SF_TIME, MTR_Q_CTRL_TIME),
                        (MTR_Q_AFREQ + MTR_Q_CTRL_TIME) - MTR_Q_ANGLE);

    /* Angle advance */
    s4_wt_advance = FIX_mul_rs(s4_wt,
                                MTR_V_PHASE_LEAD_COEF,
                                (MTR_Q_ANGLE + MTR_Q_V_PHASE_LEAD_COEF) - MTR_Q_ANGLE);
    (*p_ref_v_angle_rad) = (*p_ad_i_angle_rad) + s4_wt_advance;
    if ((*p_ref_v_angle_rad) >= MTR_ANGLE_RANGE)
    {
        (*p_ref_v_angle_rad) -= MTR_ANGLE_RANGE;
    }
    else if ((*p_ref_v_angle_rad) <= (-MTR_ANGLE_RANGE))
    {
        (*p_ref_v_angle_rad) += MTR_ANGLE_RANGE;
    }

    (*p_ad_i_angle_rad) += s4_wt;
    if ((*p_ad_i_angle_rad) >= MTR_ANGLE_RANGE)
    {
        (*p_ad_i_angle_rad) -= MTR_ANGLE_RANGE;
    }
    else if ((*p_ad_i_angle_rad) <= (-MTR_ANGLE_RANGE))
    {
        (*p_ad_i_angle_rad) += MTR_ANGLE_RANGE;
    }
} /* End of function mtr_carrier_est_speed_cll */

/***********************************************************************************************************************
* @fn             mtr_carrier_est_speed_opl
* @brief          Control a motor current
* @param[in,out]  p_st_phe          The pointer to the structure for error estimation
* @param[in,out]  p_st_asr          The pointer to the structure for auto speed regulator
* @param[out]     p_st_pll          The pointer to the structure for PLL parameters
* @param[in,out]  p_ad_i_angle_rad  The pointer to an angle degree of ADC current
* @param[in,out]  p_ref_v_angle_rad The pointer to an angle degree of reference voltage
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_est_speed_opl(st_mtr_estimate_phe_t* p_st_phe,
                                            st_mtr_asr_t* p_st_asr,
                                            st_mtr_pll_t* p_st_pll,
                                            int32_t* p_ad_i_angle_rad, int32_t* p_ref_v_angle_rad)
{
    int32_t s4_temp_speed;

    if (p_st_phe->s4_est_eq < 0)
    {
        /* BEMF magnitude calculation */
        p_st_phe->s4_est_e = -(int32_t)R_motor_sqrt_sum_FIX28(p_st_phe->s4_est_ed, p_st_phe->s4_est_eq);
    }
    else
    {
        /* BEMF magnitude calculation */
        p_st_phe->s4_est_e = (int32_t)R_motor_sqrt_sum_FIX28(p_st_phe->s4_est_ed, p_st_phe->s4_est_eq);
    }

    /* Calculate speed from magnitude of estimated BEMF */
    s4_temp_speed = FIX_mul_rs(p_st_phe->s4_coef_reci_ke, p_st_phe->s4_est_e,
                        (MTR_Q_VOLTAGE + MTR_Q_RECIM) - MTR_Q_AFREQ);

    /* Force angle advance */
    (*p_ad_i_angle_rad) = (*p_ad_i_angle_rad)
#if (USE_OPENLOOP_DAMPING == MTR_SET)
                                + FIX_mul_rs(p_st_asr->s4_ref_speed_damp_ctrl,
#else
                                + FIX_mul_rs(p_st_asr->s4_ref_speed_ctrl,
#endif
                                            FIX_fromfloat(MTR_CTRL_PERIOD * PU_SF_TIME, MTR_Q_CTRL_TIME),
                                            (MTR_Q_AFREQ + MTR_Q_CTRL_TIME) - MTR_Q_ANGLE);

    if ((*p_ad_i_angle_rad) >= MTR_ANGLE_RANGE)
    {
        (*p_ad_i_angle_rad) -= MTR_ANGLE_RANGE;
    }
    else if ((*p_ad_i_angle_rad) <= (-MTR_ANGLE_RANGE))
    {
        (*p_ad_i_angle_rad) += MTR_ANGLE_RANGE;
    }

    (*p_ref_v_angle_rad) = (*p_ad_i_angle_rad);

#if (USE_SPEED_LPF == MTR_SET)
    /* Speed LPF */
    p_st_asr->s4_speed = mtr_lpf1_run(&p_st_asr->st_lpf, s4_temp_speed, MTR_Q_SPEED_LPF_CO);
#else
    FSP_PARAMETER_NOT_USED(p_st_asr);
    p_st_asr->s4_speed = s4_temp_speed;
#endif
    /* Preparation for PLL */
    p_st_pll->s4_est_speed  = s4_temp_speed;
} /* End of function mtr_carrier_est_speed_opl */

/***********************************************************************************************************************
* @fn             mtr_carrier_get_direction
* @brief          Get a direction of the motor rotation
* @param[out]     p_s1_direction   A direction of motor rotation
* @param[in]      p_st_common      The pointer to the structure for common data
* @return         MTR_CCW/MTR_CW
***********************************************************************************************************************/
static inline int8_t mtr_carrier_get_direction(int32_t s4_speed)
{
    /* Calculate direction of rotation */
    if (s4_speed < 0)
    {
        return MTR_CCW;
    }
    else
    {
        return MTR_CW;
    }
} /* End of function mtr_carrier_get_direction */

/**********************************************************************************************************************
* @fn             mtr_carrier_ctrl_pi
* @brief          Control PI
* @param[in]      p_s4_ad_idq   The pointer to the ADC current
* @param[in]      p_st_ref_i    The pointer to the structure for reference current
* @param[in,out]  p_st_ref_v    The pointer to the structure for reference voltage
* @param[in,out]  st_acr        The pointer to the structure for auto current regulator
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_ctrl_pi(int32_t* p_s4_ad_idq,
                st_coordinate28* p_st_ref_i, st_coordinate28* p_st_ref_v,
                st_mtr_acr_t* p_st_acr)
{
    int32_t s4_err;

    /* d-axis */
    s4_err = (int32_t)(p_st_ref_i->ax_d - p_s4_ad_idq[MTR_ID]);
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    if (MTR_SET == p_st_acr->u1_flg_err_zero)
    {
        s4_err = 0;
    }
#endif
    p_st_ref_v->ax_d = mtr_pi_run_acr(&p_st_acr->st_pi_id,
                            s4_err,
                            (MTR_Q_CURRENT + MTR_Q_ACR_KP) - MTR_Q_VOLTAGE,
                            MTR_Q_CURRENT - MTR_Q_PI_RUN_ACR_ERR,
                            MTR_Q_ACR_KIDT - (MTR_Q_VOLTAGE - MTR_Q_PI_RUN_ACR_INTG),
                            MTR_Q_PI_RUN_ACR_ERR - MTR_Q_PI_RUN_ACR_INTG);

    /* q-axis */
    s4_err = (int32_t)(p_st_ref_i->ax_q - p_s4_ad_idq[MTR_IQ]);
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    if (MTR_SET == p_st_acr->u1_flg_err_zero)
    {
        s4_err = 0;
    }
#endif
    p_st_ref_v->ax_q = mtr_pi_run_acr(&p_st_acr->st_pi_iq,
                                s4_err,
                                (MTR_Q_CURRENT + MTR_Q_ACR_KP) - MTR_Q_VOLTAGE,
                                MTR_Q_CURRENT - MTR_Q_PI_RUN_ACR_ERR,
                                MTR_Q_ACR_KIDT - (MTR_Q_VOLTAGE - MTR_Q_PI_RUN_ACR_INTG),
                                MTR_Q_PI_RUN_ACR_ERR - MTR_Q_PI_RUN_ACR_INTG);
} /* End of function mtr_carrier_ctrl_pi */

/***********************************************************************************************************************
* @fn             mtr_carrier_ctrl_decoupling
* @brief          Control decoupling
* @param[in]      p_st_motor    The pointer to the structure for motor parameters
* @param[in]      p_s4_ad_idq   The pointer to the ADC current
* @param[in,out]  p_st_ref_v    The pointer to the structure for reference voltage
* @param[in]      st_asr        The structure for auto speed regulator
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_ctrl_decoupling(st_mtr_parameter_t* p_st_motor,
                        int32_t* p_s4_ad_idq, st_coordinate28* p_st_ref_v,
                        st_mtr_asr_t* p_st_asr)
{
    int32_t s4_temp;
    int32_t s4_mtr_ld;
    int32_t s4_mtr_lq;
    int32_t s4_mtr_ke;

    s4_mtr_ld = p_st_motor->s4_mtr_ld;
    s4_mtr_lq = p_st_motor->s4_mtr_lq;
    s4_mtr_ke = p_st_motor->s4_mtr_ke;

    /* Lq * iq */
    s4_temp = FIX_mul_rs(s4_mtr_lq, p_s4_ad_idq[MTR_IQ], (MTR_Q_CURRENT + MTR_Q_INDUCTANCE) - MTR_Q_BEMF_CONST);

    /* w*Lq*iq */
    s4_temp = FIX_mul_rs(p_st_asr->s4_ref_speed_ctrl, s4_temp,
                            (MTR_Q_BEMF_CONST + MTR_Q_AFREQ) - MTR_Q_VOLTAGE);

    /* vd-w*Lq*iq */
    p_st_ref_v->ax_d = p_st_ref_v->ax_d - s4_temp;

    /* Ld*id */
    s4_temp = FIX_mul_rs(s4_mtr_ld, p_s4_ad_idq[MTR_ID], (MTR_Q_CURRENT + MTR_Q_INDUCTANCE) - MTR_Q_BEMF_CONST);

    /* Ld*id+Ke */
    s4_temp = s4_temp + s4_mtr_ke;

    /* w*(Ld*id+Ke) */
    s4_temp = FIX_mul_rs(p_st_asr->s4_ref_speed_ctrl, s4_temp,
                            (MTR_Q_BEMF_CONST + MTR_Q_AFREQ) - MTR_Q_VOLTAGE);

    /* vq+w*(Ld*id+Ke) */
    p_st_ref_v->ax_q = p_st_ref_v->ax_q + s4_temp;
} /* End of function mtr_carrier_ctrl_decoupling */

/***********************************************************************************************************************
* @fn             mtr_carrier_dq2uvw_voltage
* @brief          Transform dq to UVW
* @param[in,out]  p_st_ref_v   The pointer to the structure for reference voltage
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_dq2uvw_voltage(st_coordinate28* p_st_ref_v)
{
    /*=================================================*/
    /*     Coordinate transformation (dq->UVW)         */
    /*=================================================*/
    /* Update Coordinate transformation (dq->UVW) rotor angle */
    R_motor_sincos_FIX28(&p_st_ref_v->st_angle);
    R_motor_dq2uvw_abs_FIX28(p_st_ref_v);
} /* End of function mtr_carrier_dq2uvw_voltage */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_set_pwm_ss
* @brief          Set PWM for Single Shunt
* @param[in,out]  p_st_ref_v    The pointer to the structure for reference voltage
* @param[in,out]  p_st_mod      The pointer to the structure for modulation
* @param[in,out]  p_st_sscs     The pointer to the structure for sensing 1-shunt currents
* @param[in,out]  p_st_ref_i    The pointer to the Coordinate system structure of current
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_set_pwm_ss(st_coordinate28* p_st_ref_v, st_mtr_mod_t* p_st_mod,
        st_mtr_sscs_t* p_st_sscs, st_coordinate28 *p_st_ref_i)
{
    /*==============================*/
    /*     Calculate modulation     */
    /*==============================*/
    mtr_carrier_mod_ss(p_st_mod, p_st_ref_v, &p_st_sscs->u1_drv_pattern_set, p_st_sscs, p_st_ref_i);
    mtr_carrier_pwm_duty_ss(p_st_sscs);
    mtr_set_duty_adj_ss(p_st_sscs);
} /* End of function mtr_carrier_set_pwm_ss */
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_set_pwm_ts
* @brief          Set PWM for Three Shunt
* @param[in,out]  p_st_ref_v    The pointer to the structure for reference voltage
* @param[in,out]  p_st_mod      The pointer to the structure for modulation
* @param[in,out]  p_st_tscs     The pointer to the structure for sensing 3-shunt currents
* @param[in,out]  p_st_ref_i    The pointer to the Coordinate system structure of current
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_set_pwm_ts(st_coordinate28* p_st_ref_v, st_mtr_mod_t* p_st_mod,
                st_mtr_tscs_t* p_st_tscs, st_coordinate28 *p_st_ref_i)
{
    /*==============================*/
    /*     Calculate modulation     */
    /*==============================*/
    mtr_carrier_mod_ts(p_st_mod, p_st_ref_v, p_st_ref_i);

    /*==============================*/
    /*     PWM reference setting    */
    /*==============================*/
    mtr_carrier_pwm_duty_ts(p_st_tscs, p_st_mod);

    /* Set duty */
    three_phase_duty_cycle_t duty_cycle;
    duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = (uint16_t)p_st_tscs->s2_duty_u;
    duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = (uint16_t)p_st_tscs->s2_duty_v;
    duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = (uint16_t)p_st_tscs->s2_duty_w;
    R_GPT_THREE_PHASE_CompMode2_DutyCycleSet(g_three_phase0.p_ctrl, &duty_cycle);
} /* End of function mtr_carrier_set_pwm_ts */
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_conv_ad_ss
* @brief          Execute AD conversion for Single Shunt
* @param[in,out]  p_st_sscs   The pointer to the structure for sensing 1-shunt currents
* @return         None
***********************************************************************************************************************/
static inline void mtr_conv_ad_ss(st_mtr_sscs_t* p_st_sscs)
{
    if(p_st_sscs->u1_drv_pattern_set & MTR_DRV_CURRENT_UNAVAILABLE)
    {
        /* If driver pattern is set to unavailable current, */
        /* skip AD conversion by setting both AD conversion points to MTR_PWM_SHIFT_TIMER_SET_0 + 1. */
        p_st_sscs->s2_ad_point_a_cnt = MTR_PWM_SHIFT_TIMER_SET_0 + 1;
        p_st_sscs->s2_ad_point_b_cnt = MTR_PWM_SHIFT_TIMER_SET_0 + 1;
    }
    else
    {
        p_st_sscs->s2_ad_point_b_cnt = (p_st_sscs->s2_duty_min_adj_comp + MTR_PWM_SHIFT_AD_CONVERT_CNT);

#if (MOD_2PH_BOT == MOD_METHOD)
    if (MTR_SET == p_st_sscs->u1_flag_mod_2ph)
    {
        /* A-point set to Maximum */
        p_st_sscs->s2_ad_point_a_cnt = ((int16_t)MTR_CARRIER_CNT - 2) - p_st_sscs->s2_ad_point_b_adj_cnt;
    }
    else
    {
        /* A-point set to max_cmp - adjust */
        p_st_sscs->s2_ad_point_a_cnt = (int16_t)((p_st_sscs->s2_duty_max_adj_comp - (int16_t)MTR_DEADTIME_CNT)
                                                                            - p_st_sscs->s2_ad_point_b_adj_cnt);
    }
#else

        p_st_sscs->s2_ad_point_a_cnt = (int16_t)((p_st_sscs->s2_duty_max_adj_comp - (int16_t)MTR_DEADTIME_CNT)
                                    - p_st_sscs->s2_ad_point_b_adj_cnt);
#endif
    }
    R_MTR_GPT_THREE_PHASE_SetADCTrigger(g_three_phase0.p_ctrl, (uint16_t)p_st_sscs->s2_ad_point_a_cnt,
                                        (uint16_t)p_st_sscs->s2_ad_point_b_cnt);
} /* End of function mtr_conv_ad_ss_change */

#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
/***********************************************************************************************************************
* @fn             mtr_2phase_duty_cross
* @brief          Execute a 2-phase duty-cross
* @param[in,out]  p_st_ad_i       The pointer to the structure for ADC current
* @param[in,out]  p_st_repro_i    The pointer to the structure for current reproduction
* @param[in,out]  p_st_repro_id   The pointer to the structure for current reproduction in LPF d-axis
* @param[in,out]  p_st_repro_iq   The pointer to the structure for current reproduction in LPF q-axis
* @return         None
***********************************************************************************************************************/
static inline void mtr_2phase_duty_cross(st_coordinate28* p_st_ad_i, st_coordinate28* p_st_repro_i,
                                    st_mtr_lpf1_t* p_st_repro_id, st_mtr_lpf1_t* p_st_repro_iq)
{
    /* Calculate iq LPF */
    p_st_repro_i->ax_q = mtr_lpf1_run(p_st_repro_iq,
                                    p_st_ad_i->ax_q,
                                    MTR_Q_CURRENT_LPF_CO);

    /* Calculate iq LPF */
    p_st_repro_i->ax_d = mtr_lpf1_run(p_st_repro_id,
                                    p_st_ad_i->ax_d,
                                    MTR_Q_CURRENT_LPF_CO);

    /* Calculate reproduction current */
    R_motor_sincos_FIX28(&p_st_ad_i->st_angle);
    p_st_repro_i->st_angle.sin = p_st_ad_i->st_angle.sin;
    p_st_repro_i->st_angle.cos = p_st_ad_i->st_angle.cos;
    R_motor_dq2uvw_abs_FIX28(p_st_repro_i);
} /* End of function mtr_2phase_duty_cross */
#endif
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

/* USE_DEADTIME_COMP == MTR_SET */
#if (USE_DEADTIME_COMP == MTR_SET)
/***********************************************************************************************************************
* @fn             mtr_carrier_deadtime_comp
* @biref          Dead-time compensation
* @param[in,out]  p_st_ref_i    The pointer to the Coordinate system structure of current
* @param[in]      p_st_ref_v    The pointer to the Coordinate system structure of voltage
* @param[out]     p_st_s4_comp  The pointer to the structure for deadtime compensation
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_deadtime_comp(st_coordinate28 *p_st_ref_i,
                        st_coordinate28 *p_st_ref_v, st_mtr_s4_comp_t *p_st_s4_comp)
{
    int32_t s4_temp_deadtime_v;
    int32_t s4_th_current_deadtime;

    /* Transform dq to UVW */
    p_st_ref_i->st_angle.sin = p_st_ref_v->st_angle.sin;
    p_st_ref_i->st_angle.cos = p_st_ref_v->st_angle.cos;
    R_motor_dq2uvw_abs_FIX28(p_st_ref_i);

    /* Dead-time compensation */
	s4_temp_deadtime_v = FIX_fromfloat(MTR_DEADTIME_RATIO, MTR_Q_VOLTAGE);

    s4_th_current_deadtime = FIX_fromfloat(MTR_DEADTIME_CURRENT_LIMIT * PU_SF_CURRENT, MTR_Q_CURRENT);
    if (s4_th_current_deadtime < p_st_ref_i->ph_u)
    {
        p_st_s4_comp->s4_comp_vu = s4_temp_deadtime_v;
    }
    else if ((-s4_th_current_deadtime) > p_st_ref_i->ph_u)
    {
        p_st_s4_comp->s4_comp_vu = -s4_temp_deadtime_v;
    }
    else
    {
        p_st_s4_comp->s4_comp_vu = 0;
    }

    if (s4_th_current_deadtime < p_st_ref_i->ph_v)
    {
        p_st_s4_comp->s4_comp_vv = s4_temp_deadtime_v;
    }
    else if ((-s4_th_current_deadtime) > p_st_ref_i->ph_v)
    {
        p_st_s4_comp->s4_comp_vv = -s4_temp_deadtime_v;
    }
    else
    {
        p_st_s4_comp->s4_comp_vv = 0;
    }

    if (s4_th_current_deadtime < p_st_ref_i->ph_w)
    {
        p_st_s4_comp->s4_comp_vw = s4_temp_deadtime_v;
    }
    else if ((-s4_th_current_deadtime) > p_st_ref_i->ph_w)
    {
        p_st_s4_comp->s4_comp_vw = -s4_temp_deadtime_v;
    }
    else
    {
        p_st_s4_comp->s4_comp_vw = 0;
    }
} /* End of function mtr_carrier_deadtime_comp */
#endif /* USE_DEADTIME_COMP == MTR_SET */


/* SINGLE_SHUNT == CURRENT_SENS_METHOD */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_mod_ss
* @brief          Calculate modulation factor for Single Shunt
* @param[in,out]  p_st_mod      The pointer to the modulation structure
* @param[in,out]  p_st_ref_v    The pointer to the Coordinate system structure of voltage
* @param[out]     p_u1_drv_pat  The pointer of PWM drive pattern
* @param[in,out]  p_st_sscs     The pointer to the structure for sensing 1-shunt currents
* @param[in,out]  p_st_ref_i    The pointer to the Coordinate system structure of current
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_mod_ss(st_mtr_mod_t *p_st_mod, st_coordinate28 *p_st_ref_v, uint8_t *p_u1_drv_pat,
                        st_mtr_sscs_t *p_st_sscs, st_coordinate28 *p_st_ref_i)
{
    int32_t s4_u_cnt;
    int32_t s4_v_cnt;
    int32_t s4_w_cnt;
    int32_t s4_temp;
    int32_t s4_temp2;
#if (MOD_3PH_SPWM != MOD_METHOD)
    int32_t s4_v_min;
#endif
#if (MOD_3PH_TOW == MOD_METHOD)
    int32_t s4_v_max;
#elif (MOD_2PH_BOT == MOD_METHOD)
    int32_t s4_v_mid;
    int32_t s4_temp_v_diff;
    int32_t s4_com_mod;
    uint8_t u1_temp_min_pt;
#endif

#if (USE_DEADTIME_COMP == MTR_SET)
    st_mtr_s4_comp_t st_s4_comp;

    /* Deadtime compensation */
    mtr_carrier_deadtime_comp(p_st_ref_i, p_st_ref_v, &st_s4_comp);

    p_st_ref_v->ph_u += st_s4_comp.s4_comp_vu;
    p_st_ref_v->ph_v += st_s4_comp.s4_comp_vv;
    p_st_ref_v->ph_w += st_s4_comp.s4_comp_vw;
#endif

    /* Sort vu vv vw */
    if ((p_st_ref_v->ph_u >= p_st_ref_v->ph_v) && (p_st_ref_v->ph_u >= p_st_ref_v->ph_w))
    {
        if (p_st_ref_v->ph_v >= p_st_ref_v->ph_w)
        {
            (*p_u1_drv_pat) = MTR_DRV_UVW; /* U > V > W */
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = p_st_ref_v->ph_u;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = p_st_ref_v->ph_v;
            u1_temp_min_pt = MTR_PHASE_W; /* w */
#endif
#if (MOD_3PH_SPWM != MOD_METHOD)
            s4_v_min = p_st_ref_v->ph_w;
#endif
        }
        else
        {
            (*p_u1_drv_pat) = MTR_DRV_UWV; /* U > W > V */
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = p_st_ref_v->ph_u;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = p_st_ref_v->ph_w;
            u1_temp_min_pt = MTR_PHASE_V; /* v */
#endif
#if (MOD_3PH_SPWM != MOD_METHOD)
            s4_v_min = p_st_ref_v->ph_v;
#endif
        }
    }
    else if ((p_st_ref_v->ph_v >= p_st_ref_v->ph_u) && (p_st_ref_v->ph_v >= p_st_ref_v->ph_w))
    {
        if (p_st_ref_v->ph_u >= p_st_ref_v->ph_w)
        {
            (*p_u1_drv_pat) = MTR_DRV_VUW; /* V > U > W */
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = p_st_ref_v->ph_v;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = p_st_ref_v->ph_u;
            u1_temp_min_pt = MTR_PHASE_W; /* w */
#endif
#if (MOD_3PH_SPWM != MOD_METHOD)
            s4_v_min = p_st_ref_v->ph_w;
#endif
        }
        else
        {
            (*p_u1_drv_pat) = MTR_DRV_VWU; /* V > W > U */
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = p_st_ref_v->ph_v;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = p_st_ref_v->ph_w;
            u1_temp_min_pt = MTR_PHASE_U; /* u */
#endif
#if (MOD_3PH_SPWM != MOD_METHOD)
            s4_v_min = p_st_ref_v->ph_u;
#endif
        }
    }
    else
    {
        if (p_st_ref_v->ph_u >= p_st_ref_v->ph_v)
        {
            (*p_u1_drv_pat) = MTR_DRV_WUV; /* W > U > V */
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = p_st_ref_v->ph_w;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = p_st_ref_v->ph_u;
            u1_temp_min_pt = MTR_PHASE_V; /* v */
#endif
#if (MOD_3PH_SPWM != MOD_METHOD)
            s4_v_min = p_st_ref_v->ph_v;
#endif
        }
        else
        {
            (*p_u1_drv_pat) = MTR_DRV_WVU; /* W > V > U */
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = p_st_ref_v->ph_w;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = p_st_ref_v->ph_v;
            u1_temp_min_pt = MTR_PHASE_U; /* u */
#endif
#if (MOD_3PH_SPWM != MOD_METHOD)
            s4_v_min = p_st_ref_v->ph_u;
#endif
        }
    }

#if (MOD_2PH_BOT == MOD_METHOD)
    if (MTR_SET == p_st_sscs->u1_flag_mod_2ph)
    {
        s4_temp_v_diff = s4_v_mid - s4_v_min;
        if (u1_temp_min_pt != p_st_mod->u1_flg_uvw_min_pattern_pre)
        {
            if (u1_temp_min_pt != p_st_mod->u1_flg_uvw_min_pattern)
            {
                p_st_mod->s4_v_diff_sum += s4_temp_v_diff;
                if (p_st_mod->s4_v_diff_sum > p_st_mod->s2_cnt_2ph_bot_change)
                {
                    p_st_mod->u1_flg_uvw_min_pattern_pre = p_st_mod->u1_flg_uvw_min_pattern;
                    p_st_mod->u1_flg_uvw_min_pattern     = u1_temp_min_pt;
                    p_st_mod->s4_v_diff_sum          = 0;
                }
            }
        }
    }
#endif

#if (MOD_3PH_TOW == MOD_METHOD)
    int32_t s4_ref_v_com;
    s4_ref_v_com  = (int32_t)(s4_v_max + s4_v_min) >> 1;

    p_st_ref_v->ph_u -= s4_ref_v_com;
    p_st_ref_v->ph_v -= s4_ref_v_com;
    p_st_ref_v->ph_w -= s4_ref_v_com;
#endif

    /*=========================*/
    /*     Voltage limiter     */
    /*=========================*/
    mtr_carrier_lim_uvw_voltage(&p_st_ref_v->ph_u, p_st_mod->s4_lim_vout);

    /* Duty in Q12 format */
    p_st_mod->s4_mod_u = FIX_mul_rs(p_st_ref_v->ph_u, p_st_mod->s4_ad_reci_vdc,
                            MTR_Q_VOLTAGE + MTR_Q_RECIV - MTR_Q_VMOD);
    p_st_mod->s4_mod_v = FIX_mul_rs(p_st_ref_v->ph_v, p_st_mod->s4_ad_reci_vdc,
                            MTR_Q_VOLTAGE + MTR_Q_RECIV - MTR_Q_VMOD);
    p_st_mod->s4_mod_w = FIX_mul_rs(p_st_ref_v->ph_w, p_st_mod->s4_ad_reci_vdc,
                            MTR_Q_VOLTAGE + MTR_Q_RECIV - MTR_Q_VMOD);

#if (MOD_2PH_BOT == MOD_METHOD)
    if (MTR_SET == p_st_sscs->u1_flag_mod_2ph)
    {
        if (MTR_PHASE_U == u1_temp_min_pt)
        {
            s4_com_mod = MTR_PWM_DUTY_RANGE + p_st_mod->s4_mod_u;
        }
        else if (MTR_PHASE_V == u1_temp_min_pt)
        {
            s4_com_mod = MTR_PWM_DUTY_RANGE + p_st_mod->s4_mod_v;
        }
        else if (MTR_PHASE_W == u1_temp_min_pt)
        {
            s4_com_mod = MTR_PWM_DUTY_RANGE + p_st_mod->s4_mod_w;
        }
        p_st_mod->s4_mod_u -= s4_com_mod;
        p_st_mod->s4_mod_v -= s4_com_mod;
        p_st_mod->s4_mod_w -= s4_com_mod;
    }
#endif

    /* Translate to Timer counts */
    s4_u_cnt = mtr_limit_abs(-(p_st_mod->s4_mod_u), MTR_PWM_DUTY_RANGE);
    s4_v_cnt = mtr_limit_abs(-(p_st_mod->s4_mod_v), MTR_PWM_DUTY_RANGE);
    s4_w_cnt = mtr_limit_abs(-(p_st_mod->s4_mod_w), MTR_PWM_DUTY_RANGE);

#if (MOD_2PH_BOT == MOD_METHOD)
    if (MTR_SET == p_st_sscs->u1_flag_mod_2ph)
    {
        /* s2_temp is signed integer */
        s4_temp  = (int16_t) (MTR_DUTY_RANGE_CNT);
        s4_temp2 = ((MTR_HALF_CARRIER_CNT + MTR_HALF_DEADTIME_CNT) - 1);

        /* s4_u_cnt is signed integer */
        s4_u_cnt = ((s4_temp * (s4_u_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
        if (MTR_PHASE_U == u1_temp_min_pt)
        {
            s4_u_cnt = MTR_LOWEST_DUTY_CNT;
        }

        /* s4_v_cnt is signed integer */
        s4_v_cnt = ((s4_temp * (s4_v_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
        if (MTR_PHASE_V == u1_temp_min_pt)
        {
            s4_v_cnt = MTR_LOWEST_DUTY_CNT;
        }

        /* s4_w_cnt is signed integer */
        s4_w_cnt = ((s4_temp * (s4_w_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
        if (MTR_PHASE_W == u1_temp_min_pt)
        {
            s4_w_cnt = MTR_LOWEST_DUTY_CNT;
        }
    }
    else
    {
        /* calculate count(unsigned) to temporary value(signed) */
        s4_temp  = (MTR_HALF_CARRIER_CNT);
        s4_temp2 = ((MTR_HALF_CARRIER_CNT + MTR_HALF_DEADTIME_CNT) - 1);
        s4_u_cnt = ((s4_temp * (s4_u_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
        s4_v_cnt = ((s4_temp * (s4_v_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
        s4_w_cnt = ((s4_temp * (s4_w_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
    }
#else /* (MOD_2PH_BOT == MOD_METHOD) */
    /* calculate count(unsigned) to temporary value(signed) */
    s4_temp  = (MTR_HALF_CARRIER_CNT);
    s4_temp2 = ((MTR_HALF_CARRIER_CNT + MTR_HALF_DEADTIME_CNT) - 1);
    s4_u_cnt = ((s4_temp * (s4_u_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
    s4_v_cnt = ((s4_temp * (s4_v_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
    s4_w_cnt = ((s4_temp * (s4_w_cnt >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY) + s4_temp2;
#endif /* (MOD_2PH_BOT == MOD_METHOD) */
    p_st_sscs->s2_duty_u = (int16_t)(s4_u_cnt);
    p_st_sscs->s2_duty_v = (int16_t)(s4_v_cnt);
    p_st_sscs->s2_duty_w = (int16_t)(s4_w_cnt);

    switch ((*p_u1_drv_pat))
    {
        case MTR_DRV_WUV: /* W > U > V */
            p_st_sscs->s2_duty_max = p_st_sscs->s2_duty_v;
            p_st_sscs->s2_duty_mid = p_st_sscs->s2_duty_u;
            p_st_sscs->s2_duty_min = p_st_sscs->s2_duty_w;
            break;

        case MTR_DRV_UVW: /* U > V > W */
            p_st_sscs->s2_duty_max = p_st_sscs->s2_duty_w;
            p_st_sscs->s2_duty_mid = p_st_sscs->s2_duty_v;
            p_st_sscs->s2_duty_min = p_st_sscs->s2_duty_u;
            break;

        case MTR_DRV_UWV: /* U > W > V */
            p_st_sscs->s2_duty_max = p_st_sscs->s2_duty_v;
            p_st_sscs->s2_duty_mid = p_st_sscs->s2_duty_w;
            p_st_sscs->s2_duty_min = p_st_sscs->s2_duty_u;
            break;

        case MTR_DRV_WVU: /* W > V > U */
            p_st_sscs->s2_duty_max = p_st_sscs->s2_duty_u;
            p_st_sscs->s2_duty_mid = p_st_sscs->s2_duty_v;
            p_st_sscs->s2_duty_min = p_st_sscs->s2_duty_w;
            break;

        case MTR_DRV_VUW: /* V > U > W */
            p_st_sscs->s2_duty_max = p_st_sscs->s2_duty_w;
            p_st_sscs->s2_duty_mid = p_st_sscs->s2_duty_u;
            p_st_sscs->s2_duty_min = p_st_sscs->s2_duty_v;
            break;

        case MTR_DRV_VWU: /* V > W > U */
            p_st_sscs->s2_duty_max = p_st_sscs->s2_duty_u;
            p_st_sscs->s2_duty_mid = p_st_sscs->s2_duty_w;
            p_st_sscs->s2_duty_min = p_st_sscs->s2_duty_v;
            break;

        default:
            p_st_sscs->s2_duty_max = p_st_sscs->s2_duty_w;
            p_st_sscs->s2_duty_mid = p_st_sscs->s2_duty_v;
            p_st_sscs->s2_duty_min = p_st_sscs->s2_duty_u;
            break;
    }
} /* End of function mtr_carrier_mod_ss */
#endif /* SINGLE_SHUNT == CURRENT_SENS_METHOD */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)

/***********************************************************************************************************************
* @fn             mtr_carrier_mod_ts
* @brief          Calculate modulation factor for Three Shunt
* @param[in,out]  p_st_mod      The pointer to the modulation structure
* @param[in,out]  p_st_ref_v    The pointer to the reference voltage
* @param[in,out]  p_st_ref_i    The pointer to the Coordinate system structure of current
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_mod_ts(st_mtr_mod_t *p_st_mod, st_coordinate28 *p_st_ref_v,
                                        st_coordinate28 *p_st_ref_i)
{
#if (MOD_3PH_SPWM != MOD_METHOD)
#if (MOD_3PH_TOW == MOD_METHOD)
    int32_t s4_v_max;
#elif (MOD_2PH_BOT == MOD_METHOD)
    int32_t s4_v_mid;
    int32_t s4_temp_v_diff;
    int32_t s4_com_mod;
    uint8_t u1_temp_min_pt;
#endif
    int32_t s4_v_min;
#endif

#if (USE_DEADTIME_COMP == MTR_SET)
    st_mtr_s4_comp_t st_s4_comp;

    /* Deadtime compensation */
    mtr_carrier_deadtime_comp(p_st_ref_i, p_st_ref_v, &st_s4_comp);

#if (MOD_2PH_BOT != MOD_METHOD)
    p_st_ref_v->ph_u += st_s4_comp.s4_comp_vu;
    p_st_ref_v->ph_v += st_s4_comp.s4_comp_vv;
    p_st_ref_v->ph_w += st_s4_comp.s4_comp_vw;
#endif
#else
    FSP_PARAMETER_NOT_USED(p_st_ref_i);
#endif

#if (MOD_3PH_SPWM != MOD_METHOD)
    /* Sort vu vv vw */
    if ((p_st_ref_v->ph_u >= p_st_ref_v->ph_v) && (p_st_ref_v->ph_u >= p_st_ref_v->ph_w))
    {
        if (p_st_ref_v->ph_v >= p_st_ref_v->ph_w)
        {
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = (int32_t)p_st_ref_v->ph_u;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = (int32_t)p_st_ref_v->ph_v;
            u1_temp_min_pt = MTR_PHASE_W;/* w */
#endif
            s4_v_min = (int32_t)p_st_ref_v->ph_w;
        }
        else
        {
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = (int32_t)p_st_ref_v->ph_u;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = (int32_t)p_st_ref_v->ph_w;
            u1_temp_min_pt = MTR_PHASE_V;/* v */
#endif
            s4_v_min = (int32_t)p_st_ref_v->ph_v;
        }
    }
    else if ((p_st_ref_v->ph_v >= p_st_ref_v->ph_u) && (p_st_ref_v->ph_v >= p_st_ref_v->ph_w))
    {
        if (p_st_ref_v->ph_u >= p_st_ref_v->ph_w)
        {
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = (int32_t)p_st_ref_v->ph_v;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = (int32_t)p_st_ref_v->ph_u;
            u1_temp_min_pt = MTR_PHASE_W;/* w */
#endif
            s4_v_min = (int32_t)p_st_ref_v->ph_w;
        }
        else
        {
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = (int32_t)p_st_ref_v->ph_v;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = (int32_t)p_st_ref_v->ph_w;
            u1_temp_min_pt = MTR_PHASE_U;/* u */
#endif
            s4_v_min = (int32_t)p_st_ref_v->ph_u;
        }
    }
    else
    {
        if (p_st_ref_v->ph_u >= p_st_ref_v->ph_v)
        {
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = (int32_t)p_st_ref_v->ph_w;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = (int32_t)p_st_ref_v->ph_u;
            u1_temp_min_pt = MTR_PHASE_V;/* v */
#endif
            s4_v_min = (int32_t)p_st_ref_v->ph_v;
        }
        else
        {
#if (MOD_3PH_TOW == MOD_METHOD)
            s4_v_max = (int32_t)p_st_ref_v->ph_w;
#elif (MOD_2PH_BOT == MOD_METHOD)
            s4_v_mid       = (int32_t)p_st_ref_v->ph_v;
            u1_temp_min_pt = MTR_PHASE_U;/* u */
#endif
            s4_v_min = (int32_t)p_st_ref_v->ph_u;
        }
    }

#if (USE_DEADTIME_COMP == MTR_SET)
#if (MOD_2PH_BOT == MOD_METHOD)
    p_st_ref_v->ph_u += st_s4_comp.s4_comp_vu;
    p_st_ref_v->ph_v += st_s4_comp.s4_comp_vv;
    p_st_ref_v->ph_w += st_s4_comp.s4_comp_vw;
#endif
#endif


#if (MOD_2PH_BOT == MOD_METHOD)
    s4_temp_v_diff = s4_v_mid - s4_v_min;
    if (0 != p_st_mod->s2_cnt_2ph_bot_change)
    {
        if (u1_temp_min_pt != p_st_mod->u1_flg_uvw_min_pattern_pre)
        {
            if (u1_temp_min_pt != p_st_mod->u1_flg_uvw_min_pattern)
            {
                p_st_mod->s4_v_diff_sum += s4_temp_v_diff;
                if (p_st_mod->s4_v_diff_sum > p_st_mod->s2_cnt_2ph_bot_change)
                {
                    p_st_mod->u1_flg_uvw_min_pattern_pre = p_st_mod->u1_flg_uvw_min_pattern;
                    p_st_mod->u1_flg_uvw_min_pattern     = u1_temp_min_pt;
                    p_st_mod->s4_v_diff_sum              = 0;
                }
            }
        }
    }
    else
    {
        if (u1_temp_min_pt != p_st_mod->u1_flg_uvw_min_pattern)
        {
            p_st_mod->u1_flg_uvw_min_pattern_pre = p_st_mod->u1_flg_uvw_min_pattern;
            p_st_mod->u1_flg_uvw_min_pattern     = u1_temp_min_pt;
        }
    }
#endif

#if (MOD_3PH_TOW == MOD_METHOD)
    int32_t s4_ref_v_com;
    s4_ref_v_com  = (int32_t)(s4_v_max + s4_v_min) >> 1;

    p_st_ref_v->ph_u -= s4_ref_v_com;
    p_st_ref_v->ph_v -= s4_ref_v_com;
    p_st_ref_v->ph_w -= s4_ref_v_com;
#endif

#endif /* (MOD_3PH_SPWM != MOD_METHOD) */

    /*=========================*/
    /*     Voltage limiter     */
    /*=========================*/
    mtr_carrier_lim_uvw_voltage((int32_t*)&p_st_ref_v->ph_u, p_st_mod->s4_lim_vout);

    /* Voltage -> MOD : Q12 format */
    p_st_mod->s4_mod_u = FIX_mul_rs(p_st_ref_v->ph_u, p_st_mod->s4_ad_reci_vdc,
                            MTR_Q_VOLTAGE + MTR_Q_RECIV - MTR_Q_VMOD);
    p_st_mod->s4_mod_v = FIX_mul_rs(p_st_ref_v->ph_v, p_st_mod->s4_ad_reci_vdc,
                            MTR_Q_VOLTAGE + MTR_Q_RECIV - MTR_Q_VMOD);
    p_st_mod->s4_mod_w = FIX_mul_rs(p_st_ref_v->ph_w, p_st_mod->s4_ad_reci_vdc,
                            MTR_Q_VOLTAGE + MTR_Q_RECIV - MTR_Q_VMOD);

#if (MOD_2PH_BOT == MOD_METHOD)
    if (MTR_PHASE_U == u1_temp_min_pt)
    {
        s4_com_mod = MTR_PWM_DUTY_RANGE + p_st_mod->s4_mod_u;
    }
    else if (MTR_PHASE_V == u1_temp_min_pt)
    {
        s4_com_mod = MTR_PWM_DUTY_RANGE + p_st_mod->s4_mod_v;
    }
    else if (MTR_PHASE_W == u1_temp_min_pt)
    {
        s4_com_mod = MTR_PWM_DUTY_RANGE + p_st_mod->s4_mod_w;
    }
    p_st_mod->s4_mod_u -= s4_com_mod;
    p_st_mod->s4_mod_v -= s4_com_mod;
    p_st_mod->s4_mod_w -= s4_com_mod;
#endif

} /* End of function mtr_carrier_mod_ts */
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_pwm_duty_ss
* @brief          Calculate PWM duty with adjustment for A/D conversion
* @param[in,out]  p_st_sscs   The pointer to the single-shunt current sensing structure
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_pwm_duty_ss(st_mtr_sscs_t *p_st_sscs)
{
    const int32_t s4_w_half = MTR_PWM_SHIFT_TIMER_HALF;
    const int32_t s4_w_all  = MTR_PWM_SHIFT_TIMER_HALF << 1;
    int32_t       s4_w_max;    /* Width of maximum duty */
    int32_t       s4_w_mid;    /* Width of medium duty */
    int32_t       s4_w_min;    /* Width of minimum duty */
    int32_t       s4_w_time_a; /* A point delay adjustment count of A/D */
    int32_t       s4_w_time_b; /* B point delay adjustment count of A/D */
    int32_t       s4_temp;

    /* '------------------------------------------- */
    /* ' Variable Settings                          */
    /* '------------------------------------------- */

    s4_w_max = s4_w_all - (p_st_sscs->s2_duty_max << 1);
    s4_w_mid = s4_w_all - (p_st_sscs->s2_duty_mid << 1);
    s4_w_min = s4_w_all - (p_st_sscs->s2_duty_min << 1);

    s4_w_time_a = p_st_sscs->s2_ad_point_a_adj_cnt + MTR_PWM_SHIFT_DEADTIME + MTR_PWM_SHIFT_AD_CONVERT_CNT;
    s4_w_time_b = p_st_sscs->s2_ad_point_b_adj_cnt + MTR_PWM_SHIFT_DEADTIME + MTR_PWM_SHIFT_AD_CONVERT_CNT;

    /* '------------------------------------------- */
    /* ' Determination 1: Is there enough time secured for current detection? */
    /* '------------------------------------------- */

    if (((p_st_sscs->s2_duty_max - p_st_sscs->s2_duty_mid) > s4_w_time_b) &&
        ((p_st_sscs->s2_duty_mid - p_st_sscs->s2_duty_min) > s4_w_time_a))
    {
        /* ' Do not offset  */
        p_st_sscs->s2_duty_max_adj      = p_st_sscs->s2_duty_max;
        p_st_sscs->s2_duty_max_adj_comp = p_st_sscs->s2_duty_max;
        p_st_sscs->s2_duty_mid_adj      = p_st_sscs->s2_duty_mid;
        p_st_sscs->s2_duty_mid_adj_comp = p_st_sscs->s2_duty_mid;
        p_st_sscs->s2_duty_min_adj      = p_st_sscs->s2_duty_min;
        p_st_sscs->s2_duty_min_adj_comp = p_st_sscs->s2_duty_min;

        return;
    }

    /* '------------------------------------------- */
    /* ' Determination 2: Is PWM shifting possible? + Duty shift */
    /* '------------------------------------------- */

    /* ' Determination 2-1 */
    if (s4_w_min < (s4_w_time_a + s4_w_time_b - MTR_PWM_SHIFT_DEADTIME))
    {
        /* ' [memo]  */
        /* ' When the minimum phase count is [Duty 19% or less]  */
#if (USE_DUTY_SHIFT == MTR_SET)

        /* ' Extend the High width with Duty shift  */
        s4_temp  = s4_w_time_a + s4_w_time_b - MTR_PWM_SHIFT_DEADTIME;
        s4_w_max = s4_w_max - s4_w_min + s4_temp;
        s4_w_mid = s4_w_mid - s4_w_min + s4_temp;
        s4_w_min = s4_temp;
        p_st_sscs->u1_drv_pattern_set |= MTR_DRV_DUTY_SHIFT_RUN;

        /* ' [memo]  */
        /* ' No determination needed after Duty shift. */
        /* ' Because the High width of the minimum phase count is the longest. */
#else

        /* ' Cannot detect current */
        mtr_carrier_pwm_duty_nonadc_ss(p_st_sscs);
        return;
#endif
    }

    /* ' Determination 2-2  */
    if (s4_w_mid < (s4_w_time_b - MTR_PWM_SHIFT_DEADTIME))
    {
        /* ' [memo]  */
        /* ' When the middle phase count is [Duty 11% or less]  */
#if (USE_DUTY_SHIFT == MTR_SET)

        /* ' Extend the High width with Duty shift  */
        s4_temp  = s4_w_time_b - MTR_PWM_SHIFT_DEADTIME;
        s4_w_max = s4_w_max - s4_w_mid + s4_temp;
        s4_w_min = s4_w_min - s4_w_mid + s4_temp;
        s4_w_mid = s4_temp;
        p_st_sscs->u1_drv_pattern_set |= MTR_DRV_DUTY_SHIFT_RUN;

        /* ' Determination after Duty shift  */
        if (s4_w_min > s4_w_all)
        {
            /* ' Cannot detect current  */
            mtr_carrier_pwm_duty_nonadc_ss(p_st_sscs);
            return;
        }
#else

        /* ' Cannot detect current  */
        mtr_carrier_pwm_duty_nonadc_ss(p_st_sscs);
        return;
#endif
    }

    /* ' Determination 2-3  */
    if (s4_w_mid > (s4_w_all - (s4_w_time_a + (MTR_PWM_SHIFT_DEADTIME << 1))))
    {
        /* ' [memo]  */
        /* ' When the middle phase count is [Duty 85% or more]  */
#if (USE_DUTY_SHIFT == MTR_SET)

        /* ' Reduce the High width with Duty shift  */
        s4_temp  = s4_w_all - (s4_w_time_a + (MTR_PWM_SHIFT_DEADTIME << 1));
        s4_w_max = s4_w_max - s4_w_mid + s4_temp;
        s4_w_min = s4_w_min - s4_w_mid + s4_temp;
        s4_w_mid = s4_temp;
        p_st_sscs->u1_drv_pattern_set |= MTR_DRV_DUTY_SHIFT_RUN;

        /* ' Determination after Duty shift  */
        if (s4_w_max < (-(MTR_PWM_SHIFT_DEADTIME << 1)))
        {
            /* ' Cannot detect current  */
            mtr_carrier_pwm_duty_nonadc_ss(p_st_sscs);
            return;
        }
#else

        /* ' Cannot detect current  */
        mtr_carrier_pwm_duty_nonadc_ss(p_st_sscs);
        return;
#endif
    }

    /* '------------------------------------------- */
    /* ' PWM Shift 1: Count Minimum Phase           */
    /* '------------------------------------------- */

    if (s4_w_min <= (s4_w_half - MTR_PWM_SHIFT_DEADTIME))
    {
        /* ' When the width is small  */
        s4_temp                         = s4_w_half - s4_w_min;
        p_st_sscs->s2_duty_min_adj      = (int16_t)(MTR_PWM_SHIFT_TIMER_NEAR_0);
        p_st_sscs->s2_duty_min_adj_comp = (int16_t)(s4_temp);

        /* ' [memo]  */
        /* ' PWM shift is possible within the range of [Duty 20% or more]  */
    }
    else
    {
        /* ' When the width is large  */
        s4_temp = s4_w_all - MTR_PWM_SHIFT_TIMER_NEAR_100 - s4_w_min;
        if (s4_temp >= 0)
        {
            /* ' Expansion process: Up-count side  */
            p_st_sscs->s2_duty_min_adj      = (int16_t)(s4_temp);
            p_st_sscs->s2_duty_min_adj_comp = (int16_t)(MTR_PWM_SHIFT_TIMER_NEAR_100);
        }
        else
        {
            /* ' Expansion process: Down-count side  */
            p_st_sscs->s2_duty_min_adj      = (int16_t)(MTR_PWM_SHIFT_TIMER_SET_100);
            p_st_sscs->s2_duty_min_adj_comp = (int16_t)(MTR_PWM_SHIFT_TIMER_NEAR_100 + s4_temp);
        }
    }

    /* '------------------------------------------- */
    /* ' PWM Shift 2: Count Middle Phase            */
    /* '------------------------------------------- */

    s4_temp = p_st_sscs->s2_duty_min_adj_comp + s4_w_time_a;
    if (s4_w_mid <= (s4_w_half - s4_temp))
    {
        /* ' When the width is small  */
        s4_temp                         = s4_w_half - s4_w_mid;
        p_st_sscs->s2_duty_mid_adj      = (int16_t)(MTR_PWM_SHIFT_TIMER_NEAR_0);
        p_st_sscs->s2_duty_mid_adj_comp = (int16_t)(s4_temp);

        /* ' [memo]  */
        /* ' PWM shift is possible within the range of [Duty 12% or more]  */
    }
    else
    {
        /* ' When the width is large  */
        p_st_sscs->s2_duty_mid_adj      = (int16_t)(s4_w_all - s4_temp - s4_w_mid);
        p_st_sscs->s2_duty_mid_adj_comp = (int16_t)(s4_temp);

        /* ' [memo]  */
        /* ' PWM shift is possible within the range of [Duty 84% or less]  */
    }

    /* '------------------------------------------- */
    /* ' PWM Shift 3: Count Maximum Phase           */
    /* '------------------------------------------- */

    s4_temp = p_st_sscs->s2_duty_mid_adj_comp + s4_w_time_b;
    if (s4_w_max <= (s4_w_half - s4_temp))
    {

        /* ' When the width is small  */
        if (s4_w_max <= (s4_w_half - MTR_PWM_SHIFT_TIMER_SET_0))
        {
            /* ' Near Duty 0% [Duty 3% or less]  */
            p_st_sscs->s2_duty_max_adj      = (int16_t)(s4_w_all - s4_w_max - MTR_PWM_SHIFT_TIMER_SET_0);
            p_st_sscs->s2_duty_max_adj_comp = (int16_t)(MTR_PWM_SHIFT_TIMER_SET_0);
        }
        else
        {
            /* ' Near Duty 0% [Duty 4% or more]  */
            s4_temp                         = s4_w_half - s4_w_max;
            p_st_sscs->s2_duty_max_adj      = (int16_t)(MTR_PWM_SHIFT_TIMER_NEAR_0);
            p_st_sscs->s2_duty_max_adj_comp = (int16_t)(s4_temp);
        }
    }
    else
    {
        /* ' When the width is large  */
        p_st_sscs->s2_duty_max_adj      = (int16_t)(s4_w_all - s4_temp - s4_w_max);
        p_st_sscs->s2_duty_max_adj_comp = (int16_t)(s4_temp);

        /* ' [memo]  */
        /* ' PWM shift is possible within the range of [Duty 76% or less]  */
    }
} /* End of function mtr_carrier_pwm_duty_ss */

/***********************************************************************************************************************
* @fn             mtr_carrier_pwm_duty_nonadc_ss
* @brief          Calculate PWM duty with adjustment for A/D conversion
* @param[in,out]  p_st_sscs   The pointer to the single-shunt current sensing structure
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_pwm_duty_nonadc_ss(st_mtr_sscs_t *p_st_sscs)
{
    // ' Cannot detect current
    p_st_sscs->u1_drv_pattern_set |= MTR_DRV_CURRENT_UNAVAILABLE;

    // ' Do not offset
    p_st_sscs->s2_duty_max_adj      = p_st_sscs->s2_duty_max;
    p_st_sscs->s2_duty_max_adj_comp = p_st_sscs->s2_duty_max;
    p_st_sscs->s2_duty_mid_adj      = p_st_sscs->s2_duty_mid;
    p_st_sscs->s2_duty_mid_adj_comp = p_st_sscs->s2_duty_mid;
    p_st_sscs->s2_duty_min_adj      = p_st_sscs->s2_duty_min;
    p_st_sscs->s2_duty_min_adj_comp = p_st_sscs->s2_duty_min;
} /* End of function mtr_carrier_pwm_duty_nonadc_ss */
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_pwm_duty_ts
* @brief          Calculate PWM duty for Three Shunt
* @param[in,out]  p_st_tscs           The pointer to the structure for sensing 3-shunt currents
* @param[in]      p_st_mod            UVW phase duty and Minimum voltage pattern
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_pwm_duty_ts(st_mtr_tscs_t *p_st_tscs, st_mtr_mod_t* p_st_mod)
{
    /* MTR_HALF_CARRIER_CNT will be cast to signed */
#if (MOD_2PH_BOT == MOD_METHOD)
    p_st_tscs->s2_duty_u
        = mtr_carrier_pwm_duty_calc(p_st_mod->s4_mod_u, p_st_mod->u1_flg_uvw_min_pattern, MTR_PHASE_U);
    p_st_tscs->s2_duty_v
        = mtr_carrier_pwm_duty_calc(p_st_mod->s4_mod_v, p_st_mod->u1_flg_uvw_min_pattern, MTR_PHASE_V);
    p_st_tscs->s2_duty_w
        = mtr_carrier_pwm_duty_calc(p_st_mod->s4_mod_w, p_st_mod->u1_flg_uvw_min_pattern, MTR_PHASE_W);

#else
    FSP_PARAMETER_NOT_USED(p_st_mod->u1_flg_uvw_min_pattern);

    p_st_tscs->s2_duty_u = mtr_carrier_pwm_duty_calc(p_st_mod->s4_mod_u);
    p_st_tscs->s2_duty_v = mtr_carrier_pwm_duty_calc(p_st_mod->s4_mod_v);
    p_st_tscs->s2_duty_w = mtr_carrier_pwm_duty_calc(p_st_mod->s4_mod_w);

#endif
} /* End of function mtr_carrier_pwm_duty_ts */
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_set_duty_adj_ss
* @brief          Set adjustment PWM duty
* @param[in,out]  p_st_sscs   The pointer to the single-shunt current sensing structure
* @return         None
***********************************************************************************************************************/
static inline void mtr_set_duty_adj_ss(st_mtr_sscs_t *p_st_sscs)
{
    switch (p_st_sscs->u1_drv_pattern_set & MTR_DRV_MASK)
    {
        case MTR_DRV_UVW:                           /* U > V > W */
            p_st_sscs->s2_duty_u_adj  = p_st_sscs->s2_duty_min_adj;
            p_st_sscs->s2_duty_v_adj  = p_st_sscs->s2_duty_mid_adj;
            p_st_sscs->s2_duty_w_adj  = p_st_sscs->s2_duty_max_adj;
            p_st_sscs->s2_duty_u_adjc = p_st_sscs->s2_duty_min_adj_comp;
            p_st_sscs->s2_duty_v_adjc = p_st_sscs->s2_duty_mid_adj_comp;
            p_st_sscs->s2_duty_w_adjc = p_st_sscs->s2_duty_max_adj_comp;
            break;

        case MTR_DRV_UWV:                           /* U > W > V */
            p_st_sscs->s2_duty_u_adj  = p_st_sscs->s2_duty_min_adj;
            p_st_sscs->s2_duty_v_adj  = p_st_sscs->s2_duty_max_adj;
            p_st_sscs->s2_duty_w_adj  = p_st_sscs->s2_duty_mid_adj;
            p_st_sscs->s2_duty_u_adjc = p_st_sscs->s2_duty_min_adj_comp;
            p_st_sscs->s2_duty_v_adjc = p_st_sscs->s2_duty_max_adj_comp;
            p_st_sscs->s2_duty_w_adjc = p_st_sscs->s2_duty_mid_adj_comp;
            break;

        case MTR_DRV_VUW:                           /* V > U > W */
            p_st_sscs->s2_duty_u_adj  = p_st_sscs->s2_duty_mid_adj;
            p_st_sscs->s2_duty_v_adj  = p_st_sscs->s2_duty_min_adj;
            p_st_sscs->s2_duty_w_adj  = p_st_sscs->s2_duty_max_adj;
            p_st_sscs->s2_duty_u_adjc = p_st_sscs->s2_duty_mid_adj_comp;
            p_st_sscs->s2_duty_v_adjc = p_st_sscs->s2_duty_min_adj_comp;
            p_st_sscs->s2_duty_w_adjc = p_st_sscs->s2_duty_max_adj_comp;
            break;

        case MTR_DRV_VWU:                           /* V > W > U */
            p_st_sscs->s2_duty_u_adj  = p_st_sscs->s2_duty_max_adj;
            p_st_sscs->s2_duty_v_adj  = p_st_sscs->s2_duty_min_adj;
            p_st_sscs->s2_duty_w_adj  = p_st_sscs->s2_duty_mid_adj;
            p_st_sscs->s2_duty_u_adjc = p_st_sscs->s2_duty_max_adj_comp;
            p_st_sscs->s2_duty_v_adjc = p_st_sscs->s2_duty_min_adj_comp;
            p_st_sscs->s2_duty_w_adjc = p_st_sscs->s2_duty_mid_adj_comp;
            break;

        case MTR_DRV_WUV:                           /* W > U > V */
            p_st_sscs->s2_duty_u_adj  = p_st_sscs->s2_duty_mid_adj;
            p_st_sscs->s2_duty_v_adj  = p_st_sscs->s2_duty_max_adj;
            p_st_sscs->s2_duty_w_adj  = p_st_sscs->s2_duty_min_adj;
            p_st_sscs->s2_duty_u_adjc = p_st_sscs->s2_duty_mid_adj_comp;
            p_st_sscs->s2_duty_v_adjc = p_st_sscs->s2_duty_max_adj_comp;
            p_st_sscs->s2_duty_w_adjc = p_st_sscs->s2_duty_min_adj_comp;
            break;

        case MTR_DRV_WVU:                           /* W > V > U */
            p_st_sscs->s2_duty_u_adj  = p_st_sscs->s2_duty_max_adj;
            p_st_sscs->s2_duty_v_adj  = p_st_sscs->s2_duty_mid_adj;
            p_st_sscs->s2_duty_w_adj  = p_st_sscs->s2_duty_min_adj;
            p_st_sscs->s2_duty_u_adjc = p_st_sscs->s2_duty_max_adj_comp;
            p_st_sscs->s2_duty_v_adjc = p_st_sscs->s2_duty_mid_adj_comp;
            p_st_sscs->s2_duty_w_adjc = p_st_sscs->s2_duty_min_adj_comp;
            break;

        default:
            p_st_sscs->s2_duty_u_adj  = (MTR_HALF_CARRIER_CNT - 1);
            p_st_sscs->s2_duty_v_adj  = (MTR_HALF_CARRIER_CNT - 1);
            p_st_sscs->s2_duty_w_adj  = (MTR_HALF_CARRIER_CNT - 1);
            p_st_sscs->s2_duty_u_adjc = (MTR_HALF_CARRIER_CNT - 1);
            p_st_sscs->s2_duty_v_adjc = (MTR_HALF_CARRIER_CNT - 1);
            p_st_sscs->s2_duty_w_adjc = (MTR_HALF_CARRIER_CNT - 1);
            break;
    }

    three_phase_duty_cycle_t duty_cycle;
    duty_cycle.duty[THREE_PHASE_CHANNEL_U]        = (uint32_t)p_st_sscs->s2_duty_u_adj;
    duty_cycle.duty[THREE_PHASE_CHANNEL_V]        = (uint32_t)p_st_sscs->s2_duty_v_adj;
    duty_cycle.duty[THREE_PHASE_CHANNEL_W]        = (uint32_t)p_st_sscs->s2_duty_w_adj;
    duty_cycle.duty_buffer[THREE_PHASE_CHANNEL_U] = (uint32_t)p_st_sscs->s2_duty_u_adjc;
    duty_cycle.duty_buffer[THREE_PHASE_CHANNEL_V] = (uint32_t)p_st_sscs->s2_duty_v_adjc;
    duty_cycle.duty_buffer[THREE_PHASE_CHANNEL_W] = (uint32_t)p_st_sscs->s2_duty_w_adjc;
    R_MTR_GPT_THREE_PHASE_CompMode3_DutyCycleSet(g_three_phase0.p_ctrl, &duty_cycle);
} /* End of function mtr_set_duty_adj_ss */
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

/***********************************************************************************************************************
* @fn             mtr_carrier_lim_uvw_voltage
* @brief          Limit with absolute value for three-phase voltae
* @param[in,out]  p_s4_ref_v_uvw     The pointer to the three-phase voltage
* @param[in]      s4_voltage_limit   Limit value [PU(V)]
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_lim_uvw_voltage(int32_t *p_s4_ref_v_uvw, int32_t s4_voltage_limit)
{
    /* Vu */
    if (p_s4_ref_v_uvw[0] > s4_voltage_limit)
    {
        p_s4_ref_v_uvw[0] = s4_voltage_limit;
    }
    else if (p_s4_ref_v_uvw[0] < (-s4_voltage_limit))
    {
        p_s4_ref_v_uvw[0] = -s4_voltage_limit;
    }

    /* Vv */
    if (p_s4_ref_v_uvw[1] > s4_voltage_limit)
    {
        p_s4_ref_v_uvw[1] = s4_voltage_limit;
    }
    else if (p_s4_ref_v_uvw[1] < (-s4_voltage_limit))
    {
        p_s4_ref_v_uvw[1] = -s4_voltage_limit;
    }

    /* Vw */
    if (p_s4_ref_v_uvw[2] > s4_voltage_limit)
    {
        p_s4_ref_v_uvw[2] = s4_voltage_limit;
    }
    else if (p_s4_ref_v_uvw[2] < (-s4_voltage_limit))
    {
        p_s4_ref_v_uvw[2] = -s4_voltage_limit;
    }
} /* End of function mtr_carrier_lim_uvw_voltage */

/**********************************************************************************************************************
* @fn             mtr_carrier_startup_sequence
* @brief          Do processes while drive is not started
* @return         None
***********************************************************************************************************************/
static inline void mtr_carrier_startup_sequence(void)
{
    /* Calibrate A/D offset */
    if ((MTR_OFFSET_CALC_EXE == g_st_foc_common.u1_state_drive) &&
        (MTR_CLR             == g_st_foc_common.st_foc_carrier.u1_flg_offset_end))
    {
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
        /* Calibrate offset */
        g_st_foc_common.st_foc_carrier.u1_flg_offset_end
            = mtr_carrier_offset_ss(&g_st_foc_common.st_foc_carrier.st_sscs);
#endif
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
        /* Calibrate offset */
        g_st_foc_common.st_foc_carrier.u1_flg_offset_end
            = mtr_carrier_offset_ts(&g_st_foc_common.st_foc_carrier.st_tscs);
#endif
    }
    else
    {
        __NOP(); /* do nothing */
    }
    R_MTR_SetIcs();

} /* End of function mtr_carrier_startup_sequence */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_offset_ss
* @brief          Calculate current offset needed to perform current offset calibration
* @param[in,out]  p_st_sscs     The pointer to the single-shunt current sensing structure
* @retval         MTR_OFFSET_CALC_EXE   Offset calculation ongoing
* @retval         MTR_OFFSET_CALC_END   Offset calculation finished
***********************************************************************************************************************/
static inline uint8_t mtr_carrier_offset_ss(st_mtr_sscs_t *p_st_sscs)
{
    uint8_t  u1_flg_offset_end = MTR_CLR;

    /* Calculate offset current values */
    if ((p_st_sscs->u4_offset_calc_cnt + CP_OFFSET_CALC_ST_WAIT_CNT) <= p_st_sscs->u4_offset_sample_cnt)
    {
        p_st_sscs->s4_offset_ia /= (int32_t)p_st_sscs->u4_offset_calc_cnt;
        p_st_sscs->s4_offset_ib /= (int32_t)p_st_sscs->u4_offset_calc_cnt;

        p_st_sscs->s4_offset_ia -= MTR_ADC_OFFSET;
        p_st_sscs->s4_offset_ib -= MTR_ADC_OFFSET;

        u1_flg_offset_end = MTR_SET;
    }
    else
    {
        if (p_st_sscs->u4_offset_sample_cnt >= CP_OFFSET_CALC_ST_WAIT_CNT)
        {
            uint16_t s2_val_a;
            uint16_t s2_val_b;

            R_MTR_ADC_WaitConversion(g_adc0.p_ctrl, ADC_CONVERT_TIMEOUT);
            R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IDC, &s2_val_a);
            R_MTR_ADC_ReadDuplex(g_adc0.p_ctrl, &s2_val_b);

            p_st_sscs->s4_offset_ia += (s2_val_a >> MTR_ADC_DATA_SHIFT);
            p_st_sscs->s4_offset_ib += (s2_val_b >> MTR_ADC_DATA_SHIFT);
        }
        p_st_sscs->u4_offset_sample_cnt++;
    }

    return (u1_flg_offset_end);
} /* End of function mtr_carrier_offset_ss */
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_offset_ts
* @brief          Calculate current offset needed to perform current offset calibration
* @param[in,out]  p_st_tscs - The pointer to the three-shunt current sensing structure
* @retval         MTR_OFFSET_CALC_EXE   Offset calculation ongoing
* @retval         MTR_OFFSET_CALC_END   Offset calculation finished
***********************************************************************************************************************/
static inline uint8_t mtr_carrier_offset_ts(st_mtr_tscs_t *p_st_tscs)
{
    uint32_t u4_temp_ad_u = 0;
    uint32_t u4_temp_ad_v = 0;
    uint32_t u4_temp_ad_w = 0;
    uint8_t  u1_temp      = 0;

    u1_temp = MTR_CLR;

    /* Calculate offset current values */
    if ((p_st_tscs->u4_offset_calc_cnt + CP_OFFSET_CALC_ST_WAIT_CNT) <= p_st_tscs->u4_offset_sample_cnt)
    {
        p_st_tscs->u4_offset_sample_cnt = p_st_tscs->u4_offset_calc_cnt;

        /* calculate count(signed) to Adc(unsigned) */
        u4_temp_ad_u = ((uint32_t)(p_st_tscs->s4_offset_iu) /
                        (uint32_t)p_st_tscs->u4_offset_calc_cnt);
        u4_temp_ad_v = ((uint32_t)(p_st_tscs->s4_offset_iv) /
                        (uint32_t)p_st_tscs->u4_offset_calc_cnt);
        u4_temp_ad_w = ((uint32_t)(p_st_tscs->s4_offset_iw) /
                        (uint32_t)p_st_tscs->u4_offset_calc_cnt);

        /* calculate Adc(unsigned) to offset(signed) */
        p_st_tscs->s4_offset_iu = ((int32_t)u4_temp_ad_u - MTR_ADC_OFFSET);
        p_st_tscs->s4_offset_iv = ((int32_t)u4_temp_ad_v - MTR_ADC_OFFSET);
        p_st_tscs->s4_offset_iw = ((int32_t)u4_temp_ad_w - MTR_ADC_OFFSET);
#if (USE_U_PHASE_CURRENT == MTR_CLR)
        /* 2bit shift (12bit -> 10bit) */
        p_st_tscs->u4_offset_idc_adc = (p_st_tscs->u4_offset_idc_adc /
                                        p_st_tscs->u4_offset_calc_cnt) >> 2;
#endif
#if (USE_U_PHASE_CURRENT == MTR_SET)
        uint32_t scan_mask_a = R_MTR_ADC_SCAN_MASK_UVW;
#else
        uint32_t scan_mask_a = R_MTR_ADC_SCAN_MASK_VW_IDC;
#endif
        uint32_t scan_mask_b = R_MTR_ADC_SCAN_MASK_VDC;
        R_MTR_ADC_SetChannels(g_adc0.p_ctrl, scan_mask_a, scan_mask_b);
        u1_temp = MTR_SET;
    }
    else
    {
        if (p_st_tscs->u4_offset_sample_cnt >= CP_OFFSET_CALC_ST_WAIT_CNT)
        {
            uint16_t s2_val_v;
            uint16_t s2_val_w;
#if (USE_U_PHASE_CURRENT == MTR_SET)
            uint16_t s2_val_u;
#else
            uint16_t s2_val_idc;
#endif

            R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IV, &s2_val_v);
            R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IW, &s2_val_w);
            p_st_tscs->s4_offset_iv += (s2_val_v >> MTR_ADC_DATA_SHIFT);
            p_st_tscs->s4_offset_iw += (s2_val_w >> MTR_ADC_DATA_SHIFT);

#if (USE_U_PHASE_CURRENT == MTR_SET)
            R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IU, &s2_val_u);
            p_st_tscs->s4_offset_iu += (s2_val_u >> MTR_ADC_DATA_SHIFT);
#else
            /* offset_idc_ad_sum is signed integer */
            R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IDC, &s2_val_idc);
            p_st_tscs->u4_offset_idc_adc += (uint64_t)(s2_val_idc >> MTR_ADC_DATA_SHIFT);
#endif
        }

        p_st_tscs->u4_offset_sample_cnt++;
    }

    return (u1_temp);
} /* End of function mtr_carrier_offset_ts */
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */


/***********************************************************************************************************************
* @fn             mtr_limit
* @brief          Limit with max limit value and minimum limit value
* @param[in]      s4_value   Target value,
* @param[in]      s4_max     Max limit value,
* @param[in]      s4_min     Minimum limit value
* @return         Limited target value
***********************************************************************************************************************/
static inline int32_t mtr_limit(int32_t s4_value, int32_t s4_max, int32_t s4_min)
{
    if (s4_value > s4_max)
    {
        return (s4_max);
    }
    else if (s4_value < s4_min)
    {
        return (s4_min);
    }
    else
    {
        return (s4_value);
    }
} /* End of function mtr_limit */


#if (MOD_2PH_BOT == MOD_METHOD)
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/***********************************************************************************************************************
* @fn             mtr_limit_or_zero
* @brief          Limit with max limit value and minimum limit value.
                  If limited value is too small, reset zero to it.
* @param[in]      s2_value        Target value,
* @param[in]      s2_max          Max limit value,
* @param[in]      s2_min          Minimum limit value
* @param[in]      s2_zero_line    Line to reset zero to target value
* @return         Limited target value
***********************************************************************************************************************/
static inline int16_t mtr_limit_or_zero(int16_t s2_value, int16_t s2_max, int16_t s2_min, int16_t s2_zero_line)
{
    if (s2_value <= s2_zero_line)
    {
        return (0);
    }

    if (s2_value > s2_max)
    {
        return (s2_max);
    }
    else if (s2_value < s2_min)
    {
        return (s2_min);
    }

    return (s2_value);
} /* End of function mtr_limit_or_zero */
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */
#endif /* #if (MOD_2PH_BOT == MOD_METHOD) */

/***********************************************************************************************************************
* @fn             mtr_lpf1_run
* @brief          Calculate output of 1st order IIR LPF
* @param[in,out]  p_st_lpf   The pointer to the IIR LPF structure
* @param[in]      s4_input   Input
* @param[in]      u1_q       Q parameter for LPF
* @return         Current output value
***********************************************************************************************************************/
static inline int32_t mtr_lpf1_run(st_mtr_lpf1_t *p_st_lpf, int32_t s4_input, const uint8_t u1_q)
{
    int32_t s4_temp;

    /* out(n) = in_k * input(n) + out_k * output(n-1) */
    s4_temp  = FIX_mul_rs(s4_input, p_st_lpf->s4_in_k, u1_q);
    s4_temp += FIX_mul_rs(p_st_lpf->s4_pre_out, p_st_lpf->s4_out_k, u1_q);

    p_st_lpf->s4_pre_out = s4_temp;

    return (s4_temp);
} /* End of function mtr_lpf1_run */

/***********************************************************************************************************************
* @fn             mtr_pi_run_acr
* @brief          Current PI control
* @param[in,out]  p_st_pi           The pointer to the structure for PI controller parameter
* @param[in]      s4_err            Error number
* @param[in]      u1_kp_q           Q-format of PI proportional gain
* @param[in]      u1_q_err_shift    Shift count of error number
* @param[in]      u1_q_kidt_shift   Q-format of PI Integral gain
* @param[in]      u1_q_intg_shift   Shift count of decimal part
* @return         PI output
***********************************************************************************************************************/
static inline int32_t mtr_pi_run_acr(st_mtr_pi_t *p_st_pi, int32_t s4_err,
                                        const uint8_t u1_kp_q, const uint8_t u1_q_err_shift,
                                        const uint8_t u1_q_kidt_shift, const uint8_t u1_q_intg_shift)
{
    int32_t s4_pi_out;

    p_st_pi->s4_decimal += (s4_err >> u1_q_err_shift);

    /* Integral part saturation (symmetric) limiter */
    p_st_pi->s4_decimal = mtr_limit_abs(p_st_pi->s4_decimal, p_st_pi->s4_max_intg);

    int32_t s4_intg;
    s4_intg = (p_st_pi->s4_kidt >> u1_q_kidt_shift)
            * (p_st_pi->s4_decimal >> u1_q_intg_shift);

    s4_pi_out = s4_intg + FIX_mul_rs_sign(p_st_pi->s4_kp, s4_err, u1_kp_q);
    return (s4_pi_out);
} /* End of function mtr_pi_run_acr */

/***********************************************************************************************************************
* @fn             mtr_abs
* @brief          Absolute value
* @param[in]      s4_value   Target value
* @return         Absolute value
***********************************************************************************************************************/
static inline int32_t mtr_abs(int32_t s4_value)
{
    return ((s4_value ^ (s4_value >> 31)) - (s4_value >> 31));
} /* End of function mtr_abs */

/***********************************************************************************************************************
* @fn             mtr_limit_abs
* @brief          Limit with absolute value
* @param[in]      s4_value         Target value
* @param[in]      s4_limit_value   Limit value
* @return         Limited value
***********************************************************************************************************************/
static inline int32_t mtr_limit_abs(int32_t s4_value, int32_t s4_limit_value)
{
    if (s4_value > s4_limit_value)
    {
        return (s4_limit_value);
    }
    else if (s4_value < (-s4_limit_value))
    {
        return (-s4_limit_value);
    }
    else
    {
        return (s4_value);
    }
} /* End of function mtr_limit_abs */

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
#if (MOD_2PH_BOT == MOD_METHOD)
/***********************************************************************************************************************
* @fn             mtr_carrier_pwm_duty_calc
* @brief          Calculate PWM duty
* @param[in]      s4_value                  Target value
* @param[in]      u1_flg_uvw_min_pattern    Target phase
* @param[in]      phase                     Phase
* @return         Calculated value
***********************************************************************************************************************/
static inline int16_t mtr_carrier_pwm_duty_calc(int32_t s4_value, uint8_t u1_flg_uvw_min_pattern, uint8_t phase)
{
    if (phase == u1_flg_uvw_min_pattern)
    {
        return ((int16_t)MTR_LOWEST_DUTY_CNT);
    }
    else
    {
        int32_t s4_temp = (int32_t)(MTR_HALF_CARRIER_CNT); /* s4_temp0 is signed integer */
        s4_value        = mtr_limit_abs(-s4_value, MTR_PWM_DUTY_RANGE);
        s4_temp         = ((s4_temp * (s4_value >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY)
                        + (int32_t)(MTR_CENTER_AMPLITUDE_CNT - 1);

        /* limitation */
        s4_temp = mtr_limit(s4_temp, MTR_LOWEST_DUTY_CNT - 1, MTR_ADC_TS_CNT + MTR_DEADTIME_CNT);

        return ((int16_t)s4_temp);
    }
} /* End of function mtr_carrier_pwm_duty_calc */
#else
/***********************************************************************************************************************
* @fn             mtr_carrier_pwm_duty_calc
* @brief          Calculate PWM duty
* @param[in]      s4_value   Target value
* @return         Calculated value
***********************************************************************************************************************/
static inline int16_t mtr_carrier_pwm_duty_calc(int32_t s4_value)
{
    int32_t s4_temp;

    /*s4_value = mtr_limit_abs(-s4_value, MTR_PWM_DUTY_RANGE); */
    s4_value = -s4_value;
    s4_value = mtr_limit_abs(s4_value, MTR_PWM_DUTY_RANGE);

    /* s2_value is signed integer */
    /*s2_value = (int16_t)(((((int16_t)(MTR_HALF_CARRIER_CNT))
            * (s4_value >> (MTR_Q_VMOD - MTR_Q_DUTY))) >> MTR_Q_DUTY)
            + (int32_t)(MTR_CENTER_AMPLITUDE_CNT - 1)); */
    s4_temp = s4_value >> (MTR_Q_VMOD - MTR_Q_DUTY);
    s4_temp = ((MTR_HALF_CARRIER_CNT) * s4_temp) >> MTR_Q_DUTY;
    s4_temp = s4_temp + (MTR_CENTER_AMPLITUDE_CNT - 1);

    /* limitation */
    s4_temp = (int16_t)mtr_limit(s4_temp, MTR_MAX_DUTY_CNT, MTR_ADC_TS_CNT + MTR_DEADTIME_CNT);

    return ((int16_t)s4_temp);
} /* End of function mtr_carrier_pwm_duty_calc */
#endif /* (MOD_2PH_BOT == MOD_METHOD) */
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */
