/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_ol2cl_ctrl.h
* Description : Definitions of Open-loop to Closed-loop switch Control
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef RM_MTR_OL2CL_CTRL_H
#define RM_MTR_OL2CL_CTRL_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_common.h"
#include "rm_mtr_parameter.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include <stdint.h>

/***********************************************************************************************************************
* Macro definitions for sequence control
***********************************************************************************************************************/
#define MTR_1_ROTATION_DEG                (360)
/* SWITCH_ANGLE_MIN_RAD is signed value */
#define MTR_OL2CL_SWITCH_ANGLE_MIN_RAD    ((int32_t)(MTR_ANGLE_RANGE \
                                            / (MTR_1_ROTATION_DEG / CP_OL2CL_SWITCH_ANGLE_MIN)))

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/

typedef struct
{
    int32_t       s4_k;                     /* The gain for open-loop damping */
    int32_t       s4_speed_lim_rate;        /* Speed limit rate */
    uint8_t       u1_q_damp_speed_calc;     /* Q-format of damping speed calculation */
    uint8_t       u1_q_damp_speed_lim_calc; /* Q-format of damping speed limit calculation */
    st_mtr_hpf1_t st_hpf;                   /* 1st order HPF structure */
} st_mtr_damp_t;

/*  Open-loop to Closed-loop switch Control structure */
typedef struct
{
    int32_t        s4_lim_ramp_i;             /* Limit of current value change A/ms] */
    int32_t        s4_iq_ol2cl;               /* Q-axis current (Iq) in sensorless switching */
    int32_t        s4_k0_angle2current;       /* Reference current = k0 + k1 * (phase error) */
    int32_t        s4_k1_angle2current;       /* Reference current = k0 + k1 * (phase error) */
    int32_t        s4_th_phase_err_rad_cl;    /* Phase error[rad] to decide sensorless switch timing */
    uint16_t       u2_cnt_switch;             /* Time[cnt] to switch open-loop to sensorless */
    uint8_t        u1_q_k1_angle2current;     /* Q-format of angle error-dependent portion of reference current */
    uint8_t        u1_q_idelta_calc;          /* Q-format of current calculation for q-axis component */
    st_sincos28    st_ph_err;                 /* Phase error angle structure */
    st_mtr_damp_t  st_damp;                   /* Open-loop Damping Control structure */
} st_mtr_ol2cl_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: RM_MTR_OplOL2CLIqCalc
* Description  : Calculates The current required for eliminating the phase error
* Arguments    : st_ol2cl - The pointer to the Open-loop to Closed-loop switch Control structure
*                s4_ref_id - The Id reference in open-loop drive mode
*                s1_dir - Rotation direction
* Return Value : none
***********************************************************************************************************************/
void RM_MTR_OplOL2CLIqCalc (st_mtr_ol2cl_t * st_ol2cl, int32_t s4_ref_id, int8_t s1_dir);

/***********************************************************************************************************************
* Function Name : RM_MTR_OplOL2CLRefIqGet
* Description   : Set Iq reference when Open-loop to Closed-loop switch Control
* Arguments     : st_ol2cl - The pointer to the Open-loop to Closed-loop switch Control structure
*                 s4_ref_id - d-axis current reference in open-loop drive mode
* Return Value  : Iq reference
***********************************************************************************************************************/
int32_t RM_MTR_OplOL2CLRefIqGet (st_mtr_ol2cl_t * st_ol2cl, int32_t s4_ref_id);

/***********************************************************************************************************************
* Function Name : RM_MTR_OpenloopDampCtrl
* Description   : Damping control
* Arguments     : st_damp - damping control structure (pointer)
*               : s4_ed - d-axis BEMF
*               : s4_ref_speed - reference speed
* Return Value  : Feedback value for reference speed
***********************************************************************************************************************/
int32_t RM_MTR_OpenloopDampCtrl (st_mtr_damp_t * st_damp, int32_t s4_ed, int32_t s4_ref_speed);

#endif /* RM_MTR_OL2CL_CTRL_H */
