/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#ifndef DRIVER_R_MTR_GPT_THREE_PHASE_H_
#define DRIVER_R_MTR_GPT_THREE_PHASE_H_

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include "bsp_api.h"
#include "r_three_phase_api.h"

#include "r_gpt_three_phase.h"
#include "r_gpt_three_phase_cfg.h"

#include "r_gpt.h"
#include "r_gpt_cfg.h"

/**********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/

/* "GPT3" in ASCII, used to determine if channel is open. */
#define GPT_THREE_PHASE_OPEN                       (0x47505433ULL)

#define GPT_THREE_PHASE_PRV_GTWP_RESET_VALUE            (0xA500U)
#define GPT_THREE_PHASE_PRV_GTWP_WRITE_PROTECT          (0xA501U)

#define GPT_THREE_PHASE_PRV_GTBER_SINGLE_BUFFER         (0x50000U)
#define GPT_THREE_PHASE_PRV_GTBER_DOUBLE_BUFFER         (0xA0000U)

#define GPT_THREE_PHASE_PRV_GTWP_RESET_VALUE            (0xA500U)
#define GPT_THREE_PHASE_PRV_GTWP_WRITE_PROTECT          (0xA501U)

#define GPT_THREE_PHASE_PRV_GTCR_MODE_MASK              (0x000F0000U)
#define GPT_THREE_PHASE_PRV_GTCR_COMP2_MODE             (0x000D0000U)
#define GPT_THREE_PHASE_PRV_GTCR_COMP3_MODE             (0x000E0000U)

#define GPT_THREE_PHASE_PRV_GTIOR_OUTPUT_DISABLE        (0x01000100U)

#define GPT_PRV_GTCCRA                                  (0U)
#define GPT_PRV_GTCCRB                                  (1U)
#define GPT_PRV_GTCCRC                                  (2U)
#define GPT_PRV_GTCCRE                                  (3U)
#define GPT_PRV_GTCCRD                                  (4U)
#define GPT_PRV_GTCCRF                                  (5U)

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Public APIs
 **********************************************************************************************************************/
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode2_Open(three_phase_ctrl_t * const p_ctrl, three_phase_cfg_t const * const p_cfg);
fsp_err_t R_GPT_THREE_PHASE_CompMode2_DutyCycleSet(three_phase_ctrl_t * const p_ctrl, three_phase_duty_cycle_t *const p_duty_cycle);
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode3_Open(three_phase_ctrl_t * const p_ctrl, three_phase_cfg_t const * const p_cfg);
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode3_DutyCycleSet(three_phase_ctrl_t * const p_ctrl, three_phase_duty_cycle_t *const p_duty_cycle);
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */
fsp_err_t R_MTR_GPT_THREE_PHASE_SetDeadTime(three_phase_ctrl_t * const p_ctrl, uint16_t up_count, uint16_t down_count);
fsp_err_t R_MTR_GPT_THREE_PHASE_SetADCTrigger(three_phase_ctrl_t * const p_ctrl, uint16_t a_down_count, uint16_t b_down_count);
fsp_err_t R_MTR_GPT_THREE_PHASE_EnableOutputAll(three_phase_ctrl_t * const p_ctrl);
fsp_err_t R_MTR_GPT_THREE_PHASE_DisableOutputAll(three_phase_ctrl_t * const p_ctrl);

#endif /* DRIVER_R_MTR_GPT_THREE_PHASE_H_ */
