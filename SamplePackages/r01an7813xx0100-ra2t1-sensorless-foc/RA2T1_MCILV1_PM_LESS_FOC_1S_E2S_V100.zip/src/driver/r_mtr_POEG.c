/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes   <System Includes> , "Project Includes"
 **********************************************************************************************************************/

/* Private header file for this package. */
#include "r_mtr_POEG.h"
#include "r_mtr_ra2t1.h"

/*******************************************************************************************************************//**
 * Reset the status flag and wait until it is done.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_TIMEOUT                timeout occurs.
 * @retval FSP_ERR_ASSERTION              A required input pointer is NULL.
 * @retval FSP_ERR_ALREADY_OPEN           Module is already open.
 **********************************************************************************************************************/
fsp_err_t R_MTR_POEG_SoftwareRelease(poeg_ctrl_t * const p_ctrl, uint16_t timeout_count)
{
#if POEG_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_instance_ctrl);
    FSP_ERROR_RETURN(POEG_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    R_POEG_Reset(p_ctrl);
    poeg_status_t status;
    uint16_t u2_count = timeout_count;
    while (1)
    {
        R_POEG_StatusGet(p_ctrl, &status);
        if (POEG_STATE_NO_DISABLE_REQUEST == status.state)
        {
            break;
        }

        FSP_ERROR_RETURN(0U < u2_count--, FSP_ERR_TIMEOUT);
    }
    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Recover from the state of forced shutdown.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_TIMEOUT                timeout occurs.
 * @retval FSP_ERR_ASSERTION              A required input pointer is NULL.
 * @retval FSP_ERR_ALREADY_OPEN           Module is already open.
 **********************************************************************************************************************/
fsp_err_t R_MTR_POEG_RecoverForcedShutdown(poeg_ctrl_t * const p_ctrl, uint16_t timeout_count, uint8_t * p_is_shutdown)
{
#if POEG_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_instance_ctrl);
    FSP_ERROR_RETURN(POEG_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    *p_is_shutdown = 0; // = MTR_CLR

    poeg_status_t status;
    R_POEG_StatusGet(p_ctrl, &status);

    if (POEG_STATE_NO_DISABLE_REQUEST != status.state)
    {
        *p_is_shutdown = 1; // = MTR_SET;

        fsp_err_t ret;
        ret = R_MTR_POEG_SoftwareRelease(p_ctrl, timeout_count);
        if (FSP_SUCCESS != ret)
        {
            return ret;
        }
    }

    return FSP_SUCCESS;
}
