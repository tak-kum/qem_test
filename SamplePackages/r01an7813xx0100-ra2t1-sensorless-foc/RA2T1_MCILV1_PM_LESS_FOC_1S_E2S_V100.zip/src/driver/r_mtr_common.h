/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#ifndef DRIVER_R_MTR_COMMON_H_
#define DRIVER_R_MTR_COMMON_H_

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/

#include "hal_data.h"
#include "r_mtr_GPT_THREE_PHASE.h"
#include "r_mtr_ADC.h"
#include "r_mtr_POEG.h"

/**********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#define R_MTR_ADCR_IDC              (ADC_CHANNEL_0)
#define R_MTR_ADCR_IDCDUP           (ADC_CHANNEL_DUPLEX)
#define R_MTR_ADCR_VDC              (ADC_CHANNEL_8)

#define R_MTR_ADC_SCAN_MASK_VW      (0x00000006U)
#define R_MTR_ADC_SCAN_MASK_UVW     (0x00000007U)
#define R_MTR_ADC_SCAN_MASK_VW_IDC  (0x00000007U)
#define R_MTR_ADC_SCAN_MASK_VDC     (0x00000100U)
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
#define R_MTR_ADCR_IU               (ADC_CHANNEL_0)
#define R_MTR_ADCR_IV               (ADC_CHANNEL_1)
#define R_MTR_ADCR_IW               (ADC_CHANNEL_2)
#define R_MTR_ADCR_IDC              (ADC_CHANNEL_0)
#define R_MTR_ADCR_VDC              (ADC_CHANNEL_8)

#define R_MTR_ADC_SCAN_MASK_VW      (0x00000006U)
#define R_MTR_ADC_SCAN_MASK_UVW     (0x00000007U)
#define R_MTR_ADC_SCAN_MASK_VW_IDC  (0x00000007U)
#define R_MTR_ADC_SCAN_MASK_VDC     (0x00000100U)
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#define R_MTR_ADCR_VDC              (ADC_CHANNEL_8)
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

#endif /* DRIVER_R_MTR_COMMON_H_ */
