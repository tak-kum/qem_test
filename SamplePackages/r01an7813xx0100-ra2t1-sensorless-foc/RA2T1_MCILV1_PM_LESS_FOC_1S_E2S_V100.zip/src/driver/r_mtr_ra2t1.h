/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ra2t1.h
* Description : Definitions of the processing of a MCU control layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_CTRL_RA2T1_H
#define R_MTR_CTRL_RA2T1_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_common.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include <stdint.h>
#include "r_mtr_config.h"
#include "r_mtr_control_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define     USE_PWMOPA              (MTR_SET)           /* Defines whether use PWMOPA for HWOC */
#define     USE_ADC_FAST_MODE       (MTR_SET)           /* Defines whether to enable high-speed ADC conversion mode for faster sampling */
#define     USE_DUTY_SHIFT          (MTR_CLR)           /* Defines whether to use duty cycle shifting for motor control */
#define     USE_U_PHASE_CURRENT     (MTR_CLR)           /* Defines whether to use U-phase current measurement for motor control */

#define     TRD_SKIPPING_COUNT      (CP_INT_DECIMATION) /* TRD interrupt skipping count */

#define     MTR_PWM_TIMER_FREQ      (CP_PWM_TIMER_FREQ) /* PWM timer frequency[MHz] */

#define     MTR_INTVAL_TIMER_FREQ   (CP_INTVAL_TIMER_FREQ) /* interval timer frequency[MHz] */

#define     MTR_CARRIER_FREQ        (CP_CARRIER_FREQ)      /* PWM carrier wave frequency[kHz] */
#define     MTR_DEADTIME            (IP_DEADTIME)       /* dead-time[usec] */

/* Count values are unsigned */
#define     MTR_DEADTIME_CNT          ((uint16_t)(MTR_DEADTIME * MTR_PWM_TIMER_FREQ))
                                                        /* setting value of dead-time */
#define     MTR_CARRIER_CNT           ((uint16_t)(MTR_PWM_TIMER_FREQ * 1000 / MTR_CARRIER_FREQ * 0.5f))
                                                        /* max setting value of carrier period */
#define     MTR_HALF_CARRIER_CNT      ((uint16_t)(MTR_CARRIER_CNT * 0.5f))
                                                        /* half of duty value */
#define     MTR_HALF_DEADTIME_CNT     ((uint16_t)(MTR_DEADTIME_CNT * 0.5f))
                                                        /* setting value of half dead-time */
#define     MTR_DUTY_RANGE_CNT        ((uint16_t)(MTR_CARRIER_CNT-MTR_DEADTIME_CNT)*0.5f)

/* THREE_SHUNT == CURRENT_SENS_METHOD */
#if (THREE_SHUNT == CURRENT_SENS_METHOD)
#define     MTR_CURRENT_ADCONV_TIME (CP_AD_CONVERSION_TIME * 2.0f)
                                                        /* time[usec] needed for u,w phase current A/D conversion */

#define     MTR_ADC_SH_CNT          (44)  /* PCLKD = 64MHz */
#define     MTR_ADC_RINGING_CNT     (CP_AD_RINGING_WAIT_CNT)
#define     MTR_ADC_TS_CNT          ((MTR_ADC_SH_CNT+MTR_ADC_RINGING_CNT+1)/2)


#if ((MOD_3PH_TOW == MOD_METHOD) || (MOD_3PH_SPWM == MOD_METHOD))
/* MTR_VOLTAGE_LIMIT_OFFSET is integer */
#define     MTR_VOLTAGE_LIMIT_OFFSET ((int32_t)(((MTR_CURRENT_ADCONV_TIME + MTR_DEADTIME * 2) / \
                                                (1000/MTR_CARRIER_FREQ)) * 0.5f * (1 << MTR_Q_VOLTAGE)))
                                                        /* 0.5 is Vdc/2/PU_BASE_VOLTAGE_V in PU system */
/* MTR_CENTER_AMPLITUDE_CNT is unsigned */
#define     MTR_CENTER_AMPLITUDE_CNT ((MTR_CARRIER_CNT+MTR_ADC_TS_CNT+MTR_DEADTIME_CNT+1)/2)
                                                        /* 0.5 is Vdc/2/PU_BASE_VOLTAGE_V in PU system */
#elif (MOD_2PH_BOT == MOD_METHOD)
/* MTR_VOLTAGE_LIMIT_OFFSET is integer */
#define     MTR_VOLTAGE_LIMIT_OFFSET (0)                /* Offset is zero for 2-phase modulation */
/* MTR_CENTER_AMPLITUDE_CNT is unsigned */

#define     MTR_CENTER_AMPLITUDE_CNT ((int16_t)(MTR_HALF_CARRIER_CNT + MTR_DEADTIME_CNT))
#endif

#define     MTR_OFFSET_CENTER_AMPLITUDE_CNT (MTR_CENTER_AMPLITUDE_CNT)

#endif /* THREE_SHUNT == CURRENT_SENS_METHOD */

/* SINGLE_SHUNT == CURRENT_SENS_METHOD */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if ((MOD_3PH_SPWM == MOD_METHOD) || (MOD_3PH_TOW == MOD_METHOD))
/* MTR_HALF_VOLTAGE_LIMIT_OFFSET is integer */
#define MTR_VOLTAGE_LIMIT_OFFSET  ((int32_t)(((MTR_DEADTIME * 2) / (1000 / MTR_CARRIER_FREQ)) * 0.5f * (1 << MTR_Q_VOLTAGE)))
                                                    /* 0.5 is Vdc/2/PU_BASE_VOLTAGE_V in PU system */
#elif (MOD_2PH_BOT == MOD_METHOD)
#define     MTR_VOLTAGE_LIMIT_OFFSET (0) /* Offset is zero for 2-phase modulation */
#endif
#endif /* SINGLE_SHUNT == CURRENT_SENS_METHOD */

#define MTR_DEADTIME_RATIO         ((MTR_DEADTIME * 1.0f * MTR_CARRIER_FREQ) / 1000.0f)
                                                    /* ratio of deadtime to carrier */
#define MTR_DEADTIME_CURRENT_LIMIT ((float)(IP_CURRENT_RANGE)/(1<<MTR_ADC_12BIT))
                                                    /* dead zone of deadtime compensation */

/* control period/frequency */
#define     MTR_CTRL_PERIOD         ((CP_INT_DECIMATION + 1) / (MTR_CARRIER_FREQ * 1000)) /* control period [sec] */
#define     MTR_SPEED_CTRL_PERIOD   (CP_SPEED_CTRL_PERIOD)            /* control period for speed loop [sec] */

/* A/D converter channel number */
#define     MTR_ADC_DATA_SHIFT      (0)                 /* ADCR is regard as right-justified 12 bits */

#define     MTR_ADC_OFFSET          (0x7FF)             /* A/D offset */

/* system error status */
#define     MTR_CHARGE_CAP_WAIT_CNT     (IP_CHARGE_CAP_WAIT_CNT)               /* 300 us per count */

/* Voltage leading phase coefficient */
#define     MTR_V_PHASE_LEAD_COEF   (FIX_fromfloat(CP_V_PHASE_LEAD_COEF, MTR_Q_V_PHASE_LEAD_COEF))


/* PWM register setting */
#define     MTR_LOWEST_DUTY_CNT     (MTR_CARRIER_CNT + MTR_DEADTIME_CNT)
#define     MTR_MAX_DUTY_CNT        (MTR_CARRIER_CNT - 1)
#define     MTR_MIN_DUTY_CNT        (1)

#define     POEG_RECOVER_TIMEOUT    (3)
#define     ADC_CONVERT_TIMEOUT     (0xFFFF)

/* Define constants for better readability */
#define     MTR_ID                  (0)
#define     MTR_IQ                  (1)

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MTR_InitUnusedPins
* Description   : Initialize unused pins
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MTR_InitUnusedPins (void);

#endif /* R_MTR_CTRL_RA2T1_H */
