/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes   <System Includes> , "Project Includes"
 **********************************************************************************************************************/

/* Private header file for this package. */
#include "r_mtr_GPT_THREE_PHASE.h"
#include "r_mtr_ra2t1.h"

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
/*******************************************************************************************************************//**
 * Initializes the 3-phase timer module in Complementary PWM Mode 2 and applies configurations.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION              A required input pointer is NULL.
 * @retval FSP_ERR_ALREADY_OPEN           Module is already open.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode2_Open(three_phase_ctrl_t * const p_ctrl, three_phase_cfg_t const * const p_cfg)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_cfg);
    FSP_ASSERT(NULL != p__ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN != p_instance_ctrl->open, FSP_ERR_ALREADY_OPEN);
#endif

    fsp_err_t err;

    /* Open all three GPT submodules */
    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        err = R_GPT_Open(p_cfg->p_timer_instance[ch]->p_ctrl, p_cfg->p_timer_instance[ch]->p_cfg);
#if GPT_CFG_PARAM_CHECKING_ENABLE
        if (err)
        {
            /* In case of an error on GPT open, close all opened instances and return the error */
            for (three_phase_channel_t close_ch = THREE_PHASE_CHANNEL_U; close_ch < ch; close_ch++)
            {
                R_GPT_Close(p_cfg->p_timer_instance[close_ch]->p_ctrl);
            }

            return err;
        }

#else
        FSP_PARAMETER_NOT_USED(err);
#endif
        /* Save a pointer to the GPT registers for this channel */
        p_instance_ctrl->p_reg[ch] = ((gpt_instance_ctrl_t *) (p_cfg->p_timer_instance[ch]->p_ctrl))->p_reg;

        /*** The followings are settings for Comp2 */
        /* Set COMP2 mode */
        p_instance_ctrl->p_reg[ch]->GTCR &= ~GPT_THREE_PHASE_PRV_GTCR_MODE_MASK;
        p_instance_ctrl->p_reg[ch]->GTCR |= GPT_THREE_PHASE_PRV_GTCR_COMP2_MODE;

        /* Set the timer cycle to double buffer */
        three_phase_channel_t mch = p_cfg->callback_ch;
        if (ch == mch)
        {
            p_instance_ctrl->p_reg[ch]->GTPDBR = (uint32_t)(MTR_CARRIER_CNT);

            /* ADC start trigger timing setting */
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRBDEN = 0;
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRBUEN = 1;
#if (MTR_ADC_SH_CNT >= MTR_ADC_RINGING_CNT)
            /* ADC start trigger A is down count side */
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRADEN = 1;
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRAUEN = 0;
            p_instance_ctrl->p_reg[ch]->GTADTRA = (uint16_t)MTR_ADC_SH_CNT - (uint16_t)MTR_ADC_TS_CNT;
#else
            /* ADC start trigger A is up count side */
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRADEN = 0;
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRAUEN = 1;
            p_instance_ctrl->p_reg[ch]->GTADTRA = (uint16_t)MTR_ADC_RINGING_CNT - (uint16_t)MTR_ADC_TS_CNT;
#endif
        }

        /* Set the duty cycle to buffers */
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRA] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRC] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRE] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRD] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRF] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;

        /* Dead time value register GTDVU */
        p_instance_ctrl->p_reg[ch]->GTDVU = MTR_DEADTIME_CNT;
        /* Dead time value register GTDVD */
        p_instance_ctrl->p_reg[ch]->GTDVD = MTR_DEADTIME_CNT;
        /* GTITC is always present for GPTE and GPTEH timers */
#if (TRD_SKIPPING_COUNT == 0)
        p_instance_ctrl->p_reg[ch]->GTITC = ((uint32_t) GPT_INTERRUPT_SKIP_SOURCE_NONE << R_GPT0_GTITC_IVTC_Pos) |
                                        ((uint32_t) TRD_SKIPPING_COUNT << R_GPT0_GTITC_IVTT_Pos) |
                                        ((uint32_t) 0U << R_GPT0_GTITC_ADTAL_Pos) |
                                        ((uint32_t) 0U << R_GPT0_GTITC_ADTBL_Pos);
#else
        p_instance_ctrl->p_reg[ch]->GTITC = ((uint32_t) GPT_INTERRUPT_SKIP_SOURCE_TROUGH << R_GPT0_GTITC_IVTC_Pos) |
                                        ((uint32_t) TRD_SKIPPING_COUNT << R_GPT0_GTITC_IVTT_Pos) |
                                        ((uint32_t) 1U << R_GPT0_GTITC_ADTAL_Pos) |
                                        ((uint32_t) 1U << R_GPT0_GTITC_ADTBL_Pos);
#endif
        /* Configure AD Compare match behavior */
        p_instance_ctrl->p_reg[ch]->GTADTRA = 0;
        p_instance_ctrl->p_reg[ch]->GTADTRB = MTR_CARRIER_CNT;

        /*** settings for Comp2 ***/

#if GPT_CFG_WRITE_PROTECT_ENABLE

        /* Re-enable write protection */
        p_instance_ctrl->p_reg[ch]->GTWP = GPT_THREE_PHASE_PRV_GTWP_WRITE_PROTECT;
#endif
    }

    /* Get copy of GPT channel mask and buffer mode */
    p_instance_ctrl->channel_mask = p_cfg->channel_mask;
    p_instance_ctrl->buffer_mode  = p_cfg->buffer_mode;

    /* Save pointer to config struct */
    p_instance_ctrl->p_cfg = p_cfg;

    p_instance_ctrl->open = GPT_THREE_PHASE_OPEN;

    R_MTR_GPT_THREE_PHASE_DisableOutputAll(p_ctrl);
    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Sets duty cycle for the 3-phase timer module in Complementary PWM Mode 2.
 *
 * @retval FSP_SUCCESS                 Duty cycle updated successfully.
 * @retval FSP_ERR_ASSERTION           A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN            The instance is not opened.
 * @retval FSP_ERR_INVALID_ARGUMENT    One or more duty cycle count values was outside the range 0..(period - 1).
 **********************************************************************************************************************/
fsp_err_t R_GPT_THREE_PHASE_CompMode2_DutyCycleSet(three_phase_ctrl_t *const p_ctrl, three_phase_duty_cycle_t *const p_duty_cycle)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p__ctrl);
    FSP_ASSERT(NULL != p_duty_cycle);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        FSP_ERROR_RETURN(NULL != sp_reg[ch], FSP_ERR_NOT_OPEN);

        uint32_t gtpr = sp_reg[THREE_PHASE_CHANNEL_U]->GTPR;
        FSP_ERROR_RETURN((p_duty_cycle->duty[ch] < gtpr) && (p_duty_cycle->duty[ch] > 0), FSP_ERR_INVALID_ARGUMENT);

        /* In double-buffer mode also check double buffer */
        FSP_ERROR_RETURN((p_duty_cycle->duty_buffer[ch] < gtpr) && (p_duty_cycle->duty_buffer[ch] > 0),
                         FSP_ERR_INVALID_ARGUMENT);
    }
#endif

    /* Set all duty cycle registers */
    /*
     * Since GPT16n+2, which is the shift trigger to the temporary register, is the V phase,
     * set it in the order of U, W, V.
     */
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_U];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_W];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_V];

    return FSP_SUCCESS;
}
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
/*******************************************************************************************************************//**
 * Initializes the 3-phase timer module in Complementary PWM Mode 3(transfer at crest and trough) and applies configurations.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION              A required input pointer is NULL.
 * @retval FSP_ERR_ALREADY_OPEN           Module is already open.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode3_Open(three_phase_ctrl_t * const p_ctrl, three_phase_cfg_t const * const p_cfg)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_cfg);
    FSP_ASSERT(NULL != p__ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN != p_instance_ctrl->open, FSP_ERR_ALREADY_OPEN);
#endif

    fsp_err_t err;

    /* Open all three GPT submodules */
    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        err = R_GPT_Open(p_cfg->p_timer_instance[ch]->p_ctrl, p_cfg->p_timer_instance[ch]->p_cfg);
#if GPT_CFG_PARAM_CHECKING_ENABLE
        if (err)
        {
            /* In case of an error on GPT open, close all opened instances and return the error */
            for (three_phase_channel_t close_ch = THREE_PHASE_CHANNEL_U; close_ch < ch; close_ch++)
            {
                R_GPT_Close(p_cfg->p_timer_instance[close_ch]->p_ctrl);
            }

            return err;
        }

#else
        FSP_PARAMETER_NOT_USED(err);
#endif
        /* Save a pointer to the GPT registers for this channel */
        p_instance_ctrl->p_reg[ch] = ((gpt_instance_ctrl_t *) (p_cfg->p_timer_instance[ch]->p_ctrl))->p_reg;

        /*** The followings are settings for Comp3 */
        /* Set COMP3 mode */
        p_instance_ctrl->p_reg[ch]->GTCR &= ~GPT_THREE_PHASE_PRV_GTCR_MODE_MASK;
        p_instance_ctrl->p_reg[ch]->GTCR |= GPT_THREE_PHASE_PRV_GTCR_COMP3_MODE;

        p_instance_ctrl->p_reg[ch]->GTIOR_b.GTIOA = 0x09; // 01001b(init:L, active:H, upcomp:H, downcomp:L)
        p_instance_ctrl->p_reg[ch]->GTIOR_b.GTIOB = 0x06; // 00110b(init:L, active:H, upcomp:L, downcomp:H)

        /* ADC start trigger double buffer setting */
        /* Double buffer enable */
        p_instance_ctrl->p_reg[ch]->GTBER2_b.CP3DB = 1;

        /* Set the timer cycle to double buffer */
        three_phase_channel_t mch = p_cfg->callback_ch;
        if (ch == mch)
        {
            p_instance_ctrl->p_reg[ch]->GTPDBR = (uint32_t)(MTR_CARRIER_CNT);

            /* ADC start trigger timing setting */
            /* ADC start trigger A is down count side */
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRAUEN = 0;
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRADEN = 1;
            /* ADC start trigger B is down count side */
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRBUEN = 0;
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRBDEN = 1;

            /* ADC start trigger buffer transfer timing setting */
            /* ADC start trigger A transfer at trough */
            p_instance_ctrl->p_reg[ch]->GTBER_b.ADTTA = 0b10;
            /* ADC start trigger B transfer at trough */
            p_instance_ctrl->p_reg[ch]->GTBER_b.ADTTB = 0b10;
        }
        p_instance_ctrl->p_reg[0]->GTADTBRA = (uint32_t)(MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1);
        p_instance_ctrl->p_reg[0]->GTADTBRB = (uint32_t)(MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1);
        p_instance_ctrl->p_reg[0]->GTADTRA = (uint32_t)(MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1);
        p_instance_ctrl->p_reg[0]->GTADTRB = (uint32_t)(MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1);

        /* Set the duty cycle to buffers */
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRA] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRC] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRE] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRD] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRF] = (MTR_CARRIER_CNT + MTR_DEADTIME_CNT + 1) >> 1;

        /* Dead time value register GTDVU */
        p_instance_ctrl->p_reg[ch]->GTDVU = MTR_DEADTIME_CNT;
        /* Dead time value register GTDVD */
        p_instance_ctrl->p_reg[ch]->GTDVD = MTR_DEADTIME_CNT;
        /* GTITC is always present for GPTE and GPTEH timers */
        p_instance_ctrl->p_reg[ch]->GTITC = ((uint32_t) GPT_INTERRUPT_SKIP_SOURCE_TROUGH << R_GPT0_GTITC_IVTC_Pos) |
                                        ((uint32_t) TRD_SKIPPING_COUNT << R_GPT0_GTITC_IVTT_Pos) |
                                        ((uint32_t) 1U << R_GPT0_GTITC_ADTAL_Pos) |
                                        ((uint32_t) 1U << R_GPT0_GTITC_ADTBL_Pos);

        /* Set VDC channel AD compare match trigger count */
        p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTINTAD_b.ADTRAUEN = 1;
        p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTADTRA = MTR_DEADTIME_CNT;

        /*** settings for Comp3 ***/

#if GPT_CFG_WRITE_PROTECT_ENABLE

        /* Re-enable write protection */
        p_instance_ctrl->p_reg[ch]->GTWP = GPT_THREE_PHASE_PRV_GTWP_WRITE_PROTECT;
#endif
    }

    /* Get copy of GPT channel mask and buffer mode */
    p_instance_ctrl->channel_mask = p_cfg->channel_mask;
    p_instance_ctrl->buffer_mode  = p_cfg->buffer_mode;

    /* Save pointer to config struct */
    p_instance_ctrl->p_cfg = p_cfg;

    p_instance_ctrl->open = GPT_THREE_PHASE_OPEN;

    R_MTR_GPT_THREE_PHASE_DisableOutputAll(p_ctrl);
    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Sets duty cycle for the 3-phase timer module in Complementary PWM Mode 3.
 *
 * @retval FSP_SUCCESS                 Duty cycle updated successfully.
 * @retval FSP_ERR_ASSERTION           A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN            The instance is not opened.
 * @retval FSP_ERR_INVALID_ARGUMENT    One or more duty cycle count values was outside the range 0..(period - 1).
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode3_DutyCycleSet(three_phase_ctrl_t *const p_ctrl, three_phase_duty_cycle_t *const p_duty_cycle)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p__ctrl);
    FSP_ASSERT(NULL != p_duty_cycle);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        FSP_ERROR_RETURN(NULL != sp_reg[ch], FSP_ERR_NOT_OPEN);

        uint32_t gtpr = sp_reg[THREE_PHASE_CHANNEL_U]->GTPR;
        FSP_ERROR_RETURN((p_duty_cycle->duty[ch] < gtpr) && (p_duty_cycle->duty[ch] > 0), FSP_ERR_INVALID_ARGUMENT);

        /* In double-buffer mode also check double buffer */
        FSP_ERROR_RETURN((p_duty_cycle->duty_buffer[ch] < gtpr) && (p_duty_cycle->duty_buffer[ch] > 0),
                         FSP_ERR_INVALID_ARGUMENT);
    }
#endif

    /* Set all duty cycle registers */
    /*
     * Since GPT16n+2, which is the shift trigger to the temporary register, is the V phase,
     * set it in the order of U, W, V.
     */
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTCCR[GPT_PRV_GTCCRF] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_U];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTCCR[GPT_PRV_GTCCRF] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_W];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTCCR[GPT_PRV_GTCCRF] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_V];

    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty_buffer[THREE_PHASE_CHANNEL_U];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty_buffer[THREE_PHASE_CHANNEL_W];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty_buffer[THREE_PHASE_CHANNEL_V];

    return FSP_SUCCESS;
}
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */

/*******************************************************************************************************************//**
 * Set dead time values for the 3-phase timer module.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION           A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN               The instance is not opened.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_SetDeadTime(three_phase_ctrl_t * const p_ctrl, uint16_t up_count, uint16_t down_count)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        p_instance_ctrl->p_reg[ch]->GTWP = GPT_THREE_PHASE_PRV_GTWP_WRITE_PROTECT;
        p_instance_ctrl->p_reg[ch]->GTDVU = up_count;
        p_instance_ctrl->p_reg[ch]->GTDVD = down_count;
    }

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Set ADC triggers for the 3-phase timer module in Complementary PWM Mode 3.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION           A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN               The instance is not opened.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_SetADCTrigger(three_phase_ctrl_t * const p_ctrl, uint16_t a_down_count, uint16_t b_down_count)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    three_phase_channel_t mch = p_instance_ctrl->p_cfg->callback_ch;
    p_instance_ctrl->p_reg[mch]->GTADTBRA = a_down_count;
    p_instance_ctrl->p_reg[mch]->GTADTBRB = b_down_count;

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Make all outputs enable.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION           A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN               The instance is not opened.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_EnableOutputAll(three_phase_ctrl_t * const p_ctrl)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        p_instance_ctrl->p_reg[ch]->GTIOR |= GPT_THREE_PHASE_PRV_GTIOR_OUTPUT_DISABLE;
    }

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Make all outputs disable.
 *
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION              A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN               The instance is not opened.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_DisableOutputAll(three_phase_ctrl_t * const p_ctrl)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        p_instance_ctrl->p_reg[ch]->GTIOR &= ~GPT_THREE_PHASE_PRV_GTIOR_OUTPUT_DISABLE;
    }

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    three_phase_duty_cycle_t duty_cycle;
    duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = (int16_t)(MTR_CENTER_AMPLITUDE_CNT - 1);
    duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = (int16_t)(MTR_CENTER_AMPLITUDE_CNT - 1);
    duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = (int16_t)(MTR_CENTER_AMPLITUDE_CNT - 1);
    R_GPT_THREE_PHASE_CompMode2_DutyCycleSet(p_ctrl, &duty_cycle);
#endif

    return FSP_SUCCESS;
}
