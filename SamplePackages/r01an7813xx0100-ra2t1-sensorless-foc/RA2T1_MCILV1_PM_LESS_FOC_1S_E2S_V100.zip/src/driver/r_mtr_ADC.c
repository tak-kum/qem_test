/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes   <System Includes> , "Project Includes"
 **********************************************************************************************************************/

/* Private header file for this package. */
#include "r_mtr_ADC.h"
#include "r_mtr_ra2t1.h"
//R_ADC0_Type * gp_adc;

/*******************************************************************************************************************//**
 * Initialize the ADC in fast mode.
 * Other settings are the same as R_ADC_Open.
 *
 * @retval FSP_SUCCESS                     Module is ready for use.
 * @retval FSP_ERR_ASSERTION               An input argument is invalid.
 * @retval FSP_ERR_ALREADY_OPEN            The instance control structure has already been opened.
 * @retval FSP_ERR_IRQ_BSP_DISABLED        A callback is provided, but the interrupt is not enabled.
 * @retval FSP_ERR_IP_CHANNEL_NOT_PRESENT  The requested unit does not exist on this MCU.
 * @retval FSP_ERR_INVALID_HW_CONDITION    The ADC clock must be at least 1 MHz
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_Open(adc_ctrl_t * p_ctrl, adc_cfg_t const * const p_cfg)
{
    fsp_err_t fsp_err = R_ADC_Open(p_ctrl, p_cfg);

    if (FSP_SUCCESS == fsp_err)
    {
        adc_instance_ctrl_t * p_instance_ctrl = (adc_instance_ctrl_t *) p_ctrl;

        /* Enable fast conversion mode */
        p_instance_ctrl->p_reg->ADACSR_b.ADSAC = 1;

        /* Disable group B scan end interrupt */
        p_instance_ctrl->p_reg->ADCSR_b.GBADIE = 0;
    }

    return fsp_err;
}


/*******************************************************************************************************************//**
 * Wait conversion finished.
 *
 * @retval FSP_SUCCESS                 Data read into provided p_data.
 * @retval FSP_ERR_TIMEOUT             timeout occurs.
 * @retval FSP_ERR_ASSERTION           An input argument is invalid.
 * @retval FSP_ERR_NOT_OPEN            Unit is not open.
 * @retval FSP_ERR_NOT_INITIALIZED     Unit is not initialized.
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_WaitConversion(adc_ctrl_t * p_ctrl, uint16_t timeout_count)
{
    adc_instance_ctrl_t * p_instance_ctrl = (adc_instance_ctrl_t *) p_ctrl;
    uint16_t u2_count = timeout_count;
#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    while (p_instance_ctrl->p_reg->ADCSR & ADC_PRV_ADCSR_ADST)
    {
        /* Wait conversion finished. */
        FSP_ERROR_RETURN(0U < u2_count--, FSP_ERR_TIMEOUT);
    }

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Set ADC channels.
 *
 * @retval FSP_SUCCESS                 Data read into provided p_data.
 * @retval FSP_ERR_ASSERTION           An input argument is invalid.
 * @retval FSP_ERR_NOT_OPEN            Unit is not open.
 * @retval FSP_ERR_NOT_INITIALIZED     Unit is not initialized.
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_SetChannels(adc_ctrl_t * p_ctrl, uint32_t scan_mask_a, uint32_t scan_mask_b)
{
    adc_instance_ctrl_t * p_instance_ctrl = (adc_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    R_ADC_ScanStop(p_ctrl);

    p_instance_ctrl->p_reg->ADANSA[0] = (uint16_t) (scan_mask_a);
    p_instance_ctrl->p_reg->ADANSB[0] = (uint16_t) (scan_mask_b);
    p_instance_ctrl->p_reg->ADANSA[1] = (uint16_t) ((scan_mask_a >> 16));
    p_instance_ctrl->p_reg->ADANSB[1] = (uint16_t) ((scan_mask_b >> 16));

    R_ADC_ScanStart(p_ctrl);

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Reads conversion results from a duplex register into a 32-bit result.
 *
 * @retval FSP_SUCCESS                 Data read into provided p_data.
 * @retval FSP_ERR_ASSERTION           An input argument is invalid.
 * @retval FSP_ERR_NOT_OPEN            Unit is not open.
 * @retval FSP_ERR_NOT_INITIALIZED     Unit is not initialized.
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_ReadDuplex(adc_ctrl_t * p_ctrl, uint16_t * const p_data)
{
    adc_instance_ctrl_t * p_instance_ctrl = (adc_instance_ctrl_t *) p_ctrl;

    /* Perform parameter checking. */
#if ADC_CFG_PARAM_CHECKING_ENABLE

    /* Verify the pointers are valid */
    FSP_ASSERT(NULL != p_instance_ctrl);
    FSP_ASSERT(NULL != p_data);
    FSP_ERROR_RETURN(ADC_OPEN == p_instance_ctrl->opened, FSP_ERR_NOT_OPEN);
    FSP_ERROR_RETURN(ADC_OPEN == p_instance_ctrl->initialized, FSP_ERR_NOT_INITIALIZED);
#endif

    /* Read the data from the requested ADC conversion register and return it */
    *p_data = p_instance_ctrl->p_reg->ADDBLDR;

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Sets the sample state count for individual channels. This only needs to be set for special use cases. Normally, use
 * the default values out of reset.
 *
 * @retval FSP_SUCCESS                     Module is ready for use.
 * @retval FSP_ERR_ASSERTION               An input argument is invalid.
 * @retval FSP_ERR_ALREADY_OPEN            The instance control structure has already been opened.
 * @retval FSP_ERR_IRQ_BSP_DISABLED        A callback is provided, but the interrupt is not enabled.
 * @retval FSP_ERR_IP_CHANNEL_NOT_PRESENT  The requested unit does not exist on this MCU.
 * @retval FSP_ERR_INVALID_HW_CONDITION    The ADC clock must be at least 1 MHz
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_SetSampleStateCount(adc_ctrl_t * p_ctrl)
{
    adc_sample_state_t sample = { ADC_SAMPLE_STATE_CHANNEL_0, 7 };
    fsp_err_t fsp_err = R_ADC_SampleStateCountSet(p_ctrl, &sample);

    return fsp_err;
}

