/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_board.c
* Description : Processes of user interface on inverter board
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "rm_mtr_common.h"
#include "rm_mtr_statemachine.h"
#include "mtr_main.h"
#include "r_mtr_board.h"
#include "hal_data.h"

/***********************************************************************************************************************
Private variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : RM_MTR_BoardLedContrl
* Description   : Set LED pattern depend on motor status and system status
* Arguments     : u1_motor_status - motor control status
*               : u1_system_status - system status
* Return Value  : None
***********************************************************************************************************************/
void RM_MTR_BoardLedContrl(uint8_t u1_motor_status, uint8_t u1_system_status)
{
    /***** LED control *****/
    if (MODE_ERROR == u1_system_status)       /* Check motor status */
    {
        R_IOPORT_PinWrite(g_ioport.p_ctrl, BSP_IO_PORT_09_PIN_13, BSP_IO_LEVEL_HIGH);       /* LED1 off */
        R_IOPORT_PinWrite(g_ioport.p_ctrl, BSP_IO_PORT_09_PIN_14, BSP_IO_LEVEL_LOW);        /* LED2 on */
    }
    else
    {
        if (MTR_MODE_STOP == u1_motor_status)         /* Check motor status */
        {
            R_IOPORT_PinWrite(g_ioport.p_ctrl, BSP_IO_PORT_09_PIN_13, BSP_IO_LEVEL_HIGH);   /* LED1 off */
            R_IOPORT_PinWrite(g_ioport.p_ctrl, BSP_IO_PORT_09_PIN_14, BSP_IO_LEVEL_HIGH);   /* LED2 off */
        }
        else if (MTR_MODE_DRIVE == u1_motor_status)      /* Check motor status */
        {
            R_IOPORT_PinWrite(g_ioport.p_ctrl, BSP_IO_PORT_09_PIN_13, BSP_IO_LEVEL_LOW);    /* LED1 on */
            R_IOPORT_PinWrite(g_ioport.p_ctrl, BSP_IO_PORT_09_PIN_14, BSP_IO_LEVEL_HIGH);   /* LED2 off */
        }
        else
        {
            __NOP(); /* do nothing */
        }
    }
} /* End of function RM_MTR_BoardLedContrl */
