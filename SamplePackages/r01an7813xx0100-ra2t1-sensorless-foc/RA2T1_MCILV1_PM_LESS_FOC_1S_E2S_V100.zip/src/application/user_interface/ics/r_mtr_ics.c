/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ics.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Main associated header file */
#include "rm_mtr_common.h"
#include "rm_mtr_driver.h"
#include "rm_mtr_parameter.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "r_mtr_ics.h"
#include "r_mtr_ra2t1.h"
#if (USE_OPENLOOP_DAMPING == MTR_SET)
#include "rm_mtr_ol2cl_ctrl.h"
#endif

#include "ICS2_RA2T1.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
st_mtr_ctrl_input_t st_ics;               /* structure for ICS input */


/***********************************************************************************************************************
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const st_com_t g_st_com_init =
{
    .com_f4_ref_speed_rpm        = 0,
    .com_u1_direction            = 0,
    .com_u2_mtr_pp               = MP_POLE_PAIRS,
    .com_f4_mtr_r                = MP_RESISTANCE,
    .com_f4_mtr_ld               = MP_D_INDUCTANCE,
    .com_f4_mtr_lq               = MP_Q_INDUCTANCE,
    .com_f4_mtr_m                = MP_BEMF_CONSTANT,
    .com_f4_mtr_j                = MP_ROTOR_INERTIA,
    .com_f4_mtr_d0               = MP_FRICTION_0TH_ORDER,
    .com_f4_mtr_d1               = MP_FRICTION_1ST_ORDER,
    .com_u2_offset_calc_cnt      = CP_OFFSET_CALC_CNT,
    .com_f4_ramp_limit_speed_rpm = CP_RAMP_LIMIT_SPEED_RPM,
    .com_f4_max_speed_rpm        = CP_MAX_SPEED_RPM,
    .com_f4_cl2ol_speed_rpm      = CP_CL2OL_SPEED_RPM,
    .com_f4_ol2cl_speed_rpm      = CP_OL2CL_SPEED_RPM,
    .com_f4_ol_ref_id            = CP_OL_REF_ID,
    .com_f4_draw_in_wait_time    = CP_DRAW_IN_WAIT_TIME,
    .com_f4_init_asr_intg        = CP_INIT_ASR_INTEG,
    .com_f4_ramp_limit_current   = CP_RAMP_LIMIT_CURRENT,

    .st_com.f4_pll_nf_hz           = CP_PLL_NF_HZ,
    .st_com.f4_acr_nf_hz           = CP_ACR_NF_HZ,
    .st_com.f4_asr_nf_hz           = CP_ASR_NF_HZ,
    .st_com.f4_asr_lpf_cof_hz      = CP_ASR_LPF_COF_HZ,
    .st_com.f4_acr_lpf_cof_hz      = CP_ACR_LPF_COF_HZ,
    .st_com.f4_acr_deadband_lsb    = CP_ACR_DEADBAND_LSB,
    .st_com.f4_asr_deadband_lsb    = CP_ASR_DEADBAND_LSB,
    .st_com.f4_pll_deadband_lsb    = CP_PLL_DEADBAND_LSB,
    .st_com.f4_asr_ki_aug          = CP_ASR_KI_AUG,

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    .com_f4_i_repro_cof_hz      = CP_I_REPRO_COF_HZ,
#endif
#if ((MOD_3PH_SPWM == MOD_METHOD) || (MOD_3PH_TOW == MOD_METHOD))
    .com_s2_ad_point_a_adj_cnt  = CP_AD_POINT_A_ADJ_CNT,
    .com_s2_ad_point_b_adj_cnt  = CP_AD_POINT_B_ADJ_CNT,
#elif (MOD_2PH_BOT == MOD_METHOD)
    .com_s4_mod_3ph2ph_speed_rpm   = CP_MOD_3PH2PH_SPEED_RPM,
    .com_s4_mod_2ph3ph_speed_rpm   = CP_MOD_2PH3PH_SPEED_RPM,
    .com_s2_ad_point_a_adj_cnt_3ph = CP_AD_POINT_A_ADJ_CNT,
    .com_s2_ad_point_b_adj_cnt_3ph = CP_AD_POINT_B_ADJ_CNT,
    .com_s2_ad_point_a_adj_cnt_2ph = CP_AD_POINT_A_ADJ_2PH_CNT,
    .com_s2_ad_point_b_adj_cnt_2ph = CP_AD_POINT_B_ADJ_2PH_CNT,
#endif
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */
#if (MOD_2PH_BOT == MOD_METHOD)
    .com_s2_mod_2ph_bot_change_cnt = CP_MOD_2PH_BOT_CHANGE_CNT,
#endif
#if (USE_OPENLOOP_DAMPING == MTR_SET)
    .com_f4_damp_hpf_cof_hz       = CP_DAMP_HPF_COF_HZ,
    .com_f4_damp_zeta             = CP_DAMP_ZETA,
    .com_f4_damp_speed_limit_rate = CP_DAMP_SPEED_LIMIT_RATE,
#endif
#if (USE_OL2CL_CTRL == MTR_SET)
    .com_f4_pherr_lpf_cof_hz    = CP_PHASE_ERR_LPF_COF_HZ,
    .com_f4_ol2cl_switch_time   = CP_OL2CL_SWITCH_TIME,
#endif
    .com_s2_enable_write = 0,

};

st_com_t g_st_com;

const st_mtr_design_parameter_macro_t g_st_design_param_macro =
{
    .f4_pu_sf_afreq         = PU_SF_AFREQ,
    .f4_dt                  = MTR_CTRL_PERIOD * PU_SF_TIME,
    .f4_dt_speed            = MTR_SPEED_CTRL_PERIOD * PU_SF_TIME,
    .f4_i_lim_vd            = MTR_I_LIMIT_VD * PU_SF_VOLTAGE,
    .f4_i_lim_vq            = MTR_I_LIMIT_VQ * PU_SF_VOLTAGE,
    .f4_speed_lim_rad       = MTR_SPEED_LIMIT_RAD * PU_SF_AFREQ,
    .u1_q_current           = MTR_Q_CURRENT,
    .u1_q_pll_kp            = MTR_Q_PLL_KP,
    .u1_q_pll_kidt          = MTR_Q_PLL_KIDT,
    .u1_q_pll_deadband      = (MTR_Q_PLL_KIDT - MTR_Q_AFREQ) + MTR_Q_ANGLE,
    .u1_q_acr_kp            = MTR_Q_ACR_KP,
    .u1_q_acr_kidt          = MTR_Q_ACR_KIDT,
    .u1_q_acr_deadband      = (MTR_Q_ACR_KIDT - MTR_Q_VOLTAGE) + MTR_Q_CURRENT,
    .u1_q_asr_kp            = MTR_Q_ASR_KP,
    .u1_q_asr_kidt          = MTR_Q_ASR_KIDT,
    .u1_q_asr_deadband      = (MTR_Q_ASR_KIDT - MTR_Q_CURRENT) + MTR_Q_AFREQ,
    .u1_q_asr_lpf_k         = MTR_Q_SPEED_LPF_CO,
    .u1_q_acr_lpf_k         = MTR_Q_CURRENT_LPF_CO,
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    .u1_q_i_repro_lpf_k     = MTR_Q_CURRENT_REPO_LPF_CO,
#endif
#endif
#if (USE_OPENLOOP_DAMPING == MTR_SET)
    .u1_q_damp_k            = MTR_Q_DAMP_K,
    .u1_q_damp_hpf_k        = MTR_Q_DAMP_HPF_CO,
#endif
#if (USE_OL2CL_CTRL == MTR_SET)
    .u1_q_ol2cl_current_k1  = MTR_Q_OL2CL_K1,
    .u1_q_pherr_lpf_k       = MTR_Q_PHERR_LPF_CO,
#endif
    .u1_q_d1_div_p2m        = MTR_Q_D1_DIV_P2M,
    .u1_q_pi_run_acr_err    = MTR_Q_PI_RUN_ACR_ERR,
    .u1_q_pi_run_asr_err    = MTR_Q_PI_RUN_ASR_ERR,
    .u1_q_pi_run_pll_err    = MTR_Q_PI_RUN_PLL_ERR,
    .u1_q_afreq             = MTR_Q_AFREQ,
};

int16_t    g_s2_enable_write;             /* ICS write enable flag */

/***********************************************************************************************************************
* Private variables
***********************************************************************************************************************/
static uint8_t s_u1_cnt_ics = 0;

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/
static inline int32_t mtr_limit (int32_t s4_value, int32_t s4_max, int32_t s4_min);

/***********************************************************************************************************************
* @fn             R_MTR_SetIcs
* @brief          Set to prepare ICS
* @return         None
***********************************************************************************************************************/
void R_MTR_SetIcs(void)
{
    /*============================*/
    /*         for ICS            */
    /*============================*/
    s_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (MTR_ICS_DECIMATION < s_u1_cnt_ics)
    {
        ics2_watchpoint();
        s_u1_cnt_ics = 0;
    }
} /* End of function R_MTR_SetIcs */

/***********************************************************************************************************************
* @fn             R_MTR_SetCOMVariables
* @brief          Set com variables to "tool" input buffer
* @return         None
***********************************************************************************************************************/
void R_MTR_SetCOMVariables(void)
{
    int8_t s1_dir = MTR_CW;

    /*============================*/
    /*      get ICS value         */
    /*============================*/
    /***** When com_s2_enable_sw and g_s2_enable_sw are same value, rewrite enable. *****/
    if (g_st_com.com_s2_enable_write == g_s2_enable_write)
    {
        /***** limit input speed *****/
        g_st_com.com_f4_ref_speed_rpm = (float)mtr_limit((int32_t)g_st_com.com_f4_ref_speed_rpm,
                                                            (int32_t)g_st_com.com_f4_max_speed_rpm, 0);

        /* reference speed */
        st_ics.s4_ref_speed = FIX_fromfloat(g_st_com.com_f4_ref_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        /* rotation direction */
        if (MTR_CW == g_st_com.com_u1_direction)
        {
            s1_dir = MTR_CCW;
        }
        else
        {
            s1_dir = MTR_CW;
        }
        st_ics.s1_ref_direction = s1_dir;

        /* motor parameter */
        st_ics.st_motor.s4_mtr_r  = FIX_fromfloat(g_st_com.com_f4_mtr_r * PU_SF_RES, MTR_Q_RESISTANCE);
        st_ics.st_motor.s4_mtr_ld = FIX_fromfloat(g_st_com.com_f4_mtr_ld * PU_SF_IND, MTR_Q_INDUCTANCE);
        st_ics.st_motor.s4_mtr_lq = FIX_fromfloat(g_st_com.com_f4_mtr_lq * PU_SF_IND, MTR_Q_INDUCTANCE);
        st_ics.st_motor.s4_mtr_ke = FIX_fromfloat(g_st_com.com_f4_mtr_m * PU_SF_BEMF_CONST, MTR_Q_BEMF_CONST);
        st_ics.st_motor.s4_mtr_j  = FIX_fromfloat(g_st_com.com_f4_mtr_j * PU_SF_INERTIA, MTR_Q_INERTIA);
        st_ics.st_motor.u2_mtr_pp = g_st_com.com_u2_mtr_pp;

        /* current offset calculation time */
        st_ics.u2_cnt_offset_calc = g_st_com.com_u2_offset_calc_cnt;

        /* phase error integral gain */
        /* current PI gain */
        /* speed PI gain */
        /* Speed LPF gain */
        /* Current LPF gain */
        /* Augmentation rate for integral part of ASR  */
        g_st_ctrl_params.st_com = g_st_com.st_com;

        /* limit of speed change */
        st_ics.s4_lim_accel = FIX_fromfloat(g_st_com.com_f4_ramp_limit_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        /* max speed */
        st_ics.s4_max_speed = FIX_fromfloat(g_st_com.com_f4_max_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        /* Speed of switching from sensorless to open loop */
        st_ics.s4_th_speed_cl2ol = FIX_fromfloat(g_st_com.com_f4_cl2ol_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        /* Speed of switching from open loop to sensorless */
        st_ics.s4_th_speed_ol2cl = FIX_fromfloat(g_st_com.com_f4_ol2cl_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        /* id reference when low speed */
        st_ics.s4_ref_id_ol = FIX_fromfloat(g_st_com.com_f4_ol_ref_id * PU_SF_CURRENT, MTR_Q_CURRENT);

        /* Draw-in wait time count value */
        st_ics.s4_cnt_wait_draw_in = (int16_t)(g_st_com.com_f4_draw_in_wait_time / MTR_SPEED_CTRL_PERIOD);

        /* q-axis pi control initial integral parameter */
        st_ics.s4_coef_init_intg = FIX_fromfloat(g_st_com.com_f4_init_asr_intg, MTR_Q_CURRENT);

        /* Limit of current value change A/ms] */
        st_ics.s4_lim_current = FIX_fromfloat(g_st_com.com_f4_ramp_limit_current * PU_SF_CURRENT, MTR_Q_CURRENT);

#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
        /*********** For 1shunt ***********/
#if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
        g_st_ctrl_params.f4_i_repro_cof_hz = g_st_com.com_f4_i_repro_cof_hz;
#endif
#if (MOD_2PH_BOT == MOD_METHOD)
        /* Switching speed from 3-phase to 2-phase modulation */
        st_ics.s4_mod_3ph2ph_speed_rad
            = FIX_fromfloat(g_st_com.com_s4_mod_3ph2ph_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        /* Switching speed from 2-phase to 3-phase modulation */
        st_ics.s4_mod_2ph3ph_speed_rad
            = FIX_fromfloat(g_st_com.com_s4_mod_2ph3ph_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        st_ics.s2_ad_point_a_adj_cnt_3ph = g_st_com.com_s2_ad_point_a_adj_cnt_3ph;
        st_ics.s2_ad_point_b_adj_cnt_3ph = g_st_com.com_s2_ad_point_b_adj_cnt_3ph;
        st_ics.s2_ad_point_a_adj_cnt_2ph = g_st_com.com_s2_ad_point_a_adj_cnt_2ph;
        st_ics.s2_ad_point_b_adj_cnt_2ph = g_st_com.com_s2_ad_point_b_adj_cnt_2ph;
#else
        st_ics.s2_ad_point_a_adj_cnt = g_st_com.com_s2_ad_point_a_adj_cnt;
        st_ics.s2_ad_point_b_adj_cnt = g_st_com.com_s2_ad_point_b_adj_cnt;
#endif
#endif
#if (MOD_2PH_BOT == MOD_METHOD)
        st_ics.s2_mod_2ph_bot_change_cnt = g_st_com.com_s2_mod_2ph_bot_change_cnt;
#endif
#if (USE_OPENLOOP_DAMPING == MTR_SET)
        g_st_ctrl_params.f4_damp_hpf_cof_hz  = g_st_com.com_f4_damp_hpf_cof_hz;
        g_st_ctrl_params.f4_damp_zeta        = g_st_com.com_f4_damp_zeta;
        st_ics.s4_speed_limit_rate
            = FIX_fromfloat(g_st_com.com_f4_damp_speed_limit_rate, MTR_Q_DAMP_SL_RATE);
        g_st_ctrl_params.u2_mtr_pp           = g_st_com.com_u2_mtr_pp;
        g_st_ctrl_params.f4_ol_ref_id        = g_st_com.com_f4_ol_ref_id * PU_SF_CURRENT;
        g_st_ctrl_params.f4_ol2cl_speed      = g_st_com.com_f4_ol2cl_speed_rpm * PU_SF_RPM_RAD;
        g_st_ctrl_params.f4_ramp_limit_speed
            = g_st_com.com_f4_ramp_limit_speed_rpm * PU_SF_RPM_RAD * PU_SF_AFREQ * 1000;
#endif
#if (USE_OL2CL_CTRL == MTR_SET)
        /* phase error lpf natural frequency [Hz] */
        g_st_ctrl_params.f4_pherr_lpf_cof_hz = g_st_com.com_f4_pherr_lpf_cof_hz;

        /* Time[s] to switch open-loop to sensorless */
        g_st_ctrl_params.f4_ol2cl_switch_time = g_st_com.com_f4_ol2cl_switch_time * PU_SF_TIME;
#endif
        g_st_ctrl_params.f4_r  = g_st_com.com_f4_mtr_r * PU_SF_RES;
        g_st_ctrl_params.f4_ld = g_st_com.com_f4_mtr_ld * PU_SF_IND;
        g_st_ctrl_params.f4_lq = g_st_com.com_f4_mtr_lq * PU_SF_IND;
        g_st_ctrl_params.f4_ke = g_st_com.com_f4_mtr_m * PU_SF_BEMF_CONST;
        g_st_ctrl_params.f4_j  = g_st_com.com_f4_mtr_j * PU_SF_INERTIA;

        /* calculate the terms related to friction */
        g_st_ctrl_params.f4_d0_div_pm
            = (g_st_com.com_f4_mtr_d0
            / (g_st_com.com_u2_mtr_pp * g_st_com.com_f4_mtr_m))
            * PU_SF_CURRENT;
        g_st_ctrl_params.f4_d1_div_p2m
            = (g_st_com.com_f4_mtr_d1
            / (g_st_com.com_u2_mtr_pp * g_st_com.com_u2_mtr_pp * g_st_com.com_f4_mtr_m))
            * PU_SF_D1_DIV_P2M;

        /* Calculate motor control gains and set trigger flag */
        RM_MTR_IcsBufferSet();

        g_s2_enable_write ^= 1;                         /* change every time 0 and 1 */
    }

} /* End of function R_MTR_SetCOMVariables */

/***********************************************************************************************************************
* @fn             R_MTR_ICSVariablesInit
* @brief          Initialize valiables for Analyzer interface
* @return         None
***********************************************************************************************************************/
void R_MTR_ICSVariablesInit(void)
{
    g_st_com = g_st_com_init;

/*    st_ics.st_ctrl_params.st_macro = g_st_design_param_macro; */
    g_st_ctrl_params.st_macro = g_st_design_param_macro;

    g_s2_enable_write   = 0;
} /* End of function R_MTR_ICSVariablesInit */

/***********************************************************************************************************************
* @fn             mtr_limit
* @brief          Limit with max limit value and minimum limit value
* @param[in]      s4_value   Target value,
* @param[in]      s4_max     Max limit value,
* @param[in]      s4_min     Minimum limit value
* @return         limited target value
***********************************************************************************************************************/
static inline int32_t mtr_limit(int32_t s4_value, int32_t s4_max, int32_t s4_min)
{
    if (s4_value > s4_max)
    {
        return (s4_max);
    }
    else if (s4_value < s4_min)
    {
        return (s4_min);
    }
    else
    {
        return (s4_value);
    }
} /* End of function mtr_limit */

