/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ics.h
* Description : Definitions of a user interface (tool) processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_ICS_H
#define R_MTR_ICS_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
//#define TS_50US
//#define TS_100US
#define TS_300US


/* ICS watch point configuration */
#ifdef TS_300US
#define     ICS_BRR                         (4)

#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#if (CP_INT_DECIMATION == 0)
#define     MTR_ICS_DECIMATION              (5)
#elif (CP_INT_DECIMATION == 1)
#define     MTR_ICS_DECIMATION              (2)
#else
#error "ICS watch point error"
#endif /* CP_INT_DECIMATION */
#elif (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_40KHZ)
#if (CP_INT_DECIMATION == 1)
#define     MTR_ICS_DECIMATION              (5)
#elif (CP_INT_DECIMATION == 3)
#define     MTR_ICS_DECIMATION              (2)
#else
#error "ICS watch point error"
#endif /* CP_INT_DECIMATION */
#else
#error "ICS watch point error"
#endif /* CP_CARRIER_FREQ_SEL */
#endif /* #ifdef TS_300US */

#ifdef TS_100US
#define     ICS_BRR                         (0)

#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#if (CP_INT_DECIMATION == 0)
#define     MTR_ICS_DECIMATION              (1)
#elif (CP_INT_DECIMATION == 1)
#define     MTR_ICS_DECIMATION              (0)
#else
#error "ICS watch point error"
#endif /* CP_INT_DECIMATION */
#elif (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_40KHZ)
#if (CP_INT_DECIMATION == 1)
#define     MTR_ICS_DECIMATION              (1)
#elif (CP_INT_DECIMATION == 3)
#define     MTR_ICS_DECIMATION              (0)
#else
#error "ICS watch point error"
#endif /* CP_INT_DECIMATION */
#else
#error "ICS watch point error"
#endif /* CP_CARRIER_FREQ_SEL */
#endif /* #ifdef TS_100US */

#ifdef TS_50US
#define     ICS_BRR                         (0)
/* 50us cycle only. Cannot be used when using interrupt skipping. */
#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#if (CP_INT_DECIMATION == 0)
#define     MTR_ICS_DECIMATION              (0)
#elif (CP_INT_DECIMATION == 1)
#define     MTR_ICS_DECIMATION              (0)
#else
#error "ICS watch point error"
#endif /* CP_INT_DECIMATION */
#elif (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_40KHZ)
#if (CP_INT_DECIMATION == 1)
#define     MTR_ICS_DECIMATION              (0)
#elif (CP_INT_DECIMATION == 3)
#define     MTR_ICS_DECIMATION              (0)
#else
#error "ICS watch point error"
#endif /* CP_INT_DECIMATION */
#else
#error "ICS watch point error"
#endif /* CP_CARRIER_FREQ_SEL */
#endif /* #ifdef TS_50US */

/* for I/F initialization of Renesas Motor Workbench */
#define     ICS_ADDR                        (0xFE00)
#define     ICS_INT_LEVEL                   (3)
#define     ICS_NUM                         (0x40)
#define     ICS_INT_MODE                    (0)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    st_mtr_design_parameter_com_t
                st_com;

    uint8_t     com_u1_direction;              /* Rotational direction (0:CW ,1:CCW) */
    float       com_f4_mtr_r;                  /* Resistance [ohm] */
    float       com_f4_mtr_ld;                 /* d-axis inductance [H] */
    float       com_f4_mtr_lq;                 /* q-axis inductance [H] */
    float       com_f4_mtr_m;                  /* Permanent magnetic Back-EMF constant [V*s/m] */
    float       com_f4_mtr_j;                  /* Rotor inertia [[kgm^2] */
    float       com_f4_mtr_d0;                 /* 0th order friction coefficient [N*m] */
    float       com_f4_mtr_d1;                 /* 1st order friction coefficient [N*m*s/rad] */
    uint16_t    com_u2_mtr_pp;                 /* Pole pairs */
    uint16_t    com_u2_offset_calc_cnt;        /* Current offset calculation time [cnt] */
    float       com_f4_ref_speed_rpm;          /* Motor speed reference [rpm] (mechanical) */
    float       com_f4_ramp_limit_speed_rpm;   /* Limit of acceleration [rpm/ms] (mechanical) */
    float       com_f4_max_speed_rpm;          /* Maximum speed [rpm] (mechanical) */
    float       com_f4_cl2ol_speed_rpm;        /* Speed of switching from sensorless to open loop [rpm] (mechanical) */
    float       com_f4_ol2cl_speed_rpm;        /* Speed of switching from open loop to sensorless [rpm] (mechanical) */
    float       com_f4_ol_ref_id;              /* id reference when low speed [A] */
    float       com_f4_draw_in_wait_time;      /* Draw-in wait time count value [s] */
    float       com_f4_init_asr_intg;          /* q-axis pi control initial integral parameter */
    float       com_f4_ramp_limit_current;     /* Limit of current value change A/ms] */
    #if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    #if (USE_DUTY_2PH_CROS_COMP == MTR_SET)
    float       com_f4_i_repro_cof_hz;         /* LPF cut-off frequency for current reproduction [Hz] */
    #endif
    #if (MOD_2PH_BOT == MOD_METHOD)
    int32_t     com_s4_mod_3ph2ph_speed_rpm;   /* Switching speed from 3-phase to 2-phase modulation [rpm] (mechanical) */
    int32_t     com_s4_mod_2ph3ph_speed_rpm;   /* Switching speed from 2-phase to 3-phase modulation [rpm] (mechanical) */
    int16_t     com_s2_ad_point_a_adj_cnt_3ph; /* A point delay adjustment count of A/D for 3phase modulation */
    int16_t     com_s2_ad_point_b_adj_cnt_3ph; /* B point delay adjustment count of A/D for 3phase modulation */
    int16_t     com_s2_ad_point_a_adj_cnt_2ph; /* A point delay adjustment count of A/D for 2phase modulation */
    int16_t     com_s2_ad_point_b_adj_cnt_2ph; /* B point delay adjustment count of A/D for 2phase modulation */
    #else
    int16_t     com_s2_ad_point_a_adj_cnt;     /* A point delay adjustment count of A/D */
    int16_t     com_s2_ad_point_b_adj_cnt;     /* B point delay adjustment count of A/D */
    #endif
    #endif
    #if (MOD_2PH_BOT == MOD_METHOD)
    int16_t     com_s2_mod_2ph_bot_change_cnt; /* 2-phase modulation phase switching judgment counter */
    #endif
    #if (USE_OPENLOOP_DAMPING == MTR_SET)
    float       com_f4_damp_hpf_cof_hz;        /* ed hpf natural frequency [Hz] for open-loop damping control */
    float       com_f4_damp_zeta;              /* damping factor for open-loop damping control */
    float       com_f4_damp_speed_limit_rate;  /* Speed limit rate */
    #endif
    #if (USE_OL2CL_CTRL == MTR_SET)
    float       com_f4_pherr_lpf_cof_hz;       /* phase error lpf natural frequency [Hz] */
    float       com_f4_ol2cl_switch_time;      /* Time[s] to switch open-loop to sensor-less */
    #endif

    int16_t     com_s2_enable_write;           /* ICS write enable flag */
} st_com_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : R_MTR_SetIcs
* Description   : Set to prepare ICS
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MTR_SetIcs (void);

/***********************************************************************************************************************
* Function Name : R_MTR_SetCOMVariables
* Description   : Set com variables to global value
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_SetCOMVariables (void);

/***********************************************************************************************************************
* Function Name : R_MTR_ICSVariablesInit
* Description   : Set global value to ics watch buffer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ICSVariablesInit (void);

/***********************************************************************************************************************
* Function Name : R_MTR_ICSIntLevel
* Description   : Initialize valiables for Analyzer interface
* Arguments     : u1_level - priority level
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ICSIntLevel (uint8_t u1_level);
#endif /* R_MTR_ICS_H */
