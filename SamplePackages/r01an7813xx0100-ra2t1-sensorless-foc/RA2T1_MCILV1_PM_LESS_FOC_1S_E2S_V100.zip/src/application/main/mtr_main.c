/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_main.c
* Description : The main function and the processes of application layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_pin_data.h"
#include "rm_mtr_common.h"
#include "rm_mtr_driver.h"
#include "rm_mtr_foc_less_speed.h"
#include "rm_mtr_statemachine.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "mtr_main.h"
#include "r_mtr_ra2t1.h"
#include "r_mtr_board.h"

/****** for ICS ******/
#include "ICS2_RA2T1.h"
#include "r_mtr_ics.h"
/*********************/

#include "r_mtr_config.h"
#include "hal_data.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* COM Error Resolution for RMW */
#define     CONF_MOTOR_TYPE ("Brushless DC Motor")
#define     CONF_CONTROL ("Sensorless vector control (Speed control)")
#define     CONF_INVERTER ("MCI-LV-1")
#define     CONF_MOTOR_TYPE_LEN (18)
#define     CONF_CONTROL_LEN (41)
#define     CONF_INVERTER_LEN (8)

/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/
/* Renesas Motor Workbench Configurations */
uint16_t    g_u2_conf_hw         = 0x100C;       /* HW configrations   : LV Renesas */
uint16_t    g_u2_conf_sw         = 0x0000;       /* SW configrations   : Sensorless vector control (Speed control) */
uint16_t    g_u2_conf_tool       = 0x0200;       /* Tool configrations : Analyzer */
uint8_t     gui_u1_active_gui;
uint16_t    g_u2_conf_sw_ver;

uint8_t     com_u1_run_event;                    /* system mode */
uint8_t     g_u1_run_event;                      /* system mode */

/* COM Error Resolution for RMW */
uint8_t     g_u1_conf_motor_type_len;
uint8_t     g_u1_conf_control_len;
uint8_t     g_u1_conf_inverter_len;
uint8_t     g_u1_conf_motor_type[CONF_MOTOR_TYPE_LEN];
uint8_t     g_u1_conf_control[CONF_CONTROL_LEN];
uint8_t     g_u1_conf_inverter[CONF_INVERTER_LEN];

extern st_mtr_common_foc_t g_st_foc_common;

/***********************************************************************************************************************
* Private functions
***********************************************************************************************************************/
static void     ics_ui (void);                   /* ICS (Analyzer) user interface */
static int      system_init (void);              /* System initialize */
static void     system_term (void);              /* System terminal */
static void     software_init (void);            /* Software initialize */

/***********************************************************************************************************************
* Private variables
***********************************************************************************************************************/
static uint8_t     g_u1_system_mode;             /* system status */
static uint8_t     g_u1_motor_status;            /* motor status */
static uint16_t    g_u2_error_status;            /* error status */

/***********************************************************************************************************************
* Function Name : main
* Description   : Initialization and main routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_main(void)
{
    /* COM Error Resolution for RMW */
    int i;
    uint8_t u1_conf_motor_type[] = CONF_MOTOR_TYPE;
    uint8_t u1_conf_control[] = CONF_CONTROL;
    uint8_t u1_conf_inverter[] = CONF_INVERTER;
    g_u1_conf_motor_type_len = CONF_MOTOR_TYPE_LEN;
    g_u1_conf_control_len    = CONF_CONTROL_LEN;
    g_u1_conf_inverter_len   = CONF_INVERTER_LEN;
    for (i = 0; i < g_u1_conf_motor_type_len; i++)
    {
        g_u1_conf_motor_type[i] = u1_conf_motor_type[i];
    }
    for (i = 0; i < g_u1_conf_control_len; i++)
    {
        g_u1_conf_control[i] = u1_conf_control[i];
    }
    for (i = 0; i < g_u1_conf_inverter_len; i++)
    {
        g_u1_conf_inverter[i] = u1_conf_inverter[i];
    }
    g_u2_conf_hw = 0x0008;                        /* 0000000000001000b */
    g_u2_conf_sw = 0x0000;                        /* 0000000000000000b */
    g_u2_conf_tool = 0x0300;                      /* 0000011000000000b */

    __disable_irq();
    {
        if (0 != system_init())
        {
            system_term();
            return;
        }

        /* Initialize unused pins */
        R_MTR_InitUnusedPins();

        /****** for ICS ******/
        ics2_init(ICS_SCI0_P101_P100, 3, ICS_BRR, 1);
    //    ics2_init(ICS_SCI0_P101_P100, 3, 0, 1); /* 5.00[MBPS] */
    //    ics2_init(ICS_SCI0_P101_P100, 3, 4, 1); /* 1.00[MBPS] */

        RM_MTR_ControlInit();                        /* Initializes FOC motor controller */
        software_init();                            /* Initialize private global variables */
        RM_MTR_EventExec(MTR_EVENT_RESET);           /* Execute reset event */
    }

    __enable_irq();
    {
        g_st_foc_common.st_foc_carrier.u2_error_status |= RM_MTR_CapacitorCharge();       /* wait for charge of capacitor */

        /*** main routine ***/
        while (1)
        {
            ics_ui();                           /* user interface using Renesas Motor Workbench */

            /* LED control */
            RM_MTR_BoardLedContrl(g_u1_motor_status, g_u1_system_mode);

            R_WDT_Refresh(g_wdt0.p_ctrl);                       /* watch dog timer clear */
        }
    }
}

/***********************************************************************************************************************
* Function Name : ics_ui
* Description   : User interface using ICS
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void ics_ui(void)
{
    uint8_t u1_run_event_buff;
    R_MTR_SetCOMVariables();
    g_u1_motor_status = RM_MTR_StatusGet();              /* get status of motor control system */
    g_u2_error_status = RM_MTR_StatusErrorGet();

    /*==============================*/
    /*        execute event         */
    /*==============================*/
    u1_run_event_buff = com_u1_run_event;            /* prevent com_u1_event_system rewritten in interrupt */

    if (g_u1_run_event != u1_run_event_buff)
    {
        if (MODE_ACTIVE == g_u1_system_mode)
        {
            if (u1_run_event_buff >= MTR_SIZE_EVENT)
            {
                com_u1_run_event = g_u1_run_event;
            }
            else
            {
                g_u1_run_event = u1_run_event_buff;
                RM_MTR_EventExec(g_u1_run_event);
            }
        }
        else if (MODE_ERROR == g_u1_system_mode)
        {
            if (MTR_EVENT_RESET == u1_run_event_buff)
            {
                g_u1_run_event = u1_run_event_buff;
                RM_MTR_EventExec(MTR_EVENT_RESET);       /* execute reset event */
                g_u2_error_status = RM_MTR_StatusErrorGet();
                g_u1_system_mode  = MODE_ACTIVE;
            }
        }
        else
        {
            __NOP(); /* do nothing */
        }
    }

    if (MTR_EVENT_RESET == g_u1_run_event)
    {
        if (MTR_MODE_DRIVE != g_u1_motor_status)
        {
            if (MTR_ERROR_NONE == g_u2_error_status)
            {
                software_init();                            /* initialize private global variables for reset event */
            }
        }
        else
        {
            g_u1_run_event   = MTR_EVENT_DRIVE;
            com_u1_run_event = MTR_EVENT_DRIVE;
        }
    }

    if ((MTR_ERROR_NONE != g_u2_error_status) || (MTR_EVENT_ERROR == g_u1_run_event))
    {
        g_u1_run_event   = MTR_EVENT_ERROR;
        com_u1_run_event = MTR_EVENT_ERROR;
        g_u1_system_mode = MODE_ERROR;
    }

} /* End of function ics_ui */

/***********************************************************************************************************************
* Function Name : software_init
* Description   : Initialize system modules
* Arguments     : None
* Return Value  : 0 when system initialization succeeded.
*               : 1 otherwise
***********************************************************************************************************************/
static int system_init(void)
{
    if (FSP_SUCCESS != R_IOPORT_Open(&g_user_pin_ctrl, &g_user_pin_cfg))
    {
        return 1;
    }

    if (FSP_SUCCESS != R_IOPORT_Open(g_ioport.p_ctrl, g_ioport.p_cfg))
    {
        return 1;
    }

    if (FSP_SUCCESS != R_WDT_Open(g_wdt0.p_ctrl, g_wdt0.p_cfg))
    {
        return 1;
    }

#if (USE_ADC_FAST_MODE == MTR_SET)
    if (FSP_SUCCESS != R_MTR_ADC_Open(g_adc0.p_ctrl, g_adc0.p_cfg))
    {
        return 1;
    }
    if (FSP_SUCCESS != R_MTR_ADC_SetSampleStateCount(g_adc0.p_ctrl))
#else
    if (FSP_SUCCESS != R_ADC_Open(g_adc0.p_ctrl, g_adc0.p_cfg))
#endif
    {
        return 1;
    }
    if (FSP_SUCCESS != R_ADC_ScanCfg(g_adc0.p_ctrl, g_adc0.p_channel_cfg))
    {
        return 1;
    }
    if (FSP_SUCCESS != R_ADC_ScanStart(g_adc0.p_ctrl))
    {
        return 1;
    }

    if (FSP_SUCCESS != R_AGT_Open(g_agt0.p_ctrl, g_agt0.p_cfg))
    {
        return 1;
    }
    if (FSP_SUCCESS != R_AGT_Start(g_agt0.p_ctrl))
    {
        return 1;
    }

    if (FSP_SUCCESS != R_POEG_Open(g_poeg0.p_ctrl, g_poeg0.p_cfg))
    {
        return 1;
    }

#if (THREE_SHUNT == CURRENT_SENS_METHOD)
    if (FSP_SUCCESS != R_MTR_GPT_THREE_PHASE_CompMode2_Open(g_three_phase0.p_ctrl, g_three_phase0.p_cfg))
    {
        return 1;
    }
#endif /* #if (THREE_SHUNT == CURRENT_SENS_METHOD) */
#if (SINGLE_SHUNT == CURRENT_SENS_METHOD)
    if (FSP_SUCCESS != R_MTR_GPT_THREE_PHASE_CompMode3_Open(g_three_phase0.p_ctrl, g_three_phase0.p_cfg))
    {
        return 1;
    }
#endif /* #if (SINGLE_SHUNT == CURRENT_SENS_METHOD) */
    if (FSP_SUCCESS != R_GPT_THREE_PHASE_Start(g_three_phase0.p_ctrl))
    {
        return 1;
    }

    return 0;
} /* End of function system_init */

/***********************************************************************************************************************
* Function Name : system_term
* Description   : Terminate system modules
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void system_term(void)
{
    R_GPT_THREE_PHASE_Stop(g_three_phase0.p_ctrl);
    R_GPT_THREE_PHASE_Close(g_three_phase0.p_ctrl);

    R_POEG_Close(g_poeg0.p_ctrl);

    R_AGT_Stop(g_agt0.p_ctrl);
    R_AGT_Close(g_agt0.p_ctrl);

    R_ADC_ScanStop(g_adc0.p_ctrl);
    R_ADC_Close(g_adc0.p_ctrl);

    R_IOPORT_Close(g_ioport.p_ctrl);
} /* End of function system_term */

/***********************************************************************************************************************
* Function Name : software_init
* Description   : Initialize private global variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void software_init(void)
{
    g_u1_system_mode      = MODE_ACTIVE;             /* system status */
    g_u1_motor_status     = MTR_MODE_INIT;           /* motor status */
    g_u2_error_status     = MTR_ERROR_NONE;          /* error status */

    com_u1_run_event      = MTR_EVENT_STOP;          /* change run mode */
    g_u1_run_event        = MTR_EVENT_STOP;          /* change run mode */

    R_MTR_ICSVariablesInit();
    R_MTR_SetCOMVariables();
} /* End of function software_init */
