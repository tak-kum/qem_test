/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_scaling_parameter.h
* Description : Definitons for per-unit system
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

#ifndef R_MTR_SCALING_PARAMETER_H
#define R_MTR_SCALING_PARAMETER_H

/**********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <math.h>
#include "r_mtr_common.h"
#include "r_mtr_config.h"

#include "r_mtr_inverter_parameter.h"

/**********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/

/**********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Created date : 2025/05/14 */
/*================================*/
/*    Fixed Point Scale Factor    */
/*================================*/
#define FP_SF_VOLTAGE            (822226302) /*((IP_VDC_RANGE*PU_SF_VOLTAGE) * (1<<MTR_Q_VOLTAGE))*/
#define FP_SF_CURRENT            (2652206601)  /*((IP_CURRENT_RANGE*PU_SF_CURRENT) * (1<<MTR_Q_CURRENT))*/
#define FP_SF_CURRENT_AD     (FP_SF_CURRENT >> MTR_ADC_12BIT)

/*=======================*/
/*    Base Quantities    */
/*=======================*/
#define PU_BASE_CURRENT_A        (MP_RATED_CURRENT)       /* Base quantity for current */
#define PU_BASE_VOLTAGE_V        (IP_INPUT_V)             /* Base quantity for voltage */
#define PU_BASE_FREQ_Hz          (MTR_TWOPI*CP_MAX_SPEED_RPM*MP_POLE_PAIRS/60)/* base quantity for frequency */
#define PU_BASE_ANGLE_ROT        (1.0f)                   /* Base quantity for angle (DO NOT CHANGE) */

/*============================*/
/*    General scale factor    */
/*============================*/
#define PU_SF_CURRENT            (1.0f / PU_BASE_CURRENT_A)/* Current scale factor */
#define PU_SF_VOLTAGE            (1.0f / PU_BASE_VOLTAGE_V)/* Voltage scale factor */
#define PU_SF_AFREQ              (1.0f / PU_BASE_FREQ_Hz)/* Frequency scale factor */
#define PU_SF_ANGLE              (1.0f / PU_BASE_ANGLE_ROT)/* Angular angle scale factor */

#define PU_SF_TIME               (PU_SF_ANGLE / PU_SF_AFREQ)/* Time scale factor */
#define PU_SF_RES                (PU_SF_VOLTAGE / PU_SF_CURRENT)/* Impedance(resistance) scale factor */
#define PU_SF_IND                (PU_SF_RES / PU_SF_AFREQ)/* Inductance scale factor */
#define PU_SF_BEMF_CONST         (PU_SF_VOLTAGE / PU_SF_AFREQ)/* Flux scale factor */
#define PU_SF_INERTIA            (PU_SF_BEMF_CONST * PU_SF_CURRENT / (MP_POLE_PAIRS * MP_POLE_PAIRS * PU_SF_AFREQ * PU_SF_AFREQ))/* Inertia scale factor */
#define PU_SF_D1_DIV_P2M         (PU_SF_CURRENT / PU_SF_AFREQ)/* 1st order friction coefficient term scale factor */
#define PU_SF_RPM_RAD            (1.0f / CP_MAX_SPEED_RPM)
#define PU_SF_RAD_RPM            (CP_MAX_SPEED_RPM)

/*===========================================*/
/*    Current regulator gain scale factor    */
/*===========================================*/
#define PU_SF_ACR_KP             (PU_SF_RES)/* Proportional gain scale factor of current controller */
#define PU_SF_ACR_KIDT           (PU_SF_RES)/* Integral gain scale factor of current controller */
/*===========================================*/
/*    Speed regulator gain scale factor      */
/*===========================================*/
#define PU_SF_ASR_KP             (PU_SF_CURRENT / PU_SF_AFREQ)/* Proportional gain scale factor of speed controller */
#define PU_SF_ASR_KIDT           (PU_SF_CURRENT / PU_SF_AFREQ)/* Integral gain scale factor of speed controller */
/*===========================================*/
/*    PLL gain scale factor                  */
/*===========================================*/
#define PU_SF_PLL_KP             (PU_SF_AFREQ / PU_SF_ANGLE)
#define PU_SF_PLL_KIDT           (PU_SF_AFREQ / PU_SF_ANGLE)

/* Basic physics quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_ANGLE                     (28)    /* Q-format of angle(rotatrion) */
#define MTR_Q_CURRENT                   (28)    /* Q-format of current */
#define MTR_Q_VOLTAGE                   (28)    /* Q-format of voltage */
#define MTR_Q_VMOD                      (28)    /* Q-format of voltage modulation ratio */
#define MTR_Q_AFREQ                     (28)    /* Q-format of angular frequency */

#define MTR_Q_CTRL_TIME                 (34)    /* Q-format of control execution period */
#define MTR_Q_CTRL_TIME_SPEED           (30)    /* Q-format of speed control execution period */
#define MTR_Q_RESISTANCE                (31)    /* Q-format of resistance */
#define MTR_Q_INDUCTANCE                (32)    /* Q-format of inductance */
#define MTR_Q_BEMF_CONST                (28)    /* Q-format of flux */
#define MTR_Q_INERTIA                   (25)    /* Q-format of inertia */
#define MTR_Q_D1_DIV_P2M                (37)    /* Q-format of 1st order fric-coef / (pole pairs * pole pairs * BEMF-const) */
#define MTR_Q_RECIV                     (28)    /* Q-format of reciprocal of voltage  */
#define MTR_Q_RECIM                     (30)    /* Q-format of reciprocal of flux */

#define MTR_Q_ACR_KP                    (32)    /* Q-format of PI proportional gain for ACR */
#define MTR_Q_ACR_KIDT                  (37)    /* Q-format of PI (integral gain) * (sampling period) for ACR */
#define MTR_Q_ASR_KP                    (29)    /* Q-format of PI proportional gain for ASR */
#define MTR_Q_ASR_KIDT                  (38)    /* Q-format of PI (integral gain) * (sampling period) for ASR */
#define MTR_Q_PLL_KP                    (33)    /* Q-format of PLL proportional gain */
#define MTR_Q_PLL_KIDT                  (41)    /* Q-format of PLL (integral gain) * (sampling period) */
#define MTR_Q_SPEED_LPF_CO              (31)    /* Q-format of speed LPF coefficient */
#define MTR_Q_CURRENT_LPF_CO            (31)    /* Q-format of current LPF coefficient */
#define MTR_Q_CURRENT_REPO_LPF_CO       (31)    /* Q-format of current recprocal LPF coefficient */

/* Danping control quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_DAMP_K                    (28)    /* Q-format of damping factor */
#define MTR_Q_DAMP_HPF_CO               (31)    /* Q-format of HPF for damping control */
#define MTR_Q_DAMP_SL_RATE              (33)    /* Q-format of Speed limit rate for damping control */
/* Open-loop to Closed-loop switch Control quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_PHERR_LPF_CO              (31)    /* Q-format of phase error LPF coefficient */
#define MTR_Q_OL2CL_K1                  (42)    /* Q-format of angle error-dependent portion of reference current */
/* Field-Weakening Control quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_FW_I                      (29)    /* Q-format of current for Field-Weakening Control */
#define MTR_Q_FW_I_SQ                   (27)    /* Q-format of current squared for Field-Weakening Control */
#define MTR_Q_KE_DIV_2LDQ               (26)    /* Q-format of Flux / (2*(q-axis inductance- d-axis inductance)) */
#define MTR_Q_FW_KP                     (27)    /* Q-format of PI proportional gain for Field-Weakening Control */
#define MTR_Q_FW_KIDT                   (43)    /* Q-format of PI (integral gain) * (sampling period) for Field-Weakening Control */
#define MTR_Q_FW_LPF_CO                 (31)    /* Q-format of speed error LPF coefficient for Field-Weakening Control */
/* Disturbance suppression quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_DO_LPF_CO                 (31)    /* Q-format of filter coefficients for disturbance suppression  */
#define MTR_Q_J_DIV_TC_P2M              (33)    /* Q-format of filter time constant for inertia-dividing disturbance suppression  */
/* voltage leading phase coefficient quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_V_PHASE_LEAD_COEF         (30)    /* Q-format of voltage leading phase coefficient */

/* Common conversion */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_DIV_DSP                   (32)    /* Q-format of DSP module Division calclation */
#define MTR_Q_SIN_COS_DSP               (28)    /* Q-format of DSP module sin cos */
#define MTR_Q_DUTY                      (12)    /* Q-format of PWM duty */
#define MTR_Q_PI_RUN_ACR_ERR            (25)    /* Q-format of ACR PI err  */
#define MTR_Q_PI_RUN_PLL_ERR            (19)    /* Q-format of PLL PI err  */
#define MTR_Q_PI_RUN_ACR_INTG           (12)    /* Q-format of ACR INTG  */
#define MTR_Q_PI_RUN_ASR_ERR            (22)    /* Q-format of ASR PI err */
#define MTR_Q_PI_RUN_ASR_INTG           (12)    /* Q-format of ASR INTG */

#if (MTR_Q_ANGLE != 28)
#error Angle Q must be a 28
#endif

#if (MTR_Q_VOLTAGE + MTR_Q_RECIV - MTR_Q_VMOD < 0)
#error RSFT_MOD must be a non-negative number
#endif

#endif /* R_MTR_SCALING_PARAMETER_H */


