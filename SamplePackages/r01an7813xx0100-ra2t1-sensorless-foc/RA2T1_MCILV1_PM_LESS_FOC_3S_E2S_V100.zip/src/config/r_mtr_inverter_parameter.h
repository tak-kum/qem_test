/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_inverter_parameter.h
* Description : Definitions of inverter board parameters
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_INVERTER_PARAMETER_H
#define R_MTR_INVERTER_PARAMETER_H

/***********************************************************************************************************************
* Target Inverter Define
***********************************************************************************************************************/
/* Target Inverter definitions */
/* Target Inverter name : MCK */
/* Created date : 2025/05/14 */
#ifdef IP_MCK
#define     IP_DEADTIME                     (2.0f)              /* Deadtime [us] */
#define     IP_CURRENT_RANGE                (16.5f)             /* For current scaling range[A]*/
#define     IP_VDC_RANGE                    (73.5f)             /* For Vdc scaling range[V]*/
#define     IP_INPUT_V                      (24.0f)             /* Input DC voltage [V] */
#define     IP_CURRENT_LIMIT                (21.4f)             /* Current limit[A] for the inverter board */
#define     IP_OVERVOLTAGE_LIMIT            (48.0f)             /* Over voltage limit [V] */
#define     IP_UNDERVOLTAGE_LIMIT           (8.0f)              /* Under voltage limit [V] */
#define     IP_PHASE_SHUNT_RESISTANCE       (0.010f)            /* Phase Shunt Resistance [ohm] */
#define     IP_PHASE_AMPLIFICATION_GAIN     (20.000f)           /* Phase Current Amplification Gain */
#define     IP_DC_SHUNT_RESISTANCE          (0.010f)            /* DC Link Shunt Resistance [ohm] */
#define     IP_DC_AMPLIFICATION_GAIN        (20.0f)             /* DC Link Current Amplification Gain */
#define     IP_BSC_CHARGE_CNT               (150)               /* charge time of boot strap capacitor */
#define     IP_CHARGE_CAP_WAIT_CNT          (300)               /* charge time of DC capacitor */

#endif
#endif /* R_MTR_INVERTER_PARAMETER_H */

