/**
 *  ステップのクリック時に展開/折り畳みを行う
 */
$(".list-parent .list-header").click(function (e) {
	$(".list-sub .list-header").css("transition", "all 0.1s ease");
	$(this).parent().toggleClass("close");
});

/** 外部HTML読み込み（不使用） **/
$(".load").each(function (i, el) {
	$(el).load("./load_file/" + $(el).attr("id") + ".html");
});

/**
 *  ステップのサブ項目クリック時にクリック箇所をアクティブにする＆コンテンツエリア表示切替
 */
$(".list-group .list-sub .list-header").click(function (e) {
	activateStep($(this));
	set_fixbox();
});

/**
 *  ISDQEKBN-497 縦長モード時のコンテンツエリアクリック時に、クリック箇所をアクティブにする
 */
$(".list-content").click(function (e) {
	activateStep($(this));
});

function activateStep(element) {
	// ステップの折り畳みアニメーション無し
	$(".list-sub .list-header").css("transition", "none;");
	// クリックした箇所をアクティブにする
	$(".active").removeClass("active");
	$(".selected").removeClass("selected");
	element.parents('.list-parent').addClass("active");
	element.parent().addClass("selected");
	// クリックした箇所に対応するナビゲーション部分をアクティブにする
	$("#nav_" + (element.parents('.list-parent').attr("id").split("_")[1])).addClass("active");
}

$(".nav-item").click(function (e) {
	let id = $(this).attr("id").split("_")[1];

	$(".list-sub .list-header").css("transition", "none;");

	$(".active").removeClass("active");
	$(".selected").removeClass("selected");

	$("#list_" + id).addClass("active");
	$("#list_" + id + " .list-sub").first().addClass("selected");
	$("#nav_" + id).addClass("active");
	set_fixbox();

	// ISDQEKBN-488 ワークフローを縦長スタイルにした際に、ナビゲーションバーから対象のステップに画面がジャンプするように改善
	var elm = $(".list-sub.selected").parents(".list-parent").get(0);
	var navHight = $(".nav").get(0).offsetHeight;
	var pos = elm.getBoundingClientRect().top;
	$(".list-group").get(0).scrollBy(0, pos - navHight);
});

let menucnt = $(".list-sub").length;

$(".btn_up").click(function (e) {
	let idx = $(".list-sub.selected").index(".list-sub");
	idx--;
	while (idx >= 0
		&& ($(".list-sub").eq(idx).hasClass("element-hidden")
			|| ($(".list-sub").eq(idx).parents(".list-parent").hasClass("element-hidden")))) {
		idx--;
	}
	if (idx >= 0) {
		$(".list-sub .list-header").css("transition", "none;");
		$(".selected").removeClass("selected");
		$(".active").removeClass("active");
		$(".list-sub").eq(idx).addClass("selected");
		$(".list-sub").eq(idx).parents('.list-parent').addClass("active");
		let id = $(".list-sub").eq(idx).parents('.list-parent').attr("id").split("_")[1];
		$("#nav_" + id).addClass("active");
		set_fixbox();
	}
});

$(".btn_down").click(function (e) {
	let idx = $(".list-sub.selected").index(".list-sub");
	idx++;
	while (idx < menucnt
		&& ($(".list-sub").eq(idx).hasClass("element-hidden")
			|| ($(".list-sub").eq(idx).parents(".list-parent").hasClass("element-hidden")))) {
		idx++;
	}
	if (idx < menucnt) {
		$(".list-sub .list-header").css("transition", "none;");
		$(".selected").removeClass("selected");
		$(".active").removeClass("active");
		$(".list-sub").eq(idx).addClass("selected");
		$(".list-sub").eq(idx).parents('.list-parent').addClass("active");
		let id = $(".list-sub").eq(idx).parents('.list-parent').attr("id").split("_")[1];
		$("#nav_" + id).addClass("active");
		set_fixbox();
	}

});


// ■準備エリア
// モータ用サンプルプログラムのダウンロードとインポート ボタン
$('#btn-sample-program').on('click', () => { window.location.href = 'qe-wfcmd-btn-import-sample-program-click'});
// 対象プロジェクトの選択 コンボボックス
$('#select-target-project').on('change', () => { window.location.href = 'qe-wfcmd-select-target-project-change'});
// モータ制御ソフトウェアの設定を開く ボタン
$('#btn-open-configuration').on('click', () => { window.location.href = 'qe-wfcmd-btn-open-configuration-click'});
// Renesas Motor Workbenchのダウンロードとインストール ボタン
$('#btn-install-rmw').on('click', () => { window.location.href = 'qe-wfcmd-btn-install-rmw-click'});
// QE for Motor設定を開く ボタン
$('#btn-preferences-link').on('click', () => { window.location.href = 'qe-wfcmd-btn-preferences-link-click'});

// ■チューニングエリア
// Download tuning program from renesas server dialog
$('#link-refresh-tuning-program').on('click', () => { window.location.href = 'qe-wfcmd-link-refresh-tuning-program-click' });
// チューニングプログラムの選択 ボタン
$('#select-tuning-motor').on('change', () => { window.location.href = 'qe-wfcmd-select-tuning-motor-change' });
$('#btn-select-tuning-program').on('click', () => { window.location.href = 'qe-wfcmd-btn-select-tuning-program-click'});
// 書き込み設定 リンク
$('#link-download-settings-tuner').on('click', () => { window.location.href = 'qe-wfcmd-link-download-settings-tuner-click' });
// チューニングプログラムのダウンロード ボタン
$('#btn-download-tuning-program').on('click', () => { window.location.href = 'qe-wfcmd-btn-download-tuning-program-click' });
// Tuner設定ファイル コンボボックス
$('#select-tuning-config-file').on('change', () => { window.location.href = 'qe-wfcmd-select-tuning-config-file-change' });
// 起動設定 リンク
$('#link-launch-settings-tuner').on('click', () => { window.location.href = 'qe-wfcmd-link-launch-settings-tuner-click' });
// RMW tunerを起動 ボタン
$('#btn-launch-tuner').on('click', () => { window.location.href = 'qe-wfcmd-btn-launch-tuner-click' });

// ■アナライズエリア
// プログラムをビルド ボタン
$('#btn-build-application-program').on('click', () => { window.location.href = 'qe-wfcmd-btn-build-application-program-click'});
// 書き込み設定 リンク
$('#link-download-settings-analyzer').on('click', () => { window.location.href = 'qe-wfcmd-link-download-settings-analyzer-click' });
// プログラムをダウンロード ボタン
$('#btn-download-application-program').on('click', () => { window.location.href = 'qe-wfcmd-btn-download-application-program-click' });
// Generate Variable Meaning File
$('#btn-generate-var').on('click', () => { window.location.href = 'qe-wfcmd-btn-generate-var-click' });
$('#checkbox-loadVar').on('click', () => { window.location.href = 'qe-wfcmd-checkbox-loadVar-click' });
// Analyzer設定ファイル コンボボックス
$('#select-analizer-config-file').on('change', () => { window.location.href = 'qe-wfcmd-select-analizer-config-file-change' });
// Offline mode チェックボックス
$('#checkbox-offline').on('click', () => { window.location.href = 'qe-wfcmd-checkbox-offline-click' });
// 起動設定 リンク
$('#link-launch-settings-analyzer').on('click', () => { window.location.href = 'qe-wfcmd-link-launch-settings-analyzer-click' });
// RMW analyzerを起動 ボタン
$('#btn-launch-analyzer').on('click', () => { window.location.href = 'qe-wfcmd-btn-launch-analyzer-click' });

// analyzer debug hardware connection check
$('#checkbox-analyzer-debug-check-setting').on('click', function () {
	let chkDebug = this;
	$("input[name='checkbox-debug-check']").each(function () {
		this.checked = chkDebug.checked;
	});
	window.location.href = 'qe-wfcmd-checkbox-analyzer-debug-check-setting-click'
});

// tuner debug hardware connection check
$('#checkbox-tuner-debug-check-setting').on('click', function () {
	let chkDebug = this;
	$("input[name='checkbox-debug-check']").each(function () {
		this.checked = chkDebug.checked;
	});
	window.location.href = 'qe-wfcmd-checkbox-tuner-debug-check-setting-click'
});

function set_fixbox() {
	let id = $(".active").attr("id").split("_")[1];
	$(".selected").find(".list-content").append($(".fixed-box"));
	$(".active").removeClass("close");
	set_boxsize();
	
	window.location.href = "qe-wfcmd-set-fixbox";
}

function set_boxsize() {
	if ($(window).width() > 540) {
		let h = $(".selected").find(".list-content").height();
		if ($(".selected").find(".box").height()<h-306) {
			$(".selected").find(".box").css("height",h-306+"px");
		}
	} else {
		$(".selected").find(".box").css("height","");
	}
}
	
/**
 * ISDQEKBN-692 ワークフローが正しく動作しない制限を解除
 * 	DOMContentLoaded になる前に「window.location.href = "qe-wfcmd-xxx"」が実行されるとロードが中断されて 
 * 	Java の notifyLoadCompleted() が呼ばれなくなるので、DOMContentLoaded になった後に実行されるようにする。
 */
$(function() {
	set_fixbox();
});

// Initialize Swiper
var swiper = new Swiper(".mySwiper", {
	slidesPerView: 1,
	spaceBetween: 30,
	slidesPerGroup: 1,
	loop: true,
	loopFillGroupWithBlank: true,
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
});

//// モーダル表示対象のイベントハンドラを更新。ガイドを変更するたびに呼ばれる。
$(updateModal());

function updateModal() {
  var currentIndex = 0;
  var totalImages = $('.thumbnail').length;

  // サムネイル画像をクリックした時の処理
  $('.thumbnail').click(function() {
    currentIndex = $('.thumbnail').index($(this));
    showImageModal();
    $('#modal').fadeIn();
  });
  
    // 閉じるボタンをクリックした時の処理
  $('#closeButton').click(function() {
    closeModal();
  });

  // モーダルのdivをクリックした時の処理
  $('#modal').click(function(event) {
    if (event.target === this) {
      closeModal();
    }
  });

  // 戻るボタンをクリックした時の処理
  $('#prevButton').click(function() {
    currentIndex = (currentIndex - 1 + totalImages) % totalImages;
    showImageModal();
  });

  // 次へボタンをクリックした時の処理
  $('#nextButton').click(function() {
    currentIndex = (currentIndex + 1) % totalImages;
    showImageModal();
  });

  // モーダルの表示を更新する関数
  function showImageModal() {
    var imageUrl = $('.thumbnail').eq(currentIndex).attr('src');
    $('#modalImage').attr('src', imageUrl);

    // 次へボタンの表示/非表示を切り替える
    if (currentIndex === totalImages - 1) {
      $('#nextButton').hide();
    } else {
      $('#nextButton').show();
    }

    // 戻るボタンの表示/非表示を切り替える
    if (currentIndex === 0) {
      $('#prevButton').hide();
    } else {
      $('#prevButton').show();
    }
  }

  // モーダルを閉じる関数
  function closeModal() {
    $('#modal').fadeOut();
  }
}

function BoardImage(key, imgCpu, imgInverter) {
	this.key = key;
	this.imgCpu = imgCpu;
	this.imgInverter = imgInverter;
}

let arrayBoardImageEn = [];
let arrayBoardImageJp = [];

$(function () {
	arrayBoardImageEn.push(new BoardImage('RA4T1_MCILV1_SPM_', 'images2/mck_rarx_type2_cpu.png', 'images2/mck_rarx_type2_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RA6T1_ESB_SPM_', 'images2/mces_cpu.png', 'images2/mces_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RA6T2_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu.png', 'images2/mck_rarx_type1_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RA6T3_MCILV1_SPM_', 'images2/mck_rarx_type2_cpu.png', 'images2/mck_rarx_type2_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RA8T1_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu.png', 'images2/mck_rarx_type1_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RX26T_MCBA_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu.png', 'images2/mck_rarx_type1_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RX26T_MCBC_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu.png', 'images2/mck_rarx_type1_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RL78G1F_MCEK_', 'images2/mcek_rl78_cpu.png', 'images2/mcek_rl78_inv.png'));
	arrayBoardImageEn.push(new BoardImage('RL78G24_MCEK_', 'images2/mcek_rl78_cpu.png', 'images2/mcek_rl78_inv.png'));
	arrayBoardImageEn.push(new BoardImage('OTHER', 'images2/board_example_cpu.png', 'images2/board_example_inv.png'));

	arrayBoardImageJp.push(new BoardImage('RA4T1_MCILV1_SPM_', 'images2/mck_rarx_type2_cpu_jp.png', 'images2/mck_rarx_type2_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RA6T1_ESB_SPM_', 'images2/mces_cpu_jp.png', 'images2/mces_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RA6T2_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu_jp.png', 'images2/mck_rarx_type1_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RA6T3_MCILV1_SPM_', 'images2/mck_rarx_type2_cpu_jp.png', 'images2/mck_rarx_type2_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RA8T1_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu_jp.png', 'images2/mck_rarx_type1_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RX26T_MCBA_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu_jp.png', 'images2/mck_rarx_type1_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RX26T_MCBC_MCILV1_SPM_', 'images2/mck_rarx_type1_cpu_jp.png', 'images2/mck_rarx_type1_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RL78G1F_MCEK_', 'images2/mcek_rl78_cpu_jp.png', 'images2/mcek_rl78_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('RL78G24_MCEK_', 'images2/mcek_rl78_cpu_jp.png', 'images2/mcek_rl78_inv_jp.png'));
	arrayBoardImageJp.push(new BoardImage('OTHER', 'images2/board_example_cpu_jp.png', 'images2/board_example_inv_jp.png'));
});

function updateBoardPic(projectName, language) {
	let arrayImage = null;
	if (language === 'jp') {
		arrayImage = arrayBoardImageJp;
	} else {
		arrayImage = arrayBoardImageEn;
	}
	let foundObj = arrayImage.find(obj => {
		return projectName.startsWith(obj.key);
	});
	if (foundObj == null) {
		foundObj = arrayImage.find(obj => {
			return obj.key === 'OTHER';
		});
	}
	$('.img-cpu-board').attr('src', foundObj.imgCpu);
	$('.img-inverter-board').attr('src', foundObj.imgInverter);
}

//// ページトップヘスクロール
$(document).ready(function() {
  $('.list-content').scroll(function() {
    var scrollPosition = $(this).scrollTop(); // myDivのスクロール位置を取得
    var divHeight = $(this).height(); // myDivの高さを取得
    var contentHeight = $(this).prop('scrollHeight'); // myDivのコンテンツの高さを取得
    var scrollPercentage = (scrollPosition / (contentHeight - divHeight)) * 100; // スクロール位置の割合を計算
    
    if (scrollPercentage > 0) {
      $('#scrollToTopBtn').fadeIn(); // ボタンを表示
    } else {
      $('#scrollToTopBtn').fadeOut(); // ボタンを非表示
    }
  });

  $('#scrollToTopBtn').click(function() {
    $('.list-content').animate({ scrollTop: 0 }, 500); // myDivのスクロール位置を0にするアニメーション
  });
});

function reloadScript() {
	location.reload();
}

const modal_ol = document.getElementById('modalOverlay');
const svgContainer = document.getElementById('svgContainer');
const closeBtn = document.getElementById('closeBtn');

document.querySelectorAll('.modal-trigger').forEach(trigger => {
    trigger.addEventListener('click', () => {
    modal_ol.style.display = 'flex';
  });
});

closeBtn.addEventListener('click', () => {
  modal_ol.style.display = 'none';
});

modal_ol.addEventListener('click', (e) => {
  if (e.target === modal_ol) {
    modal_ol.style.display = 'none';
  }
});
