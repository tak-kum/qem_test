/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_motor_parameter.h
* Description : Definition of the target motor parameters
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_MOTOR_PARAMETER_H
#define R_MTR_MOTOR_PARAMETER_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* target motor parameter definitions */
#ifdef MP_TG55L
#define     MP_POLE_PAIRS            (2)            /* Number of pole pairs */
#define     MP_RESISTANCE            (9.125f)       /* Resistance [ohm] */
#define     MP_D_INDUCTANCE          (0.003844f)    /* D-axis inductance [H] */
#define     MP_Q_INDUCTANCE          (0.004315f)    /* Q-axis inductance [H] */
#define     MP_MAGNETIC_FLUX         (0.02144f)     /* Induced voltage constant [V s/rad] */
#define     MP_ROTOR_INERTIA         (0.000002050f) /* Rotor inertia [kgm^2] */
#define     MP_NOMINAL_CURRENT_RMS   (0.42f)        /* Nominal current [Arms] */
#endif /* Tsukasa TG55L */

#endif /* R_MTR_MOTOR_PARAMETER_H */
