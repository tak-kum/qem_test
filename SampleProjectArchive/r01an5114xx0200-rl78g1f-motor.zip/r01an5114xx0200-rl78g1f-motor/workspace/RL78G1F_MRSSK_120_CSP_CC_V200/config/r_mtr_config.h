/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_mtr_config.h
* Description  : Compile-time configurations
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_CONFIG_H
#define R_MTR_CONFIG_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/*
 * Hardware system configurations
 */
#define RL78_G1F_MRSSK  /* CPU board : RL78_G1F MRSSK */
#define IP_MRSSK        /* Inverter: MRSSK */
#define MP_TG55L        /* Tsukasa TG55L */
#define CP_TG55L        /* Tsukasa TG55L */

/* Defines the UI used as default UI (BOARD_UI/ICS_UI)*/
#define  ICS_UI                     (0)                /* Renesas Motor Workbench */
#define  BOARD_UI                   (1)                /* RSSK board */
#define  MTRCONF_DEFAULT_UI         (ICS_UI)

/* Defines the PWM chopping pattern (NON_COMPLEMENTARY/COMPLEMENTARY) */
#define NON_COMPLEMENTARY           (0)                /* non-complementary pwm output */
#define COMPLEMENTARY               (1)                /* complementary pwm output */
#define MTRCONF_PWM_MODE            (COMPLEMENTARY)

/* Defines the sensor used for control (HALL/LESS) */
#define HALL                        (0)                /* Hall effect sensor control */
#define LESS                        (1)                /* sensorless control */
#define MTRCONF_SENSOR_MODE         (LESS)

/*
 * Hardware system configurations file include
 */
#include "r_mtr_motor_parameter.h"
#include "r_mtr_control_parameter.h"
#include "r_mtr_inverter_parameter.h"

#endif /* R_MTR_CONFIG_H */
