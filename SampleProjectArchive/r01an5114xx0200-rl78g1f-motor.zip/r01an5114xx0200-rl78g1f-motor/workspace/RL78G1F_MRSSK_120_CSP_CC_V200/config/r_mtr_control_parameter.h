/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_control_parameter.h
* Description : Definitions of default control parameters
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_CONTROL_PARAMETER_H
#define R_MTR_CONTROL_PARAMETER_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* terget control parameter definitions */
#ifdef CP_TG55L
#define  CP_MAX_SPEED_RPM        (3200)           /* max speed [rpm] */
#define  CP_LIMIT_SPEED_RPM      (3900)           /* over speed limit [rpm] */
#define  CP_RAMP_LIMIT_V         (0.29f)          /* limit of rate of voltage change [V/ms] */

#define  CP_SPEED_PI_KP          (0.027410176f)   /* proportional gain for speed PI control [V s/rad] */
#define  CP_SPEED_PI_KIDT        (0.000861116f)   /* integral gain for speed PI control [V s/rad] */

#if (MTRCONF_SENSOR_MODE == HALL)
    #define  CP_MIN_SPEED_RPM            (530)    /* minimum speed [rpm] */
    #define  CP_RAMP_LIMIT_SPEED_RPM     (120)    /* limit u of acceleration [rpm/ms] */
    #define  CP_START_REF_V              (3.6f)   /* start reference voltage [V] */
    #define  CP_HALL2OL_REV_SPEED_RPM    (530)    /* hall effect sensor control to open-loop change speed [rpm] */

#elif (MTRCONF_SENSOR_MODE == LESS)
    #define  CP_MIN_SPEED_RPM            (265)    /* minimum speed [rpm] */
    #define  CP_RAMP_LIMIT_SPEED_RPM     (6)      /* limit of acceleration [rpm/ms] */
    #define  CP_DRAW_IN_REF_V            (20.0f)  /* voltage reference at draw-in [V] */
    #define  CP_OL_REF_V                 (4.3f)   /* open-loop start reference voltage [V] */
    #define  CP_OL2LESS_SPEED_RPM        (530)    /* open-loop to sensorless control change speed [rpm] */
    #define  CP_OL2LESS_SPEED_RAMP_RPM   (1)      /* acceleration at translating to PI control [rpm/ms] */
#endif

#endif /* TSUKASA TG55L */

#endif /* R_MTR_CONTROL_PARAMETER_H */
