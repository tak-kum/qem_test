/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_ctrl_rl78g1f.c
* Description : The processing of a H/W control layer(MCU dependence)
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_ctrl_rl78g1f.h"

/***********************************************************************************************************************
Private function dinifinitions
***********************************************************************************************************************/
static void mtr_init_unused_pins(void);          /* initialize unused pins */
static void mtr_init_ui(void);                   /* initialize peripheral function for user interface */
static uint16_t mtr_init_clock(void);            /* initialize clock */
static void mtr_init_tau(void);                  /* initialize TAU */
static void mtr_init_trd(void);                  /* initialize TRD */
static void mtr_init_intp(void);                 /* initialize INTP */
static void mtr_init_ad_converter(void);         /* initialize A/D converter */

/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MTR_InitHardware
* Description   : Initialize peripheral functions
* Arguments     : None
* Return Value  : Error status for initialization
***********************************************************************************************************************/
uint16_t R_MTR_InitHardware(void)
{
    uint16_t u2_init_hw_error;

    /*================================*/
    /*     initialize unused pins     */
    /*================================*/
    mtr_init_unused_pins();

    /*=======================*/
    /*     initialize UI     */
    /*========= =============*/
    mtr_init_ui();

    /*==========================*/
    /*     initialize clock     */
    /*==========================*/
    u2_init_hw_error = mtr_init_clock();

    /*========================*/
    /*     initialize TAU     */
    /*========================*/
    mtr_init_tau();

    /*========================*/
    /*    initialize TRD      */
    /*========================*/
    mtr_init_trd();

    /*=======================================*/
    /*     initialize external interrupt     */
    /*=======================================*/
    mtr_init_intp();

    /*==================================*/
    /*     initialize A/D converter     */
    /*==================================*/
    mtr_init_ad_converter();

    return (u2_init_hw_error);
} /* End of function R_MTR_InitHardware */

/***********************************************************************************************************************
* Function Name : mtr_init_unused_pins
* Description   : Initialize unused pins
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_unused_pins(void)
{
    /* initialize unused pins as output mode */
#if (MTRCONF_SENSOR_MODE == HALL)
    PM0 &= 0xF0;               /* P00, P01, P02, P03 */
    PM2 &= 0x50;               /* P20, P21, P22, P23, P25, P27 */
    PM5 &= 0xDC;               /* P50, P51, P55 */
#elif (MTRCONF_SENSOR_MODE == LESS)
    PM0 &= 0xF8;               /* P00, P01, P02 */
    PM2 &= 0x53;               /* P22, P23, P25, P27 */
    PM5 &= 0xC0;               /* P50, P51, P52, P53, P54, P55 */
#endif

    PM1 &= 0x3F;               /* P16, P17 */
    PM3 &= 0xFC;               /* P30, P31 */
    PM4 &= 0xF0;               /* P40, P41, P42, P43 */
    PM6 &= 0xF0;               /* P60, P61, P62, P63 */
    PM7 &= 0xC0;               /* P70, P71, P72, P73, P74, P75 */
    PM12 &= 0xFE;              /* P120 */
    PM14 &= 0x3C;              /* P146, P147 */

} /* End of function mtr_init_unused_pins */

/***********************************************************************************************************************
* Function Name : mtr_init_ui
* Description   : Initialize user interface of RSSK
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_ui(void)
{
    /**************** SW1,2 ****************/
    PM0_bit.no5  = 1;                           /* input mode for SW1 */
    PM0_bit.no6  = 1;                           /* input mode for SW2 */

    /*************** LED1,2,3 **************/
    P14_bit.no1  = 1;                           /* LED1 off */
    P14_bit.no0  = 1;                           /* LED2 off */
    P0_bit.no4   = 1;                           /* LED3 off */
    PM14_bit.no1 = 0;                           /* output mode for LED1 */
    PM14_bit.no0 = 0;                           /* output mode for LED2 */
    PM0_bit.no4  = 0;                           /* output mode for LED3 */

    /***************** VR1 *****************/
    PM2_bit.no6  = 1;                           /* input mode for VR1 */

    /***************** TxD2 ****************/
    PM7_bit.no7 = 0;                            /* output mode for TxD2 */

} /* End of function mtr_init_ui */

/***********************************************************************************************************************
* Function Name : mtr_init_clock
* Description   : Initialize clock
* Arguments     : None
* Return Value  : Error status
***********************************************************************************************************************/
static uint16_t mtr_init_clock(void)
{
    uint16_t i;
    uint16_t u2_change_clk_error;
    uint16_t u2_change_clk_cnt;

     u2_change_clk_error = ERROR_NONE;

    /***  initialize clock   ***/
    CMC = 0x00;                 /* clock operation mode control register */
    CKC = 0x00;                 /* system clock control register */ /* Use Internal High-speed OSC as main clock */
    CSC = 0xC0;                 /* clock operation status control register */ /* Xtal ports are set to input ports */

    /***  initialize peripheral ***/
    /* PER0 . peripheral enable register 0 ***********************************
    b7 RTCEN    - 0
    b6 IRDAEN   - 0
    b5 ADCEN    - 1
    b4 IICA0EN  - 0
    b3 SAU1EN   - 1
    b2 SAU0EN   - 1
    b1          - set to 0(64pin)
    b0 TAU0EN   - 1
    *************************************************************************/
    PER0 = 0x2D;

    /* PER1 . peripheral enable register 1 ***********************************
    b7 DACEN    - 0
    b6 TRGEN    - 0
    b5 PGACMPEN - 0
    b4 TRD0EN   - 1
    b3 DTCEN    - 0
    b2 PWMOPEN  - 0
    b1 TRXEN    - 0
    b0 TRJEN    - 0
    **************************************************************************/
    PER1 = 0x10;

    OSMC = 0x00;                /* subsystem clock no supply */

    while (MTR_SET == MCS)
    {
        for (i = 0; i < 2; i++)
        {
            NOP();
        }
        u2_change_clk_cnt++;

        /*  if about 200us*10 times passes, error is set*/
        if (u2_change_clk_cnt > 10)
        {
            u2_change_clk_error = ERROR_CHANGE_CLK_TIMEOUT;
            break;
        }
    }

    return (u2_change_clk_error);
} /* End of function mtr_init_clock */

/***********************************************************************************************************************
* Function Name : mtr_init_tau
* Description   : Initialize TAU
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_tau(void)
{
    /*************** basic configuration ***************/
    TPS0 = 0x0000;              /* CK00 = 32MHz , CK01 =  32MHz */
                                /* CK02 = 16MHz , CK03 = 125kHz */
    /* once all interrupt services are disabled. */
    TMMK00 = 1;                 /* INTTM00(trigger:end of timer channel 0 count) interrupt servicing disabled */
    TMMK01 = 1;                 /* INTTM01(trigger:end of timer channel 1 count) interrupt servicing disabled */
    TMMK02 = 1;                 /* INTTM02(trigger:end of timer channel 2 count) interrupt servicing disabled */
    TMMK03 = 1;                 /* INTTM03(trigger:end of timer channel 3 count) interrupt servicing disabled */

    /* TS0 . timer channel start register 0 ********************************************************************
    b15:b12         - reserved set to 0
    b11 TSH03       - trigger to enable operation of the higher 8bit timer when channel 3 is in the 8bit timer mode
                    - no trigger operation
    b10             - reserved set to 0
    b9 TSH01        - trigger to enable operation of the higher 8bit timer when channel 1 is in the 8bit timer mode
                    - no trigger operation
    b8:b4           - reserved set to 0
    b3:b0 TS03:TS00 - operation enable trigger of channel 0 to 3
                    - no trigger operation
    ***********************************************************************************************************/
    TS0 = 0x0000;

    /*************** configure TAU0 ***************/
    /* TMR00 . timer mode register 00 **************************************************************************
    b15:b14 CKS001:CKS000 - selection of operation clock (fMCK) of channel 0 - operation clock CK00(32MHz)
    b13                   - reserved set to 0
    b12 CCS00             - selection of count clock (fTCLK) of channel 0
                          - operation clock (fMCK) specified by the CKS000 and CKS001 bits
    b11                   - reserved set to 0
    b10:b8 STS002:STS000  - getting of start trigger or capture trigger of channel 0
                          - only software trigger start is valid
    b7:b6 CIS001:CIS000   - selection of TI00 pin input valid edge - falling edge
    b5:b4                 - reserved set to 0
    b3:b0 MD003:MD000     - operation mode of channel 0 - interval timer mode
    ***********************************************************************************************************/
    TMR00 = 0x0000;

    /* TDR00 . timer data register 00 **************************************************************************
    b15:b0 - set count down start value - create 1ms cycle interrupt
    set value = (frequency of TAU0 count clock) * (interrupt period) = 32MHz * 1ms - 1 = 31999
    ***********************************************************************************************************/
    TDR00 = (MTR_TAU0_FREQ * 1000) - 1;

    TMPR100 = 1;                /* INTTM00(trigger:end of timer channel 0 count) priority level is 3 */
    TMPR000 = 1;
    TMIF00 = 0;                 /* Clear interrupt flag */
    TMMK00 = 0;                 /* INTTM00 interruption enabled */

    TS0 |= 0x01;                /* start TAU0 */

    /*************** configure TAU1 ***************/
    /* TMR01 . timer mode register 01 **************************************************************************
    b15:b14 CKS011:CKS010 - selection of operation clock (fMCK) of channel 3 - operation clock CK03(125kHz)
    b13                   - reserved set to 0
    b12 CCS01             - selection of count clock (fTCLK) of channel 1
                          - operation clock (fMCK) specified by the CKS010 and CKS011 bits
    b11 SPLIT01           - operation as 16-bit timer
    b10:b8 STS012:STS010  - getting of start trigger or capture trigger of channel 1
                          - only software trigger start is valid
    b7:b6 CIS011:CIS010   - selection of TI00 pin input valid edge - falling edge
    b5:b4                 - reserved set to 0
    b3:b0 MD013:MD010     - operation mode of channel 1 - capture mode
    ***********************************************************************************************************/
    TMR01 = 0xC004;

    /* TDR01 . timer data register 01 **************************************************************************
    b15:b0 - set count down start value - TAU1 is free run timer
    ***********************************************************************************************************/
    TDR01 = 0xFFFF;

    TMMK01 = 1;                 /* INTTM01(trigger:end of timer channel 1 count) interruption disabled */

    TS0 |= 0x002;                /* start TAU1 */

#if (MTRCONF_SENSOR_MODE == LESS)
    /*************** configure TAU3 ***************/
    /* TMR03 . timer mode register 03 **************************************************************************
    b15:b14 CKS031:CKS030 - selection of operation clock (fMCK) of channel 3 - operation clock CK03(125kHz)
    b13                   - reserved set to 0
    b12 CCS03             - selection of count clock (fTCLK) of channel 3
                          - operation clock (fMCK) specified by the CKS030 and CKS031 bits
    b11 SPLIT03           - operation as 16-bit timer
    b10:b8 STS032:STS030  - getting of start trigger or capture trigger of channel 3
                          - only software trigger start is valid
    b7:b6 CIS031:CIS030   - selection of TI00 pin input valid edge - falling edge
    b5:b4                 - reserved set to 0
    b3:b0 MD033:MD030     - operation mode of channel 3 - one-count mode
    ***********************************************************************************************************/
    TMR03 = 0xC008;

    /* TDR03 . timer data register 03 **************************************************************************
    b15:b0 - set count down start value - TAU3 is delay timer
    ***********************************************************************************************************/
    TDR03 = 0;

    TMPR103 = 0;               /* INTTM03(trigger:end of timer channel 0 count) priority level is 1 */
    TMPR003 = 1;
    TMIF03 = 0;                /* Clear interrupt flag */
    TMMK03 = 0;                /* INTTM03(trigger:end of timer channel 1 count) interruption enabled */    

    TS0 |= 0x0008;             /* start TAU3 */
#endif
} /* End of function mtr_init_tau */

/***********************************************************************************************************************
* Function Name : mtr_init_trd
* Description   : Initialize TRD
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_trd(void)
{
    /* Setup PIN function */
    /* initialize I/O port *************************************************************************************
    P10 - Wn   P11 - Vn   P12 - Wp
    P13 - Vp   P14 - Un   P15 - Up
    ***********************************************************************************************************/
    PMC1_bit.no0 = 0;           /* select digital */
    PMC1_bit.no1 = 0;           /* select digital */
    PMC1_bit.no2 = 0;           /* select digital */
    PMC1_bit.no3 = 0;           /* select digital */
    PMC1_bit.no4 = 0;           /* select digital */
    PMC1_bit.no5 = 0;           /* select digital */
    P1_bit.no0 = 0;             /* Wn = "Low" */
    P1_bit.no1 = 0;             /* Vn = "Low" */
    P1_bit.no2 = 0;             /* Wp = "Low" */
    P1_bit.no3 = 0;             /* Vp = "Low" */
    P1_bit.no4 = 0;             /* Un = "Low" */
    P1_bit.no5 = 0;             /* Up = "Low" */
    PM1_bit.no0 = 0;            /* output mode for Wn */
    PM1_bit.no1 = 0;            /* output mode for Vn */
    PM1_bit.no2 = 0;            /* output mode for Wp */
    PM1_bit.no3 = 0;            /* output mode for Vp */
    PM1_bit.no4 = 0;            /* output mode for Un */
    PM1_bit.no5 = 0;            /* output mode for Up */

    /*************** configure TRD ***************/
    /* TRDFCR . timer RD function control register *************************************************************
    b7 PWM3         - PWM3 mode select - invalid at complimentary PWM mode
    b6 STCLK        - external clock input select - external clock input disabled
    b5:b4           - reserved set to 0
    b3 OLS1         - counter phase output level select - low initial output and high active level
    b2 OLS0         - phase output level select - low initial output and high active level
    b1:b0 CMD1:CMD0 - combination mode select
                    - reload from buffer to general register at the compare match between TRD0 & TRDGRA0
    ***********************************************************************************************************/
    TRDFCR = 0x0F;

    /* TRDMR . timer RD mode register **************************************************************************
    b7 BFD1 - TRDGRD1 register function select - buffer register of TRDGRB1
    b6 BFC1 - TRDGRC1 register function select - buffer register of TRDGRA1
    b5 BFD0 - TRDGRD0 register function select - buffer register of TRDGRB0
    b4 BFC0 - TRDGRC0 register function select - general register
    b3:b1   - nothing is assigned
    b0 SYNC - timer RD synchronous - TRD0 and TRD1 operate independently
    ***********************************************************************************************************/
    TRDMR = 0xE0;

    /* TRDOER1 . timer RD output master enable register 1*******************************************************
    b7 ED1 - TRDIOD1 output disable - output disabled (TRDIOD1 pin functions as an I/O port)
    b6 EC1 - TRDIOC1 output disable - output disabled (TRDIOC1 pin functions as an I/O port)
    b5 EB1 - TRDIOB1 output disable - output disabled (TRDIOB1 pin functions as an I/O port)
    b4 EA1 - TRDIOA1 output disable - output disabled (TRDIOA1 pin functions as an I/O port)
    b3 ED0 - TRDIOD0 output disable - output disabled (TRDIOD0 pin functions as an I/O port)
    b2 EC0 - TRDIOC0 output disable - output disabled (TRDIOC0 pin functions as an I/O port)
    b1 EB0 - TRDIOB0 output disable - output disabled (TRDIOB0 pin functions as an I/O port)
    b0 EA0 - TRDIOA0 output disable - output disabled (TRDIOA0 pin functions as an I/O port)
    ************************************************************************************************************/
    TRDOER1 = 0xFF;

    /* TRDOER2 . timer RD output master enable register 2 ******************************************************
    b7 PTO   - INTP0 of pulse output forced cutoff signal input disabled - pulse output forced cutoff input disabled
    b6:b1    - nothing is assigned - the write value must be 0
    b0 SHUTS - forced cutoff flag - not forcibly cut off
    ***********************************************************************************************************/
    TRDOER2 = 0x00;

    /* TRDDF0 . timer RD digital filter function select register 0 *********************************************
    b7:b6 DFCK1:DFCK0 - TRDIOA0 pin pulse forced cutoff control - forced cutoff disabled
    b5:b4 PENB1:PENB0 - TRDIOB0 pin pulse forced cutoff control - high-impedance output
    b3:b2 DFD:DFC     - TRDIOC0 pin pulse forced cutoff control - forced cutoff disabled
    b1:b0 DFB DFA     - TRDIOD0 pin pulse forced cutoff control - high-impedance output
    ***********************************************************************************************************/
    TRDDF0 = 0x11;

    /* TRDDF1 . timer RD digital filter function select register 1 *********************************************
    b7:b6 DFCK1:DFCK0 - TRDIOA1 pin pulse forced cutoff control - high-impedance output
    b5:b4 PENB1:PENB0 - TRDIOB1 pin pulse forced cutoff control - high-impedance output
    b3:b2 DFD:DFC     - TRDIOC1 pin pulse forced cutoff control - high-impedance output
    b1:b0 DFB DFA     - TRDIOD1 pin pulse forced cutoff control - high-impedance output
    ***********************************************************************************************************/
    TRDDF1 = 0x55;

    /* TRDIER0 . timer RD interrupt enable register 0/1 ********************************************************
    b7:b5    - nothing is assigned - the write value must be 0
    b4 OVIE  - overflow/underflow interrupt enable - interrupt (OVI) by bits OVF and UDF disabled
    b3 IMIED0 - input capture/compare match interrupt enable D - interrupt (IMID0) by the IMFD0 bit is disabled
    b2 IMIEC0 - input capture/compare match interrupt enable C - interrupt (IMIC0) by the IMFC0 bit is disabled
    b1 IMIEB0 - input capture/compare match interrupt enable B - interrupt (IMIB0) by the IMFB0 bit is disabled
    b0 IMIEA0 - input capture/compare match interrupt enable A - interrupt (IMIA0) by the IMFA0 bit is enabled
    ***********************************************************************************************************/
    TRDIER0 = 0x01;

    /* TRDIER1 . timer RD interrupt enable register 0/1 ********************************************************
    b7:b5    - nothing is assigned - the write value must be 0
    b4 OVIE  - overflow/underflow interrupt enable - interrupt (OVI) by bits OVF and UDF disabled
    b3 IMIED1 - input capture/compare match interrupt enable D - interrupt (IMID1) by the IMFD1 bit is disabled
    b2 IMIEC1 - input capture/compare match interrupt enable C - interrupt (IMIC1) by the IMFC1 bit is disabled
    b1 IMIEB1 - input capture/compare match interrupt enable B - interrupt (IMIB1) by the IMFB1 bit is disabled
    b0 IMIEA1 - input capture/compare match interrupt enable A - interrupt (IMIA1) by the IMFA1 bit is disabled
    ***********************************************************************************************************/
    TRDIER1 = 0x00;

    /* TRDCR0 . timer RD control register 0 ********************************************************************
    b7:b5 CCLR2:CCLR0 - TRD0 counter clear select
                      - TRD0 register is cleared at compare match with TRDGRA0 register
    b4:b3 CKEG1:CKEG0 - external clock edge select - count at the rising edge
    b2:b0 TCK2:TCK0   - count source select - fHOCO
    ***********************************************************************************************************/
    TRDCR0 = 0x00;

    /* TRDCR1 . timer RD control register 1 ********************************************************************
    b7:b5 CCLR2:CCLR0 - TRD1 counter clear select
                      - TRD1 register is cleared at compare match with TRDGRA1 register
    b4:b3 CKEG1:CKEG0 - external clock edge select - count at the rising edge
    b2:b0 TCK2:TCK0   - count source select - fHOCO
    ***********************************************************************************************************/
    TRDCR1 = 0x00;

    /* TRD0 . timer RD counter 0 *******************************************************************************
    b15:b0 - counter value - set counts to deadtime
    ***********************************************************************************************************/
#if (MTRCONF_PWM_MODE == NON_COMPLEMENTARY)
    TRD0 = 0;
#elif (MTRCONF_PWM_MODE == COMPLEMENTARY) 
    TRD0 = (uint16_t)MTR_DEADTIME_SET;
#endif

    /* TRD1 . timer RD counter 1 *******************************************************************************
    b15:b0 - counter value - set counts to 0
    ***********************************************************************************************************/
    TRD1 = 0;

    /* TRDGRA0 . timer RD general registers 0, 1 **************************************************************
    b15:b0 - set the PWM period - PWM period is 50us
    ***********************************************************************************************************/
    TRDGRA0 = (uint16_t)MTR_CARRIER_SET;
    TRDGRD0 = (uint16_t)MTR_HALF_CARRIER_SET;
    TRDGRB0 = (uint16_t)MTR_HALF_CARRIER_SET;
    TRDGRC1 = (uint16_t)MTR_HALF_CARRIER_SET;
    TRDGRA1 = (uint16_t)MTR_HALF_CARRIER_SET;
    TRDGRD1 = (uint16_t)MTR_HALF_CARRIER_SET;
    TRDGRB1 = (uint16_t)MTR_HALF_CARRIER_SET;

    /* TRDSTR . timer RD start register ************************************************************************
    b7:b4      - nothing is assigned - the write value must be 0
    b3 CSEL1   - TRD1 count operation select - count continues after compare match with TRDGRA1 register
    b2 CSEL0   - TRD0 count operation select - count continues after compare match with TRDGRA0 register
    b1 TSTART1 - TRD1 count start flag - count start
    b0 TSTART0 - TRD0 count start flag - count start
    ***********************************************************************************************************/
    TRDSTR = 0x0F;

    TRDPR10 = 0;                /* INTTRD0(trigger : timer RD0 compare match A) priority level is 1 */
    TRDPR00 = 1;
    TRDMK0 = 0;                 /* INTTRD0 interrupt servicing enabled */
} /* End of function mtr_init_trd */

/***********************************************************************************************************************
* Function Name : mtr_init_intp
* Description   : Initialize of External Interrupt(INTP)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_intp(void)
{
    /********** external interrupt edge detection 0(INTP0) **********/
    PPR10 = 0;                  /* INTP0 (external interrupt edge detection 0) priority level is 0 */
    PPR00 = 0;

    EGP0_bit.no0 = 0;           /* INTP0 pin valid edge : falling edge */
    EGN0_bit.no0 = 1;

    MTR_OC_INTR_MASK = MTR_ENABLE_OC_INTR;
                                /* INTP0 interrupt servicing enabled */

#if (MTRCONF_SENSOR_MODE == HALL)
    /*************** initialize I/O port ***************/
    PM5_bit.no2 = 1;            /* input mode for Hall U */
    PM5_bit.no3 = 1;            /* input mode for Hall V */
    PM5_bit.no4 = 1;            /* input mode for Hall W */

    /*************** external interrupt edge detection 1,2,3(INTP1,2,3) ***************/
    PPR01 = 1;                  /* INTP1 (external interrupt edge detection) priority level is 1 */
    PPR11 = 0;
    PPR02 = 1;                  /* INTP2 (external interrupt edge detection) priority level is 1 */
    PPR12 = 0;
    PPR03 = 1;                  /* INTP3 (external interrupt edge detection) priority level is 1 */
    PPR13 = 0;

    EGP0_bit.no1 = 1;           /* INTP1 pin valid edge : both rising and falling edges */
    EGN0_bit.no1 = 1;
    EGP0_bit.no2 = 1;           /* INTP2 pin valid edge : both rising and falling edges */
    EGN0_bit.no2 = 1;
    EGP0_bit.no3 = 1;           /* INTP3 pin valid edge : both rising and falling edges */
    EGN0_bit.no3 = 1;

    PMK1 = 1;                   /* INTP1 interrupt servicing disabled */
    PMK2 = 1;                   /* INTP2 interrupt servicing disabled */
    PMK3 = 1;                   /* INTP3 interrupt servicing disabled */
#endif

    PIOR0 = 1;                  /* I/O port for peripheral functions */
} /* End of function mtr_init_intp */

/***********************************************************************************************************************
* Function Name : mtr_init_ad_converter
* Description   : Initialize A/D converter
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void mtr_init_ad_converter(void)
{
    int16_t i;
    /* initialize I/O port *************************************************************************************
    Set used ports as analog input
    ***********************************************************************************************************/
    P2_bit.no4 = 1;             /* input mode for Vdc */

#if (MTRCONF_SENSOR_MODE == LESS)
    P0_bit.no3 = 1;             /* input mode for VU */
    P2_bit.no0 = 1;             /* input mode for VV */
    P2_bit.no1 = 1;             /* input mode for VW */
#endif

    /********** configure A/D converter **********/
    /* ADM0 . A/D converter mode register 0 ********************************************************************
    b7 ADCS       - A/D conversion operation control - stop conversion operation
    b6 ADMD       - specification of the A/D conversion channel selection mode - select mode
    b5:b3 FR2:FR0 - conversion time selection - 2.125usec
    b2:b1 LV1:LV0 - mode - normal 2
    b0 ADCE       - A/D voltage comparator operation control - stop A/D voltage comparator operation
    ***********************************************************************************************************/
    ADM0 = 0x32;

    /* ADM1 . A/D converter mode register 1 ********************************************************************
    b7:b6 ADTMD1:ADTMD0 - selection of the A/D conversion trigger mode - software trigger mode
    b5 ADSCM            - specification of the A/D conversion mode - one-shot conversion mode
    b4:b2               - reserved set to 0
    b1:b0 ADTRS1:ADTRS0 - selection of the hardware trigger signal
                        - end of timer channel 1 count or capture interrupt signal (INTTM01)
    ***********************************************************************************************************/
    ADM1 = 0x20;

    /* ADM2 . A/D converter mode register 2 ********************************************************************
    b7:b6 ADREFP1:ADREFP0 - selection of the "+" side reference voltage source of the A/D converter
                          - supplied from VDD
    b5 ADREFM             - selection of the "-" side reference voltage source of the A/D converter - supplied from VSS
    b4                    - reserved set to 0
    b3 ADRCK              - checking the upper limit and lower limit conversion result values
                          - the interrupt signal is output
                            when the ADLL register <= the ADCR register <= the ADUL register
    b2 AWC                - specification of the SNOOZE mode - do not use the SNOOZE mode function
    b1                    - reserved set to 0
    b0 ADTYP              - selection of the A/D conversion resolution - 10bit resolution
    ************************************************************************************************************/
    ADM2 = 0x00;

    ADCE = 1;                   /* conversion standby mode (only A/D voltage comparator consumes power) */
    ADMK = 1;                   /* INTAD(trigger:end of A/D conversion) interrupt servicing disabled */

    for (i=0; i<0x6; i++)
    {
        NOP();
    }

} /* End of function mtr_init_ad_converter */

#if (MTRCONF_SENSOR_MODE == HALL)
/***********************************************************************************************************************
* Function Name : R_MTR_hall_interrupt_enable
* Description   : Hall interrupt enabled
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_hall_interrupt_enable(void)
{
    PMK1 = 0;                   /* INTP1 interrupt servicing enabled (HU) */
    PMK2 = 0;                   /* INTP2 interrupt servicing enabled (HV) */
    PMK3 = 0;                   /* INTP3 interrupt servicing enabled (HW) */

    PIF1 = 0;                   /* INTP1 interrupt request flag clear */
    PIF2 = 0;                   /* INTP2 interrupt request flag clear */
    PIF3 = 0;                   /* INTP3 interrupt request flag clear */
} /* End of function R_MTR_hall_interrupt_enable */

/***********************************************************************************************************************
* Function Name : R_MTR_hall_interrupt_disable
* Description   : Hall interrupt disabled
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_hall_interrupt_disable(void)
{
    PMK1 = 1;                   /* INTP1 interrupt servicing disable (HU) */
    PMK2 = 1;                   /* INTP2 interrupt servicing disable (HV) */
    PMK3 = 1;                   /* INTP3 interrupt servicing disable (HW) */

    PIF1 = 0;                   /* INTP1 interrupt request flag clear */
    PIF2 = 0;                   /* INTP2 interrupt request flag clear */
    PIF3 = 0;                   /* INTP3 interrupt request flag clear */
} /* End of function R_MTR_hall_interrupt_disable */
#endif

/***********************************************************************************************************************
* Function Name : R_MTR_get_adc
* Description   : A/D conversion
* Arguments     : u1_ad_ch - A/D converter channel number
* Return Value  : A/D converted value
***********************************************************************************************************************/
int16_t R_MTR_get_adc(uint8_t u1_ad_ch)
{
    int16_t s2_ad_value;

    ADIF = 0;
    ADS  = u1_ad_ch;                        /* set converted channel */
    ADCS = 1;

    while (MTR_CLR == ADIF)
    {
        /* waiting for A/D converter */
    }
    s2_ad_value = (ADCR >> 6);       /* get A/D converted value (10bit) */

    return (s2_ad_value);
} /* End of function R_MTR_get_adc */

#if (MTRCONF_SENSOR_MODE == LESS)
/***********************************************************************************************************************
* Function Name : R_MTR_get_v_dcuvw_adc
* Description   : A/D conversion
* Arguments     : Bus voltage and 3 phases voltage
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_get_v_dcuvw_adc(int16_t *s2_v_dc, int16_t *s2_v_uvw)
{
    /* get voltage */
    ADIF = 0;
    ADS = MTR_ADCCH_VDC;                          /* select converted channel */
    ADCS = 1;                                     /* start to wait trigger */
    while (MTR_CLR == ADIF)
    {
        /* waiting for A/D converter */
    }

    s2_v_dc[0]  = (ADCR >> 6);                    /* get A/D converted value (10bit) */
    ADIF = 0;
    ADS = MTR_ADCCH_VU;                           /* select converted channel */
    ADCS = 1;                                     /* start to wait trigger */

    while (MTR_CLR == ADIF)
    {
        /* waiting for A/D converter */
    }

    s2_v_uvw[0] = (ADCR >> 6);                    /* get A/D converted value (10bit) */
    ADIF = 0;
    ADS = MTR_ADCCH_VV;                           /* select converted channel */
    ADCS = 1;                                     /* start to wait trigger */

    while (MTR_CLR == ADIF)
    {
        /* waiting for A/D converter */
    }

    s2_v_uvw[1] = (ADCR >> 6);                    /* get A/D converted value (10bit) */
    ADIF = 0;
    ADS = MTR_ADCCH_VW;                           /* select converted channel */
    ADCS = 1;                                     /* start to wait trigger */

    while (MTR_CLR == ADIF)
    {
        /* waiting for A/D converter */
    }

    s2_v_uvw[2] = (ADCR >> 6);                    /* get A/D converted value (10bit) */
} /* End of function R_MTR_get_v_dcuvw_adc */
#endif

/***********************************************************************************************************************
* Function Name : R_MTR_ctrl_stop
* Description   : TRD output, Hall interrupt and delay timer disable
*                 motor output port is off for motor control stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ctrl_stop(void)
{
    TRDOER1 = 0xFF;                         /* TRD output disable */

#if (MTRCONF_SENSOR_MODE == HALL)
    R_MTR_hall_interrupt_disable();         /* Hall interrupt disable */

#elif (MTRCONF_SENSOR_MODE == LESS)
    mtr_stop_delay_cnt();                   /* stop delay counter */
    mtr_clear_inttm03();                    /* clear INTTM03 interrupt flag */
#endif

    MTR_PORT_UP = 0;                        /* Up = OFF("Low") */
    MTR_PORT_UN = 0;                        /* Un = OFF("Low") */
    MTR_PORT_VP = 0;                        /* Vp = OFF("Low") */
    MTR_PORT_VN = 0;                        /* Vn = OFF("Low") */
    MTR_PORT_WP = 0;                        /* Wp = OFF("Low") */
    MTR_PORT_WN = 0;                        /* Wn = OFF("Low") */
} /* End of function R_MTR_ctrl_stop */

/***********************************************************************************************************************
* Function Name : R_MTR_v_pattern_output
* Description   : set TRD resister for voltage output
* Arguments     : u1_pattern - Voltage pattern
*               : u2_pwm_duty - PWM duty
* Return Value  : error status
***********************************************************************************************************************/
uint8_t R_MTR_v_pattern_output(uint16_t u2_pattern, uint16_t u2_pwm_duty)
{
    uint8_t u1_temp_error_flag = MTR_CLR;

    /*========================*/
    /*     stop PWM timer     */
    /*========================*/
    TRDSTR = 0x0C;                          /* stop TRD0 */

    /*======================*/
    /*     set register     */
    /*======================*/
    /* PWM output arm setting */
#if (MTRCONF_PWM_MODE == NON_COMPLEMENTARY)
    /***************** non-complementary synchronous pattern ********************/
    switch (u2_pattern)
    {
        case MTR_VP_ON_WN_PWM:
            TRDOER1 = 0x7F;                 /* Wn : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 1;                /* Vp = ON ("High") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_WP_PWM_VN_ON:
            TRDOER1 = 0xDF;                 /* Wp : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 1;                /* Vn = ON ("High") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_WP_ON_UN_PWM:
            TRDOER1 = 0xF7;                 /* Un : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 1;                /* Wp = ON ("High") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_UP_PWM_WN_ON:
            TRDOER1 = 0xFD;                 /* Up : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 1;                /* Wn = ON ("High") */
        break;

        case MTR_UP_ON_VN_PWM:
            TRDOER1 = 0xBF;                 /* Vn : PWM output enable */
            MTR_PORT_UP = 1;                /* Up = ON ("High") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_VP_PWM_UN_ON:
            TRDOER1 = 0xEF;                 /* Vp : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 1;                /* Un = ON ("High") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_UP_PWM_VN_ON:
            TRDOER1 = 0xFD;                 /* Up : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 1;                /* Vn = ON ("High") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_VP_ON_UN_PWM:
            TRDOER1 = 0xF7;                 /* Un : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 1;                /* Vp = ON ("High") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_VP_PWM_WN_ON:
            TRDOER1 = 0xEF;                 /* Vp : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 1;                /* Wn = ON ("High") */
        break;

        case MTR_WP_ON_VN_PWM:
            TRDOER1 = 0xBF;                 /* Vn : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 1;                /* Wp = ON ("High") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_WP_PWM_UN_ON:
            TRDOER1 = 0xDF;                 /* Wp : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 1;                /* Un = ON ("High") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_UP_ON_WN_PWM:
            TRDOER1 = 0x7F;                 /* Wn : PWM output enable */
            MTR_PORT_UP = 1;                /* Up = ON ("High") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        /* the default case is intentionally combined */
        case MTR_PATTERN_ERROR:
        default:
            TRDOER1 = 0xFF;                 /* PWM output disable */
            MTR_PORT_UP = 0;                /* Up = ON ("High") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
            u1_temp_error_flag = MTR_SET;   /* error status update : Hall error */
        break;
    }
#endif

#if (MTRCONF_PWM_MODE == COMPLEMENTARY)
    /***************** complementary synchronous pattern ********************/
    switch (u2_pattern)
    {
        case MTR_VP_ON_W_PWM:
            TRDOER1 = 0x5F;                 /* Wn/Wp : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 1;                /* Vp = ON ("High") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_W_PWM_VN_ON:
            TRDOER1 = 0x5F;                 /* Wp/Wn : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 1;                /* Vn = ON ("High") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_WP_ON_U_PWM:
            TRDOER1 = 0xF5;                 /* Un/Up : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 1;                /* Wp = ON ("High") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_U_PWM_WN_ON:
            TRDOER1 = 0xF5;                 /* Up/Un : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 1;                /* Wn = ON ("High") */
        break;

        case MTR_UP_ON_V_PWM:
            TRDOER1 = 0xAF;                 /* Vn/Vp : PWM output enable */
            MTR_PORT_UP = 1;                /* Up = ON ("High") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_V_PWM_UN_ON:
            TRDOER1 = 0xAF;                 /* Vp/Vn : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 1;                /* Un = ON ("High") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_U_PWM_VN_ON:
            TRDOER1 = 0xF5;                 /* Up/Un : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 1;                /* Vn = ON ("High") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_VP_ON_U_PWM:
            TRDOER1 = 0xF5;                 /* Un/Up : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 1;                /* Vp = ON ("High") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_V_PWM_WN_ON:
            TRDOER1 = 0xAF;                 /* Vp/Vn : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 1;                /* Wn = ON ("High") */
        break;

        case MTR_WP_ON_V_PWM:
            TRDOER1 = 0xAF;                 /* Vn/Vp : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 1;                /* Wp = ON ("High") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_W_PWM_UN_ON:
            TRDOER1 = 0x5F;                 /* Wp/Wn : PWM output enable */
            MTR_PORT_UP = 0;                /* Up = OFF("Low") */
            MTR_PORT_UN = 1;                /* Un = ON ("High") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        case MTR_UP_ON_W_PWM:
            TRDOER1 = 0x5F;                 /* Wn/Wp : PWM output enable */
            MTR_PORT_UP = 1;                /* Up = ON ("High") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
        break;

        /* the default case is intentionally combined */
        case MTR_PATTERN_ERROR:
        default:
            TRDOER1 = 0xFF;                 /* PWM output disable */
            MTR_PORT_UP = 0;                /* Up = ON ("High") */
            MTR_PORT_UN = 0;                /* Un = OFF("Low") */
            MTR_PORT_VP = 0;                /* Vp = OFF("Low") */
            MTR_PORT_VN = 0;                /* Vn = OFF("Low") */
            MTR_PORT_WP = 0;                /* Wp = OFF("Low") */
            MTR_PORT_WN = 0;                /* Wn = OFF("Low") */
            u1_temp_error_flag = MTR_SET;   /* error status update : Hall error */
        break;
    }
#endif

#if (MTRCONF_PWM_MODE == NON_COMPLEMENTARY)
    /***************** set duty for non-complementary output ********************/
    if ((MTR_UP_PWM_VN_ON <= u2_pattern) && (MTR_WP_PWM_VN_ON >= u2_pattern))
    {
        TRDGRB0 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of U phase */
        TRDGRA1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of V phase */
        TRDGRB1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of W phase */

        TRDGRD0 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of U phase */
        TRDGRC1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of V phase */
        TRDGRD1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of W phase */
    }
    else if ((MTR_UP_ON_VN_PWM <= u2_pattern) && (MTR_WP_ON_VN_PWM >= u2_pattern))
    {
        TRDGRB0 = u2_pwm_duty;            /* duty of U phase */
        TRDGRA1 = u2_pwm_duty;            /* duty of V phase */
        TRDGRB1 = u2_pwm_duty;            /* duty of W phase */

        TRDGRD0 = u2_pwm_duty;            /* duty of U phase */
        TRDGRC1 = u2_pwm_duty;            /* duty of V phase */
        TRDGRD1 = u2_pwm_duty;            /* duty of W phase */
    }
    else
    {
        /* do nothing */
    }
#endif

#if (MTRCONF_PWM_MODE == COMPLEMENTARY)
    /***************** set duty for complementary output ********************/
    if ((MTR_U_PWM_VN_ON <= u2_pattern) && (MTR_W_PWM_VN_ON >= u2_pattern))
    {
        TRDGRB0 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of U phase */
        TRDGRA1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of V phase */
        TRDGRB1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of W phase */

        TRDGRD0 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of U phase */
        TRDGRC1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of V phase */
        TRDGRD1 = (int16_t)MTR_CARRIER_SET - u2_pwm_duty;    /* duty of W phase */
    }
    else if ((MTR_UP_ON_V_PWM <= u2_pattern) && (MTR_WP_ON_V_PWM >= u2_pattern))
    {
        TRDGRB0 = u2_pwm_duty;            /* duty of U phase */
        TRDGRA1 = u2_pwm_duty;            /* duty of V phase */
        TRDGRB1 = u2_pwm_duty;            /* duty of W phase */

        TRDGRD0 = u2_pwm_duty;            /* duty of U phase */
        TRDGRC1 = u2_pwm_duty;            /* duty of V phase */
        TRDGRD1 = u2_pwm_duty;            /* duty of W phase */
    }
    else
    {
        /* do nothing */
    }
#endif

    /*===========================*/
    /*     restart pwm timer     */
    /*===========================*/
#if (MTRCONF_PWM_MODE == NON_COMPLEMENTARY)
    TRD0 = 0;                                 /* clear TRD0 */
#endif

#if (MTRCONF_PWM_MODE == COMPLEMENTARY)
    TRD0 = (uint16_t)MTR_DEADTIME_SET;        /* reset TRD0 */
#endif

    TRD1 = 0;                                 /* clear TRD1 */
    TRDSTR = 0x0F;                            /* start TRD0 */

    return (u1_temp_error_flag);
} /* End of function R_MTR_v_pattern_output */
