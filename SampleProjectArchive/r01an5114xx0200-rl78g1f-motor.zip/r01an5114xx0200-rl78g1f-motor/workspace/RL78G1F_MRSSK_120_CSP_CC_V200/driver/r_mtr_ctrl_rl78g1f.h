/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_ctrl_rl78g1f.h
* Description : Definitions of the processing of MCU
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef MTR_CTRL_RL78G1F_H
#define MTR_CTRL_RL78G1F_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* frequency of timers used for interruption */
#define     MTR_CARRIER_FREQ        (20.0f)            /* carrier wave frequency[kHz] */
#define     MTR_TAU0_FREQ           (32.0f)            /* TAU0 frequency[MHz] */
#define     MTR_PWM_TIMER_FREQ      (64.0f)            /* PWM timer frequency[MHz] */
#define     MTR_TAU0_PERIOD         (0.001f)           /* control period of TAU0 interrupt [s] */

/* scaling for conversion from value of A/D resister to voltage(V) */
#define     MTR_VDC_SCALING         (IP_VDC_RANGE / 1023.0f)
#define     MTR_PU_Q_VDC_SCALING    ((int16_t)(MTR_VDC_SCALING * PU_SF_VOLTAGE * (1 << (MTR_Q_VOLTAGE))))
                                                       /* with PU unit and fixed decimal */

/* setting value of carrier for non-complementary pwm */
#if (MTRCONF_PWM_MODE == NON_COMPLEMENTARY)
    #define     MTR_CARRIER_SET         ((MTR_PWM_TIMER_FREQ * 1000 / MTR_CARRIER_FREQ / 2) - 2)
                                                                                             /* carrier count of pwm */
/* setting value of carrier for complementary pwm */
#endif
#if (MTRCONF_PWM_MODE == COMPLEMENTARY)
    #define     MTR_DEADTIME            (2000)                                                     /* deadtime[nsec] */
    #define     MTR_DEADTIME_SET        ((int16_t)(MTR_DEADTIME * MTR_PWM_TIMER_FREQ / 1000))
                                                                                        /* setting value of deadtime */
    #define     MTR_CARRIER_SET         ((MTR_PWM_TIMER_FREQ * 1000 / MTR_CARRIER_FREQ / 2) + MTR_DEADTIME_SET - 2)
                                                                                             /* carrier count of pwm */
    #define     MTR_NDT_CARRIER_SET    (MTR_CARRIER_SET - MTR_DEADTIME_SET)      /* MTR_CARRIER_SET without deadtime */
#endif
#define     MTR_HALF_CARRIER_SET    (MTR_CARRIER_SET / 2)                           /* setting value of half carrier */

/* port number */
#define     MTR_PORT_HALL_U         (P5_bit.no2)       /* input port of Hall U */
#define     MTR_PORT_HALL_V         (P5_bit.no3)       /* input port of Hall V */
#define     MTR_PORT_HALL_W         (P5_bit.no4)       /* input port of Hall W */

#define     MTR_PORT_UP             (P1_bit.no5)       /* output port of PWM timer(Up) */
#define     MTR_PORT_UN             (P1_bit.no4)       /* output port of PWM timer(Un) */
#define     MTR_PORT_VP             (P1_bit.no3)       /* output port of PWM timer(Vp) */
#define     MTR_PORT_VN             (P1_bit.no1)       /* output port of PWM timer(Vn) */
#define     MTR_PORT_WP             (P1_bit.no2)       /* output port of PWM timer(Wp) */
#define     MTR_PORT_WN             (P1_bit.no0)       /* output port of PWM timer(Wn) */

#define     MTR_PORT_SW1            (P0_bit.no5)       /* input port of SW1 */
#define     MTR_PORT_SW2            (P0_bit.no6)       /* input port of SW2 */

#define     MTR_PORT_LED1           (P14_bit.no1)      /* output port of LED1 */
#define     MTR_PORT_LED2           (P14_bit.no0)      /* output port of LED2 */
#define     MTR_PORT_LED3           (P0_bit.no4)       /* output port of LED3 */

#define     MTR_TAU1_CNT            (TCR01)            /* TAU1 count register for speed calculation */

/* A/D converter channel number */
#define     MTR_ADCCH_VR1           (6)                /* VR1 */
#define     MTR_ADCCH_VDC           (4)                /* bus voltage */
#define     MTR_ADCCH_VU            (16)               /* U phase voltage */
#define     MTR_ADCCH_VV            (0)                /* V phase voltage */
#define     MTR_ADCCH_VW            (1)                /* W phase voltage */
#define     MTR_ADDCH_IU            (2)                /* U phase current */
#define     MTR_ADDCH_IV            (19)               /* V phase current */
#define     MTR_ADDCH_IW            (3)                /* W phase current */

/* Over current detection reference */
#define     MTR_OC_INTR_MASK        (PMK0)             /* INTP0 interrupt mask flag */
#define     MTR_DISABLE_OC_INTR     (1)                /* disable INTP0 interrupt service */
#define     MTR_ENABLE_OC_INTR      (0)                /* enable INTP0 interrupt service */

/* voltage pattern */
#define     MTR_PATTERN_ERROR       (0)                /* pattern error */
#define     MTR_UP_PWM_VN_ON        (1)                /* Up(PWM) to Vn(on) */
#define     MTR_UP_PWM_WN_ON        (2)                /* Up(PWM) to Wn(on) */
#define     MTR_VP_PWM_UN_ON        (3)                /* Vp(PWM) to Un(on) */
#define     MTR_VP_PWM_WN_ON        (4)                /* Vp(PWM) to Wn(on) */
#define     MTR_WP_PWM_UN_ON        (5)                /* Wp(PWM) to Un(on) */
#define     MTR_WP_PWM_VN_ON        (6)                /* Wp(PWM) to Vn(on) */
#define     MTR_UP_ON_VN_PWM        (7)                /* Up(on) to Vn(PWM) */
#define     MTR_UP_ON_WN_PWM        (8)                /* Up(on) to Wn(PWM) */
#define     MTR_VP_ON_UN_PWM        (9)                /* Vp(on) to Un(PWM) */
#define     MTR_VP_ON_WN_PWM        (10)               /* Vp(on) to Wn(PWM) */
#define     MTR_WP_ON_UN_PWM        (11)               /* Wp(on) to Un(PWM) */
#define     MTR_WP_ON_VN_PWM        (12)               /* Wp(on) to Vn(PWM) */
#define     MTR_U_PWM_VN_ON         (13)               /* U(PWM) to Vn(on) */
#define     MTR_U_PWM_WN_ON         (14)               /* U(PWM) to Wn(on) */
#define     MTR_V_PWM_UN_ON         (15)               /* V(PWM) to Un(on) */
#define     MTR_V_PWM_WN_ON         (16)               /* V(PWM) to Wn(on) */
#define     MTR_W_PWM_UN_ON         (17)               /* W(PWM) to Un(on) */
#define     MTR_W_PWM_VN_ON         (18)               /* W(PWM) to Vn(on) */
#define     MTR_UP_ON_V_PWM         (19)               /* Up(on) to V(PWM) */
#define     MTR_UP_ON_W_PWM         (20)               /* Up(on) to W(PWM) */
#define     MTR_VP_ON_U_PWM         (21)               /* Vp(on) to U(PWM) */
#define     MTR_VP_ON_W_PWM         (22)               /* Vp(on) to W(PWM) */
#define     MTR_WP_ON_U_PWM         (23)               /* Wp(on) to U(PWM) */
#define     MTR_WP_ON_V_PWM         (24)               /* Wp(on) to V(PWM) */

#define     mtr_clear_trd0_imfa()   (TRDSR0_bit.no0 = 0)  /* clear compare match flag IMFA */
#define     mtr_set_tdr03(cnt)      (TDR03 = cnt)         /* set delay timer count */
#define     mtr_start_delay_cnt()   (TS0L_bit.no3 = 1)    /* start delay timer */
#define     mtr_stop_delay_cnt()    (TT0L_bit.no3 = 0)    /* stop delay timer */
#define     mtr_clear_inttm03()     (TMIF03 = 0)          /* desable interruption for TAU3 */ 
#define     clear_wdt()             (WDTE = 0xAC)         /* clear Watch Dog Timer */

/* system error status */
#define    ERROR_NONE                   (0x00)
#define    ERROR_CHANGE_CLK_TIMEOUT     (0x01)
#define    ERROR_CHARGE_CAP_TIMEOUT     (0x02)

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MTR_InitHardware
* Description   : Initialize peripheral functions
* Arguments     : None
* Return Value  : Error status for initialization
***********************************************************************************************************************/
uint16_t R_MTR_InitHardware(void);

#if (MTRCONF_SENSOR_MODE == HALL)
/***********************************************************************************************************************
* Function Name : R_MTR_hall_interrupt_enable
* Description   : Hall interrupt enabled
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_hall_interrupt_enable(void);

/***********************************************************************************************************************
* Function Name : R_MTR_hall_interrupt_disable
* Description   : Hall interrupt disabled
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_hall_interrupt_disable(void);
#endif

/***********************************************************************************************************************
* Function Name : R_MTR_get_adc
* Description   : A/D conversion
* Arguments     : u1_ad_ch - A/D converter channel number
* Return Value  : A/D converted value
***********************************************************************************************************************/
int16_t R_MTR_get_adc(uint8_t u1_ad_ch);

#if (MTRCONF_SENSOR_MODE == LESS)
/***********************************************************************************************************************
* Function Name : R_MTR_get_v_dcuvw_adc
* Description   : A/D conversion
* Arguments     : Bus voltage and 3 phases voltage
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_get_v_dcuvw_adc(int16_t *s2_v_dc, int16_t *s2_v_uvw);
#endif

/***********************************************************************************************************************
* Function Name : R_MTR_ctrl_stop
* Description   : TRD output disable, motor stop check, interrupt request clear,
*                 motor output port is off for motor control stop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ctrl_stop(void);

/***********************************************************************************************************************
* Function Name : R_MTR_v_pattern_output
* Description   : Change voltage pattern
* Arguments     : u1_pattern - Voltage pattern
*               : u2_pwm_duty - PWM duty
* Return Value  : error status
***********************************************************************************************************************/
uint8_t R_MTR_v_pattern_output(uint16_t u1_pattern, uint16_t u2_pwm_duty);

#endif /* MTR_CTRL_RL78G1F_H */
