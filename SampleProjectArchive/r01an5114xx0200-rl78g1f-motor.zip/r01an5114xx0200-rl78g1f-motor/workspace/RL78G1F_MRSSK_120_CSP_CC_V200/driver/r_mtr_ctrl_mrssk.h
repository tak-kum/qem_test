/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_ctrl_mrssk.h
* Description : Definitions of the processing of a H/W control layer
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef MTR_CTRL_MRSSK_H
#define MTR_CTRL_MRSSK_H

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MTR_GetVr1Ad
* Description   : Get A/D converted value of VR1
* Arguments     : None
* Return Value  : A/D converted value of VR1
***********************************************************************************************************************/
uint16_t      R_MTR_GetVr1Ad(void);

/***********************************************************************************************************************
* Function Name : R_MTR_GetSw1
* Description   : Get state of SW1
* Arguments     : None
* Return Value  : State of SW1
***********************************************************************************************************************/
uint8_t       R_MTR_GetSw1(void);

/***********************************************************************************************************************
* Function Name : R_MTR_GetSw2
* Description   : Get state of SW2
* Arguments     : None
* Return Value  : state of SW2
***********************************************************************************************************************/
uint8_t       R_MTR_GetSw2(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Led1On
* Description   : Turn on LED1
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void        R_MTR_Led1On(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Led2On
* Description   : Turn on LED2
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void        R_MTR_Led2On(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Led3On
* Description   : Turn on LED3
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void        R_MTR_Led3On(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Led1Off
* Description   : Turn off LED1
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void        R_MTR_Led1Off(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Led2Off
* Description   : Turn off LED2
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void        R_MTR_Led2Off(void);

/***********************************************************************************************************************
* Function Name : R_MTR_Led3Off
* Description   : Turn off LED3
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void        R_MTR_Led3Off(void);

#endif /* MTR_CTRL_MRSSK_H */
