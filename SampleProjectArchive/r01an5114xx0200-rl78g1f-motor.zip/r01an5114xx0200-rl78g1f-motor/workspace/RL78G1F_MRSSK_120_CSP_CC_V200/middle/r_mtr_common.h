/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_common.h
* Description : This header includes Pragma directive , Typedef definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

#define ICS_USE

/* guard against multiple inclusion */
#ifndef MTR_COMMON_H
#define MTR_COMMON_H

/***********************************************************************************************************************
* Pragma directive
***********************************************************************************************************************/
#include    "iodefine.h"
#include <stdint.h>

#define    DI()    __DI()
#define    EI()    __EI()
#define    NOP()   __nop()
#define    STOP()  __stop()
#define    HALT()  __halt()

#define    __interrupt __near

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* value for calculation */
#define     MTR_TWOPI                   (2 * 3.14159265359f)      /* 2*pi */
#define     MTR_TWOPI_60                (MTR_TWOPI / 60)          /* 2*pi/60 */

/* rotational direction */
#define     MTR_CW                      (0)                       /* clockwise */
#define     MTR_CCW                     (1)                       /* counter-clockwise */

/* SW condition */
#define     MTR_ON                      (0)                       /* active level of SW */
#define     MTR_OFF                     (1)                       /* inactive level of SW */

/* flag condition */
#define     MTR_CLR                     (0)                       /* for flag clear */
#define     MTR_SET                     (1)                       /* for flag set */

#endif /* MTR_COMMON_H */
