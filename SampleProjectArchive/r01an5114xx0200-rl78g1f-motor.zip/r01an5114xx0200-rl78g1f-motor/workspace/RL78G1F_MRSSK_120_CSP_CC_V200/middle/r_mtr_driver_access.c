/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_driver_access.c
* Description : The processing of accessing driver
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"
#include "r_mtr_common.h"
#include "r_mtr_driver_access.h"
#include "r_mtr_board.h"
#include "r_mtr_spm_120.h"
#include "r_dsp.h"
#include "r_mtr_fixed.h"
#include "r_mtr_pu_system.h"
#include "r_mtr_ctrl_rl78g1f.h"

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
uint8_t g_u1_trig_enable_write;                 /* ICS write enable flag */
mtr_ctrl_input_t st_ics_input_buff;             /* structure for ICS input */

extern st_mtr_120_control_t g_st_120;           /* structure for control */

/***********************************************************************************************************************
Private functions definitions
***********************************************************************************************************************/
/* set control variables */
#pragma inline R_MTR_SetVariables
void R_MTR_SetVariables(void);

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MTR_InitControl
* Description   : Initializes motor controller
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_InitControl(void)
{
    /* Initialize system state machine */
    mtr_statemachine_init(&g_st_120.st_stm);

    /* Reset configurations to default */
    mtr_120_motor_default_init(&g_st_120);
} /* End of function R_MTR_InitControl */

/***********************************************************************************************************************
* Function Name : R_MTR_IcsInput
* Description   : Set buffer variables
* Arguments     : st_ics_input : ICS input structure
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_IcsInput(mtr_ctrl_input_t *st_ics_input)
{
    /* copy structure */
    st_ics_input_buff = *st_ics_input;

    /* write enable switch */
    g_u1_trig_enable_write = MTR_SET;
} /* End of function R_MTR_IcsInput */

/***********************************************************************************************************************
* Function Name : R_MTR_SetVariables
* Description   : Set control variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_SetVariables(void)
{
    /* rotation direction */
    g_st_120.u1_ref_dir = st_ics_input_buff.u1_dir;

    /* motor parameters */
    g_st_120.st_motor  = st_ics_input_buff.st_motor;

    /* reference speed */
    g_st_120.s2_ref_speed_rad = st_ics_input_buff.s2_ref_speed_rad;
    if (MTR_CCW == g_st_120.u1_ref_dir)
    {
        g_st_120.s2_ref_speed_rad = -g_st_120.s2_ref_speed_rad;
    }

    /* limit of acceleration */
    g_st_120.s2_ramp_limit_speed_rad = st_ics_input_buff.s2_ramp_limit_speed_rad;

    /* limit of variation of voltage */
    g_st_120.s2_ramp_limit_v = st_ics_input_buff.s2_ramp_limit_v;

    /* speed PI gain */
    g_st_120.st_pi_speed.s2_kp = st_ics_input_buff.st_gain.s2_speed_pi_kp;
    g_st_120.st_pi_speed.s2_kidt = st_ics_input_buff.st_gain.s2_speed_pi_kidt;

#if (MTRCONF_SENSOR_MODE == HALL)
    /* open-loop start reference voltage */
    g_st_120.st_hall.s2_start_ref_v = st_ics_input_buff.s2_start_ref_v;

#elif (MTRCONF_SENSOR_MODE == LESS)
    /* voltage reference at draw-in */
    g_st_120.st_less.s2_draw_in_ref_v = st_ics_input_buff.s2_draw_in_ref_v;

    /* open-loop start reference voltage */
    g_st_120.st_less.s2_ol_ref_v = st_ics_input_buff.s2_ol_ref_v;

    /* voltage constant period at draw-in */
    g_st_120.st_less.u2_v_const_period = (uint16_t)(g_st_120.st_less.s2_draw_in_ref_v / g_st_120.s2_ramp_limit_v);

    /* openloop to sensorless control change speed */
    g_st_120.st_less.st_ol2less.s2_change_speed_rad = st_ics_input_buff.s2_ol2less_speed_rad;

    /* accelerattion at translating into PI control */
    g_st_120.st_less.st_ol2less.s2_ramp_speed_rad = st_ics_input_buff.s2_ol2less_ramp_speed_rad;

    /* speed to change from sensorless control to open-loop drive */
    g_st_120.st_less.s2_less2ol_speed_rad = st_ics_input_buff.s2_less2ol_speed_rad;

    /* adjusting angle */
    g_st_120.st_less.s2_angle_shift_adjust = st_ics_input_buff.s2_angle_shift_adjust;
#endif

} /* End of function R_MTR_SetVariables */

/***********************************************************************************************************************
* Function Name : R_MTR_InputBuffParamReset
* Description   : Reset buffer variables when motor control is reset
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_InputBuffParamReset(void)
{
    /* rotation direction */
    st_ics_input_buff.u1_dir                    = MTR_CW;

    /* motor parameters */
    st_ics_input_buff.st_motor.u2_mtr_pp        = MP_POLE_PAIRS;
    st_ics_input_buff.st_motor.s2_mtr_r         = FIX_fromfloat(MP_RESISTANCE * PU_SF_RES, MTR_Q_RES);
    st_ics_input_buff.st_motor.s2_mtr_ld        = FIX_fromfloat(MP_D_INDUCTANCE * PU_SF_IND, MTR_Q_IND);
    st_ics_input_buff.st_motor.s2_mtr_lq        = FIX_fromfloat(MP_Q_INDUCTANCE * PU_SF_IND, MTR_Q_IND);
    st_ics_input_buff.st_motor.s2_mtr_m         = FIX_fromfloat(MP_MAGNETIC_FLUX * PU_SF_FLUX, MTR_Q_FLUX);
    st_ics_input_buff.st_motor.s2_mtr_j         = FIX_fromfloat(MP_ROTOR_INERTIA * PU_SF_INERTIA, MTR_Q_INERTIA);

    /* reference speed */
    st_ics_input_buff.s2_ref_speed_rad          = 0;

    /* limit of acceleration */
    st_ics_input_buff.s2_ramp_limit_speed_rad   = mtr_conv_rpm2rad_pu(CP_RAMP_LIMIT_SPEED_RPM);

    /* limit of variation of voltage */
    st_ics_input_buff.s2_ramp_limit_v           = FIX_fromfloat(CP_RAMP_LIMIT_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

    /* speed PI gain */
    st_ics_input_buff.st_gain.s2_speed_pi_kp    = FIX_fromfloat(CP_SPEED_PI_KP * PU_SF_SPEED_KP, MTR_Q_SPEED_KP);
    st_ics_input_buff.st_gain.s2_speed_pi_kidt  = FIX_fromfloat(CP_SPEED_PI_KIDT * PU_SF_SPEED_KIDT, MTR_Q_SPEED_KIDT);

#if (MTRCONF_SENSOR_MODE == HALL)
    /* openloop start reference voltage */
    st_ics_input_buff.s2_start_ref_v            = FIX_fromfloat(CP_START_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

#elif (MTRCONF_SENSOR_MODE == LESS)
    /* voltage reference at draw-in */
    st_ics_input_buff.s2_draw_in_ref_v          = FIX_fromfloat(CP_DRAW_IN_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

    /* openloop start reference voltage */
    st_ics_input_buff.s2_ol_ref_v               = FIX_fromfloat(CP_OL_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

    /* accelerattion at translating into PI control */
    st_ics_input_buff.s2_ol2less_speed_rad      = mtr_conv_rpm2rad_pu(CP_OL2LESS_SPEED_RPM);

    /* openloop to sensorless control change speed */
    st_ics_input_buff.s2_ol2less_ramp_speed_rad = mtr_conv_rpm2rad_pu(CP_OL2LESS_SPEED_RAMP_RPM);

    /* speed to change from sensorless control to open-loop drive */
    st_ics_input_buff.s2_less2ol_speed_rad      = mtr_conv_rpm2rad_pu(CP_OL2LESS_SPEED_RPM - MTR_LESS2OL_HYSTERESIS);

    /* adjusting angle */
    st_ics_input_buff.s2_angle_shift_adjust     = 0;
#endif

    /* set variables for control */
    R_MTR_SetVariables();
    /* initialize write enable switch */
    g_u1_trig_enable_write = MTR_SET;
} /* End of function R_MTR_InputBuffParamReset */

/***********************************************************************************************************************
* Function Name : R_MTR_ExecEvent
* Description   : Change motor state and select action
* Arguments     : u1_event - event
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ExecEvent(uint8_t u1_event)
{
    mtr_statemachine_event(&g_st_120.st_stm, &g_st_120, u1_event);
} /* End of function R_MTR_ExecEvent */

/***********************************************************************************************************************
* Function Name : R_MTR_GetStatus
* Description   : Get status of motor control system
* Arguments     : None
* Return Value  : Motor status
***********************************************************************************************************************/
uint8_t R_MTR_GetStatus(void)
{
    return (mtr_statemachine_get_status(&g_st_120.st_stm));
} /* End of function R_MTR_GetStatus */

/***********************************************************************************************************************
* Function Name : R_MTR_GetErrorStatus
* Description   : Get status of motor error
* Arguments     : None
* Return Value  : g_st_120.u2_error_status - Error status
***********************************************************************************************************************/
uint16_t R_MTR_GetErrorStatus(void)
{
    return (g_st_120.u2_error_status);
} /* End of function  R_MTR_GetErrorStatus */

/***********************************************************************************************************************
* Function Name : R_MTR_GetDir
* Description   : Get rotation direction
* Arguments     : None
* Return Value  : g_st_120.u1_dir - Rotation direction
***********************************************************************************************************************/
uint8_t R_MTR_GetDir(void)
{
    return (g_st_120.u1_dir);
} /* End of function  R_MTR_GetDir */

/***********************************************************************************************************************
* Function Name : R_MTR_SetSpeed
* Description   : Set speed reference for board UI
* Arguments     : s2_ref_speed_rpm - Speed reference[rpm]
* Return Value  : u1_stop_req - stop request flag
***********************************************************************************************************************/
uint8_t R_MTR_SetSpeed(int16_t s2_ref_speed_rpm)
{
    uint8_t u1_stop_req;
    int16_t s2_temp;

    if (CP_MAX_SPEED_RPM <= s2_ref_speed_rpm)
    {
        /* when max speed < reference speed, reference speed is set to max speed */
        s2_temp = CP_MAX_SPEED_RPM;
        g_st_120.u1_ref_dir = MTR_CW;
        u1_stop_req = MTR_CLR;
    }
    else if ((CP_MAX_SPEED_RPM > s2_ref_speed_rpm) && (CP_MIN_SPEED_RPM < s2_ref_speed_rpm))
    {
        /* when min speed < reference speed < max speed, reference speed has no change */
        s2_temp = s2_ref_speed_rpm;
        g_st_120.u1_ref_dir = MTR_CW;
        u1_stop_req = MTR_CLR;
    }
    else if ((CP_MIN_SPEED_RPM > s2_ref_speed_rpm) && (-CP_MIN_SPEED_RPM < s2_ref_speed_rpm))
    {
        /* when -min speed < reference speed < min speed, stop request flag is set */
        s2_temp = 0;
        u1_stop_req = MTR_SET;                        /* set stop request flag */
    }
    else if ((-CP_MIN_SPEED_RPM > s2_ref_speed_rpm) && (-CP_MAX_SPEED_RPM < s2_ref_speed_rpm))
    {
        /* when -max speed < reference speed < -min speed, reference speed has no change */
        s2_temp = s2_ref_speed_rpm;
        g_st_120.u1_ref_dir = MTR_CCW;
        u1_stop_req = MTR_CLR;
    }
    else if (-CP_MAX_SPEED_RPM >= s2_ref_speed_rpm)
    {
        /* when reference speed < -max speed, reference speed is set to -max speed */
        s2_temp = -CP_MAX_SPEED_RPM;
        g_st_120.u1_ref_dir = MTR_CCW;
        u1_stop_req = MTR_CLR;
    }
    else
    {
        /* do nothing */
    }

    /* convert from rpm to rad/s */
    g_st_120.s2_ref_speed_rad = mtr_conv_rpm2rad_pu(s2_temp);

    return (u1_stop_req);
} /* End of function R_MTR_SetSpeed */

/***********************************************************************************************************************
* Function Name : R_MTR_ChargeCapacitor
* Description   : Wait for charging capacitor
* Arguments     : None
* Return Value  : u2_charge_cap_error - charge capacitor timeout error
***********************************************************************************************************************/
uint16_t R_MTR_ChargeCapacitor(void)
{
    uint16_t i;
    uint16_t u2_charge_cap_error;
    uint16_t u2_charge_cap_cnt;

    u2_charge_cap_error = ERROR_NONE;
    g_st_120.u1_flag_charge_cap = MTR_CLR;

    /* wait until Vdc exceeds MCU power on voltage */
    while (MTR_PU_Q_MCU_ON_V > g_st_120.s2_vdc_ad)
    {
        clear_wdt();                             /* watch dog timer clear */

        for (i = 0; i < 1500; i++)
        {
            NOP();
        }

        u2_charge_cap_cnt++;
        /*  if about 1.5 ms*20 times passes, charge capacitor timeout error is set*/
       if (u2_charge_cap_cnt > 20)
        {
            u2_charge_cap_error = ERROR_CHARGE_CAP_TIMEOUT;
            break;
        }
    }
    g_st_120.u1_flag_charge_cap = MTR_SET;

    return(u2_charge_cap_error);
} /* End of function R_MTR_ChargeCapacitor */

/***********************************************************************************************************************
* Function Name : R_MTR_UpdatePolling
* Description   : Polling u1_trig_enable_write to update configurations and commands
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_UpdatePolling(void)
{
    /*** set control variables ***/
    if (MTR_SET == g_u1_trig_enable_write)
    {
        R_MTR_SetVariables();
        g_u1_trig_enable_write = MTR_CLR;
    }
} /* End of function R_MTR_UpdatePolling */
