/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_pu_system.h
* Description : Definitons for per-unit system
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_PU_SYSTEM_H
#define R_MTR_PU_SYSTEM_H

/***********************************************************************************************************************
Global structure
***********************************************************************************************************************/
typedef struct
{
    int16_t s2_sf;                                      /* scale factor */
    int8_t  s1_sf_q;                                    /* Q-format of the scale factor */
    int8_t  s1_rsft;                                    /* number of bits to right shift after multiplication */
}mtr_frex_conv_t;

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define INV_LOG10_2              (1.0f / 0.3010299957f)         /* defines 1/log10(2) */

/*=======================*/
/*    Base Quantities    */
/*=======================*/
#define PU_BASE_CURRENT_A        (MP_NOMINAL_CURRENT_RMS)                 /* base quantity for current */
#define PU_BASE_VOLTAGE_V        (IP_INPUT_V)                             /* base quantity for voltage */
#define PU_BASE_FREQ_HZ          (CP_MAX_SPEED_RPM * MP_POLE_PAIRS / 60)  /* base quantity for frequency */
#define PU_BASE_ANGLE_RAD        (MTR_TWOPI)                              /* base quantity for angle (DO NOT CHANGE) */

/*============================*/
/*    General scale factor    */
/*============================*/
#define PU_SF_CURRENT            (1.0f / PU_BASE_CURRENT_A)                /* current scale factor */
#define PU_SF_VOLTAGE            (1.0f / PU_BASE_VOLTAGE_V)                /* voltage scale factor */
#define PU_SF_FREQ               (1.0f / PU_BASE_FREQ_HZ)                  /* frequency scale factor */
#define PU_SF_AFREQ              (PU_SF_FREQ / PU_BASE_ANGLE_RAD)          /* angular frequency scale factor */
#define PU_SF_TIME               (PU_BASE_FREQ_HZ)                         /* time scale factor */
#define PU_SF_RES                (PU_BASE_CURRENT_A / PU_BASE_VOLTAGE_V)   /* impedance(resistance) scale factor */
#define PU_SF_IND                (PU_SF_RES / PU_SF_AFREQ)                 /* inductance scale factor */
#define PU_SF_FLUX               (PU_SF_VOLTAGE / PU_SF_AFREQ)             /* induced voltage constant scale factor */
#define PU_SF_TORQUE             (PU_SF_FLUX * PU_SF_CURRENT)              /* torque scale factor */
#define PU_SF_INERTIA            (PU_SF_TORQUE * PU_SF_TIME / PU_SF_AFREQ) /* inertia scale factor */

/*===========================================*/
/*    Speed regulator gain scale factor      */
/*===========================================*/
#define PU_SF_SPEED_KP           (PU_SF_VOLTAGE / PU_SF_AFREQ) /* proportional gain scale factor of speed controller */
#define PU_SF_SPEED_KIDT         (PU_SF_SPEED_KP)              /* integral gain scale factor of speed controller */

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_pu_system_init
* Description   : Initialize per-unit system modules
* Arguments     : f4_adc_voltage_scl - Scale factor (Bus Voltage[PU(V)] / Bus Voltage ADC[digit])
*               : u2_polepair - Number of pole pairs of motor
* Return Value  : None
***********************************************************************************************************************/
void    mtr_pu_system_init(float, uint16_t);

/***********************************************************************************************************************
* Function Name : mtr_conv_current_pu
* Description   : Convert current A/D result [digit] to per-unit current [PU(A)]
* Arguments     : s2_current_adc - Result of current A/D conversion
* Return Value  : Current [PI(A)]
***********************************************************************************************************************/
int16_t mtr_conv_current_pu(int16_t);

/***********************************************************************************************************************
* Function Name : mtr_conv_vdc_pu
* Description   : Convert bus voltage A/D result [digit] to per-unit voltage[PU(V)]
* Arguments     : s2_voltage_adc - Result of bus voltage A/D conversion
* Return Value  : Bus voltage [PU(V)]
***********************************************************************************************************************/
int16_t mtr_conv_vdc_pu(int16_t);

/***********************************************************************************************************************
* Function Name : mtr_conv_rpm2rad_pu
* Description   : Convert mechanical speed[rpm] to electrical speed (angular frequency) [PU(rad/s)]
* Arguments     : s2_speed_rpm - Speed[rpm] to convert
* Return Value  : Electrical angular speed [PU(rad/s)]
***********************************************************************************************************************/
int16_t mtr_conv_rpm2rad_pu(int16_t);

/***********************************************************************************************************************
* Function Name : mtr_conv_rad2rpm_pu
* Description   : Convert electrical speed [PU(rad/s)] to mechanical speed[rpm]
* Arguments     : s2_ele_speed_pu - Speed[PU(rad/s)] to convert
* Return Value  : Mechanical speed [rpm]
***********************************************************************************************************************/
int16_t mtr_conv_rad2rpm_pu(int16_t);

/***********************************************************************************************************************
* Function Name : mtr_flex_conv_init
* Description   : Initialize flexible converter module to calculate (input) * (scale factor)
* Arguments     : (mtr_frex_conv_t*)st_conv - Pointer to converter structure
*                 (int8_t)s1_in_q - Q-format of input
*                 (int8_t)s1_out_q - Q-format of output
*                 (int8_t)s1_margin_q - Margin[bits] when calculate fixed point scale factor
*                 (float)f4_sf - Scale factor
* Return Value  : Conversion value
***********************************************************************************************************************/
void mtr_flex_conv_init(mtr_frex_conv_t *, int8_t, int8_t, int8_t, float);

#endif /* R_MTR_PU_SYSTEM_H */
