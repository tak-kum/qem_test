/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_driver_access.h
* Description : Definitions of the processing of accessing driver
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef MTR_DRIVER_ACCESS_H
#define MTR_DRIVER_ACCESS_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_parameter.h"

/***********************************************************************************************************************
Global structures
***********************************************************************************************************************/
/* Data structure for storing system configuration inputs */
typedef struct
{
    uint8_t   u1_dir;                      /* rotation direction (0:CW,1:CCW) */
    int16_t   s2_ref_speed_rad;            /* motor speed reference */
    int16_t   s2_ramp_limit_speed_rad;     /* limit of acceleration */
    int16_t   s2_ramp_limit_v;             /* limit of rate of voltage change */

#if (MTRCONF_SENSOR_MODE == HALL)
    int16_t   s2_start_ref_v;              /* openloop start reference voltage */

#elif (MTRCONF_SENSOR_MODE == LESS)
    int16_t   s2_draw_in_ref_v;            /* voltage reference at draw-in */
    int16_t   s2_ol_ref_v;                 /* openloop start reference voltage */
    int16_t   s2_ol2less_speed_rad;        /* speed to change from open-loop drive to sensorless control */
    int16_t   s2_ol2less_ramp_speed_rad;   /* accelerattion at translating into PI control */
    int16_t   s2_less2ol_speed_rad;        /* speed to change from sensorless control to open-loop drive */
    int16_t   s2_angle_shift_adjust;       /* adjust for delay counts */
#endif

    st_mtr_parameter_t           st_motor;           /* motor parameters */
    st_mtr_ctrl_gain_t           st_gain;            /* input PI gains */
} mtr_ctrl_input_t;

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MTR_InitControl
* Description   : Initializes motor controller
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_InitControl(void);

/***********************************************************************************************************************
* Function Name : R_MTR_IcsInput
* Description   : Set buffer variables
* Arguments     : st_ics_input - ICS input structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_IcsInput(mtr_ctrl_input_t *);

/***********************************************************************************************************************
* Function Name : R_MTR_InputBuffParamReset
* Description   : Reset buffer variables when motor control is reset
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_InputBuffParamReset(void);

/***********************************************************************************************************************
* Function Name : R_MTR_ExecEvent
* Description   : Change motor state and select action
* Arguments     : u1_event - event
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_ExecEvent(uint8_t);

/***********************************************************************************************************************
* Function Name : R_MTR_GetStatus
* Description   : Get status of motor control system
* Arguments     : None
* Return Value  : Motor status
***********************************************************************************************************************/
uint8_t  R_MTR_GetStatus(void);

/***********************************************************************************************************************
* Function Name : R_MTR_GetErrorStatus
* Description   : Get status of motor error
* Arguments     : None
* Return Value  : g_st_120.u2_error_status - Error status
***********************************************************************************************************************/
uint16_t R_MTR_GetErrorStatus(void);

/***********************************************************************************************************************
* Function Name : R_MTR_GetDir
* Description   : Get rotation direction
* Arguments     : None
* Return Value  : g_st_120.u1_dir - Rotation direction
***********************************************************************************************************************/
uint8_t R_MTR_GetDir(void);

/***********************************************************************************************************************
* Function Name : R_MTR_SetSpeed
* Description   : Set speed reference
* Arguments     : s2_ref_speed_rpm - Speed reference[rpm]
* Return Value  : u1_stop_req - stop request flag
***********************************************************************************************************************/
uint8_t R_MTR_SetSpeed(int16_t s2_ref_speed_rpm);

/***********************************************************************************************************************
* Function Name : R_MTR_ChargeCapacitor
* Description   : Wait for charging capacitor
* Arguments     : None
* Return Value  : u2_charge_cap_error - charge capacitor timeout error
***********************************************************************************************************************/
uint16_t R_MTR_ChargeCapacitor(void);

/***********************************************************************************************************************
* Function Name : R_MTR_UpdatePolling
* Description   : Polling u1_trig_enable_write to update configurations and commands
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MTR_UpdatePolling(void);

#endif /* MTR_DRIVER_ACCESS_H */
