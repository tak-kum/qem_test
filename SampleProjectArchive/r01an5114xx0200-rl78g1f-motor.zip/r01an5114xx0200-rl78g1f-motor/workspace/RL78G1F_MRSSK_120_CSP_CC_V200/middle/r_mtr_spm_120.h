/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_spm_hall_120.h
* Description : Definitions of the processing of a motor control layer
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef MTR_SPM_HALL_120_H
#define MTR_SPM_HALL_120_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"
#include "r_mtr_parameter.h"
#include "r_mtr_statemachine.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define     MTR_TIMEOUT_CNT              (200)       /* undetected time = MTR_TIMEOUT_CNT * 1[ms] */
#define     MTR_INIT_CNT_CARRIER         (300)       /* initial value of pre carrier count */
#define     MTR_LIMIT_SPEED_RAD          (MP_POLE_PAIRS * MTR_TWOPI_60 * CP_LIMIT_SPEED_RPM)
                                                     /* limit speed [rad/s] */

#if (MTRCONF_SENSOR_MODE == HALL)
#define     MTR_HALL2OL_REV_SPEED_RAD     (FIX_fromfloat(CP_HALL2OL_REV_SPEED_RPM * PU_SF_AFREQ, MTR_Q_AFREQ))
                                                     /* when rotor reverses, voltage state is changeed to MANUAL */
#endif

#if (MTRCONF_SENSOR_MODE == LESS)
#define     MTR_PHASE_ADV                (0)         /* advanced phase */
#define     MTR_PHASE_DLY                (1)         /* delayed phase */

#define     MTR_OL2LESS_ZC_CNT           (3)         /* number of zerocross to cange in sensorless control */
#define     MTR_AVOID_COMMUTATION        (4)         /* avoid judgement for zerocross because of switching current */
#define     MTR_OL2LESS_BEMF_THRESH      (3)         /* thereshold bemf voltage [ADC] */

#define     MTR_LESS2OL_HYSTERESIS       (50)        /* hystreresis of change speed between sensorless control
                                                                                                 and open-loop drive */
#define     MTR_DRAW_IN_1ST_PATTERN      (1)         /* 1st draw-in pattern */
#define     MTR_DRAW_IN_2ND_PATTERN      (2)         /* 2nd draw-in pattern */
#endif

/* parameters converted into fixed decimal [PU] */
#define     MTR_PU_Q_OVERVOLTAGE_LIMIT   (FIX_fromfloat(IP_OVERVOLTAGE_LIMIT * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
#define     MTR_PU_Q_UNDERVOLTAGE_LIMIT  (FIX_fromfloat(IP_UNDERVOLTAGE_LIMIT * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
#define     MTR_PU_Q_SPEED_LIMIT         (FIX_fromfloat(MTR_LIMIT_SPEED_RAD * PU_SF_AFREQ, MTR_Q_AFREQ))
#define     MTR_PU_Q_MCU_ON_V            (FIX_fromfloat(MTR_MCU_ON_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
#define     MTR_PU_Q_MAX_DRIVE_V         (FIX_fromfloat(MTR_MAX_DRIVE_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
#define     MTR_PU_Q_MIN_DRIVE_V         (FIX_fromfloat(MTR_MIN_DRIVE_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))

/* value of hall pattern (CW) */
#define     MTR_PATTERN_CW_V_U           (2)          /* V phase to U phase */
#define     MTR_PATTERN_CW_W_U           (3)          /* W phase to U phase */
#define     MTR_PATTERN_CW_W_V           (1)          /* W phase to V phase */
#define     MTR_PATTERN_CW_U_V           (5)          /* U phase to V phase */
#define     MTR_PATTERN_CW_U_W           (4)          /* U phase to W phase */
#define     MTR_PATTERN_CW_V_W           (6)          /* V phase to W phase */
#if (MTRCONF_SENSOR_MODE == HALL)
/* value of hall pattern (CCW) */
#define     MTR_PATTERN_CCW_V_U          (5)          /* V phase to U phase */
#define     MTR_PATTERN_CCW_V_W          (1)          /* V phase to W phase */
#define     MTR_PATTERN_CCW_U_W          (3)          /* U phase to W phase */
#define     MTR_PATTERN_CCW_U_V          (2)          /* U phase to V phase */
#define     MTR_PATTERN_CCW_W_V          (6)          /* W phase to V phase */
#define     MTR_PATTERN_CCW_W_U          (4)          /* W phase to U phase */
#elif (MTRCONF_SENSOR_MODE == LESS)
/* value of sensorless pattern (CCW) */
#define     MTR_PATTERN_CCW_V_U          (3)          /* V phase to U phase */
#define     MTR_PATTERN_CCW_V_W          (2)          /* V phase to W phase */
#define     MTR_PATTERN_CCW_U_W          (6)          /* U phase to W phase */
#define     MTR_PATTERN_CCW_U_V          (4)          /* U phase to V phase */
#define     MTR_PATTERN_CCW_W_V          (5)          /* W phase to V phase */
#define     MTR_PATTERN_CCW_W_U          (1)          /* W phase to U phase */
#endif

#define     MTR_PATTERN_NUM              (6)          /* number of voltage pattern */

/***********************************************************************************************************************
Macro definitions for sequence control
***********************************************************************************************************************/
/* error status */
#define     MTR_ERROR_NONE              (0x00)
#define     MTR_ERROR_OVER_CURRENT      (0x01)
#define     MTR_ERROR_OVER_VOLTAGE      (0x02)
#define     MTR_ERROR_OVER_SPEED        (0x04)
#define     MTR_ERROR_HALL_TIMEOUT      (0x08)
#define     MTR_ERROR_BEMF_TIMEOUT      (0x10)
#define     MTR_ERROR_HALL_PATTERN      (0x20)
#define     MTR_ERROR_BEMF_PATTERN      (0x40)
#define     MTR_ERROR_UNDER_VOLTAGE     (0x80)
#define     MTR_ERROR_UNKNOWN           (0xff)

/* draw-in status */
#define     MTR_DRAW_IN_NONE            (0)
#define     MTR_DRAW_IN_1ST             (1)
#define     MTR_DRAW_IN_2ND             (2)
#define     MTR_DRAW_IN_FINISH          (3)

/* speed reference status */
#define     MTR_SPEED_ZERO_CONST        (0)
#define     MTR_SPEED_MANUAL            (1)

/* voltage reference status */
#define     MTR_V_ZERO_CONST            (0)
#define     MTR_V_MANUAL                (1)
#define     MTR_V_PI_OUTPUT             (2)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* PI control structure */
typedef struct
{
    int16_t     s2_err;                        /* difference between reference and estimated speed */
    int16_t     s2_kp;                         /* Speed PI proportional gain */
    int16_t     s2_kidt;                       /* Speed PI integral gain * dt */
    int16_t     s2_limit;                      /* limit voltage in PI control */
    int32_t     s4_pre_refp;                   /* previous proportional term */
} st_mtr_pi_control_t;

#if (MTRCONF_SENSOR_MODE == HALL)
/* Hall-effect-sensor control structure */
typedef struct
{
    uint16_t    u2_hall_signal;                /* Hall signal pattern */
    uint16_t    u2_flag_1st_interrupt;         /* flag for first hall interruption */
    int16_t     s2_start_ref_v;                /* openloop start reference voltage */
} st_mtr_hall_control_t;

#elif (MTRCONF_SENSOR_MODE == LESS)
/* structure for transition from openloop drive into sensorless control */ 
typedef struct
{
    uint16_t    u2_flag_change;                /* transition into sensorless controll flag */
    uint16_t    u2_zc_flag;                    /* zerocross flag */
    uint16_t    u2_zc_cnt;                     /* counter for zerocross */
    uint16_t    u2_flag_change_speed;          /* exceed change_speed_rad flag */
    uint16_t    u2_rotor_pos;                  /* position of rotor : advanced / delayed */

    int16_t     s2_change_speed_rad;           /* speed allowed to transition into sensorless controll [PU] */
    int16_t     s2_ref_speed_rad_buf;          /* reference speed buffer [PU] */
    int16_t     s2_ramp_speed_rad;             /* acceleration at transition into sensorless control [PU] */
} st_mtr_ol2less_t;

/* sensorless control structure */
typedef struct
{
    uint8_t     u1_state_draw_in;              /* draw in the rotor mode */
    uint8_t     u1_flag_pattern_change;        /* voltage pattern change request flag */

    uint16_t    u2_bemf_delay;                 /* delay count as 30 degrees */
    uint16_t    u2_bemf_signal;                /* estimated pattern of BEMF */
    uint16_t    u2_pre_bemf_signal;            /* previous estimated pattern of BEMF */
    uint16_t    u2_cnt_ol_speed;               /* calculated period for openloop pattern change */
    uint16_t    u2_ol_pattern_period;          /* counter for pattern change in oppenloop drive */
    uint16_t    u2_cnt_draw_in;                /* counter for draw-in */
    uint16_t    u2_v_const_period;             /* voltage constant period at draw-in */
    uint16_t    u2_ol_v_pattern;               /* voltage pattern for openloop drive*/
    uint16_t    u2_ol_v_pattern_num;           /* selecting pattern number for openloop drive */
    uint16_t    u2_cnt_carrier;                /* counter for carrier interrupt */
    uint16_t    u2_pre_cnt_carrier;            /* previous carrier interrupt count */

    int16_t     s2_less2ol_speed_rad;          /* speed to change from sensorless control to open-loop drive */
    int16_t     s2_vu_ad;                      /* U phase voltage */
    int16_t     s2_vv_ad;                      /* V phase voltage */
    int16_t     s2_vw_ad;                      /* W phase voltage */
    int16_t     s2_vn_ad;                      /* neutral voltage */
    int16_t     s2_draw_in_ref_v;              /* voltage reference for draw-in */
    int16_t     s2_ol_ref_v;                   /* start reference voltage */
    int16_t     s2_angle_shift_adjust;         /* adjusting angle */

    st_mtr_ol2less_t             st_ol2less;   /* transition into senroless control structure */
} st_mtr_sensorless_control_t;
#endif

/* 120 degree control structure */
typedef struct
{
    uint8_t     u1_ref_dir;                    /* rotation direction reference (0:CW,1:CCW) */
    uint8_t     u1_dir;                        /* rotation direction (0:CW,1:CCW) */
    uint8_t     u1_flag_charge_cap;            /* flag for capacitor charging completed */
    uint16_t    u1_flag_pattern_error;         /* flag for Hall/BEMF pattern error */

    uint16_t    u2_run_mode;                   /* run mode */
    uint16_t    u2_error_status;               /* error status */
    uint16_t    u2_state_speed_ref;            /* speed reference mode */
    uint16_t    u2_state_voltage_ref;          /* voltage reference mode */
    uint16_t    u2_speed_timer_cnt;            /* value of timer counter (TAU) */
    uint16_t    u2_pre_speed_timer_cnt;        /* previous value of timer counter (TAU) */
    uint16_t    u2_timer_cnt_buff[6];          /* counts for 60 degrees */
    uint16_t    u2_v_pattern_ring_buff;        /* buffer counter for timer_cnt_buff */
    uint16_t    u2_v_pattern;                  /* voltage pattern */
    uint16_t    u2_pwm_duty;                   /* PWM duty : No scaling */
    uint16_t    u2_cnt_timeout;                /* counter for timeout error */
    uint16_t    u2_first_rotation_cnt;         /* count first 6 pattern changes for speed calculation */
    uint16_t    u2_timer_cnt_sum;              /* sum of counts in 360 degrees (electrical angle)*/

    int16_t     s2_speed_rad;                  /* motor speed */
    int16_t     s2_ref_speed_rad;              /* motor speed reference */
    int16_t     s2_ref_speed_rad_ctrl;         /* motor speed reference for control */
    int16_t     s2_ramp_limit_speed_rad;       /* limit of acceleration */
    int16_t     s2_vdc_ad;                     /* bus voltage */
    int16_t     s2_ref_v;                      /* reference voltage */
    int16_t     s2_ref_v_ctrl;                 /* reference voltage for control */
    int16_t     s2_ramp_limit_v;               /* limit of rate of voltage change */

    st_mtr_statemachine_t        st_stm;       /* Action structure */
    st_mtr_parameter_t           st_motor;     /* Motor parameters */
    st_mtr_pi_control_t          st_pi_speed;  /* struct for speed PI control */

#if (MTRCONF_SENSOR_MODE == HALL)
    st_mtr_hall_control_t        st_hall;      /* hall control */
#elif (MTRCONF_SENSOR_MODE == LESS)
    st_mtr_sensorless_control_t  st_less;      /* sensorless control */
#endif
} st_mtr_120_control_t;

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_120_motor_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : st_120 - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_120_motor_default_init(st_mtr_120_control_t *);

/***********************************************************************************************************************
* Function Name : mtr_120_motor_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : st_120 - The pointer to the 120 degree control data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_120_motor_reset(st_mtr_120_control_t *);

#endif /* MTR_SPM_HALL_120_H */
