/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_statemachine.h
* Description : Definitions of the state machine for motor drive system
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_STATEMACHINE_H
#define R_MTR_STATEMACHINE_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Drive modes (state) */
#define     MTR_MODE_INIT               (0x00)
#define     MTR_MODE_DRIVE              (0x01)
#define     MTR_MODE_STOP               (0x02)
#define     MTR_SIZE_STATE              (3)                     /* number of state */

/* Drive mode events */
#define     MTR_EVENT_STOP              (0x00)
#define     MTR_EVENT_DRIVE             (0x01)
#define     MTR_EVENT_ERROR             (0x02)
#define     MTR_EVENT_RESET             (0x03)
#define     MTR_SIZE_EVENT              (4)                     /* number of event */

/***********************************************************************************************************************
Global structures / type definitions
***********************************************************************************************************************/
/* State machine data structure */
typedef struct
{
    uint8_t       u1_status;                                    /* The current system status */
    uint8_t       u1_status_next;                               /* The next system status */
    uint8_t       u1_current_event;                             /* The current event index */
}st_mtr_statemachine_t;

/*
 * State machine action handler function definition
 * Arguments :  p_state_machine - the pointer to the state machine structure
 *              p_params - the pointer to the parameters
 * Return    :  the result of action
 *              0 - Success
 *              else - Error
 */
typedef void (*mtr_action_t)(st_mtr_statemachine_t *p_state_machine, void *p_params);

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_statemachine_init
* Description   : Initializes state machine for motor drive system
* Arguments     : p_state_machine   - the pointer to the state machine data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_statemachine_init(st_mtr_statemachine_t *p_state_machine);

/***********************************************************************************************************************
* Function Name : mtr_statemachine_reset
* Description   : Resets state machine
* Arguments     : p_state_machine   - the pointer to the state machine data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_statemachine_reset(st_mtr_statemachine_t *p_state_machine);

/***********************************************************************************************************************
* Function Name : mtr_statemachine_event
* Description   : Performs state transition and execute corresponding action when
*                 specified event happen
* Arguments     : p_state_machine   - the pointer to the state machine data structure
*                 p_object          - the pointer to parameters passed to the action handler
*                 u1_event          - the event index to be executed
*                       MTR_EVENT_INACTIVE  Stop the motor drive system
*                       MTR_EVENT_ACTIVE    Activate the motor drive system
*                       MTR_EVENT_ERROR     Throw an error and stop driving
*                       MTR_EVENT_RESET     Reset the configurations of motor drive system
* Return Value  : The error flags of the state machine
*                       BIT0: Event index is out of bound, please check the u1_event
*                       BIT1: State index is out of bound
*                       BIT2: Action error (value other than 0 returned from action);
***********************************************************************************************************************/
void mtr_statemachine_event(st_mtr_statemachine_t *p_state_machine, void *p_object, uint8_t u1_event);

/***********************************************************************************************************************
* Function Name : mtr_statemachine_get_status
* Description   : Gets the status of system
* Arguments     : p_state_machine - the pointer to the state machine data structure
* Return Value  : Status of system
***********************************************************************************************************************/
uint8_t mtr_statemachine_get_status(st_mtr_statemachine_t *p_state_machine);

/***********************************************************************************************************************
* Function Name : mtr_act_none
* Description   : The empty dummy function used to fill the blank in action table
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void   mtr_act_none(st_mtr_statemachine_t *p_state_machine, void *p_params);

/***********************************************************************************************************************
* Function Name : mtr_act_init
* Description   : Resets the configurations to default and clear error flags
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void   mtr_act_init(st_mtr_statemachine_t *p_state_machine, void *p_params);

/***********************************************************************************************************************
* Function Name : mtr_act_error
* Description   : Executes the post-processing (include stopping the PWM output) when an error has been detected
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void   mtr_act_error(st_mtr_statemachine_t *p_state_machine, void *p_params);

/***********************************************************************************************************************
* Function Name : mtr_act_drive
* Description   : Activates the motor control system and enables PWM output
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void   mtr_act_drive(st_mtr_statemachine_t *p_state_machine, void *p_params);

/***********************************************************************************************************************
* Function Name : mtr_act_stop
* Description   : Deactivates the motor control system and disables PWM output
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void   mtr_act_stop(st_mtr_statemachine_t *p_state_machine, void *p_params);

#endif /* R_MTR_STATEMACHINE_H */
