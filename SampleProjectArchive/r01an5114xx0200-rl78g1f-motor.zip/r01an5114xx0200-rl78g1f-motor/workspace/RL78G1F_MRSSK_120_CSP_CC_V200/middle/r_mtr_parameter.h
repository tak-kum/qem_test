/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_parameter.h
* Description : Definitions of parameters used in control
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_PARAMETER_H
#define R_MTR_PARAMETER_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define     MTR_SPEED_PI_LIMIT_V         (IP_INPUT_V)            /* speed PI output limit [V] */

/* conversion factor for speed calc(count -> rad/s) */
#define     MTR_SPEED_CALC_BASE          (125000 * MTR_TWOPI)
#define     MTR_PU_Q_SPEED_CALC_BASE       FIX32_fromfloat(MTR_SPEED_CALC_BASE * PU_SF_AFREQ, MTR_Q_AFREQ)

/* conversion factor for openloop (s/rad -> count) */
#define     MTR_OL_SPEED_CALC_BASE       (MTR_CARRIER_FREQ * 1000 * MTR_TWOPI / MTR_PATTERN_NUM)
#define     MTR_PU_Q_OL_SPEED_CALC_BASE       FIX32_fromfloat(MTR_OL_SPEED_CALC_BASE * PU_SF_AFREQ, MTR_Q_AFREQ)

/* conversion fctors for 1st rotation */
#define     MTR_PU_Q_SPEED_CALC_BASE_1ST (MTR_PU_Q_SPEED_CALC_BASE / 6)
#define     MTR_PU_Q_SPEED_CALC_BASE_2ND (MTR_PU_Q_SPEED_CALC_BASE / 3)
#define     MTR_PU_Q_SPEED_CALC_BASE_3RD (MTR_PU_Q_SPEED_CALC_BASE / 2)
#define     MTR_PU_Q_SPEED_CALC_BASE_4TH (MTR_PU_Q_SPEED_CALC_BASE * 2 / 3)
#define     MTR_PU_Q_SPEED_CALC_BASE_5TH (MTR_PU_Q_SPEED_CALC_BASE * 5 / 6)

#define     MTR_MAX_DRIVE_V              (IP_INPUT_V * 0.90f)    /* max output voltage [V] */
#define     MTR_MIN_DRIVE_V              (IP_INPUT_V * 0.0f)     /* min output voltage [V] */
#define     MTR_MCU_ON_V                 (IP_INPUT_V * 0.8)      /* MCU power on voltage [V] */

/***********************************************************************************************************************
Global structure
***********************************************************************************************************************/
/* motor parameter structure */
typedef struct
{
    uint16_t u2_mtr_pp;                            /* Number of pole pairs */
    int16_t  s2_mtr_r;                             /* Resistance [ohm] */
    int16_t  s2_mtr_ld;                            /* Inductance for d-axis [H] */
    int16_t  s2_mtr_lq;                            /* Inductance for q-axis [H] */
    int16_t  s2_mtr_m;                             /* Induced voltage constant [V s/rad] */
    int16_t  s2_mtr_j;                             /* Rotor inertia [kgm^2] */
} st_mtr_parameter_t;

/* data structure for input gains */
typedef struct
{
    int16_t  s2_speed_pi_kp;                       /* Speed PI proportional gain */
    int16_t  s2_speed_pi_kidt;                     /* Speed PI integral gain * dt */
} st_mtr_ctrl_gain_t;

#endif /* R_MTR_PARAMETER_H */