/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_statemachine.c
* Description : The state machine for motor drive system
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_common.h"
#include "r_mtr_statemachine.h"
#include "r_mtr_ctrl_rl78g1f.h"
#include "r_mtr_spm_120.h"

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
static uint8_t state_transition_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* Event / State         0:MTR_MODE_INIT, 1:MTR_MODE_DRIVE,  2:MTR_MODE_STOP */
/* 0:MTR_EVENT_STOP  */{   MTR_MODE_STOP,   MTR_MODE_STOP,     MTR_MODE_STOP  },
/* 1:MTR_EVENT_DRIVE */{   MTR_MODE_INIT,   MTR_MODE_DRIVE,    MTR_MODE_DRIVE },
/* 2:MTR_EVENT_ERROR */{   MTR_MODE_STOP,   MTR_MODE_STOP,     MTR_MODE_STOP  },
/* 3:MTR_EVENT_RESET */{   MTR_MODE_INIT,   MTR_MODE_DRIVE,    MTR_MODE_INIT  },};

static mtr_action_t action_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* Event / State         0:MTR_MODE_INIT,     1:MTR_MODE_DRIVE,  2:MTR_MODE_STOP */
/* 0:MTR_EVENT_STOP  */{   mtr_act_stop,       mtr_act_stop,       mtr_act_none  },
/* 1:MTR_EVENT_DRIVE */{   mtr_act_none,       mtr_act_none,       mtr_act_drive },
/* 2:MTR_EVENT_ERROR */{   mtr_act_error,      mtr_act_error,      mtr_act_error },
/* 3:MTR_EVENT_RESET */{   mtr_act_init,       mtr_act_none,       mtr_act_init  },};

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_statemachine_init
* Description   : Initializes state machine for motor drive system
* Arguments     : p_state_machine   - the pointer to the state machine data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_statemachine_init(st_mtr_statemachine_t *p_state_machine)
{
    mtr_statemachine_reset(p_state_machine);
} /* End of function mtr_statemachine_init */

/***********************************************************************************************************************
* Function Name : mtr_statemachine_reset
* Description   : Resets state machine
* Arguments     : p_state_machine   - the pointer to the state machine data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_statemachine_reset(st_mtr_statemachine_t *p_state_machine)
{
    p_state_machine->u1_status          = MTR_MODE_INIT;
    p_state_machine->u1_status_next     = MTR_MODE_INIT;
} /* End of function mtr_statemachine_reset */

/***********************************************************************************************************************
* Function Name : mtr_statemachine_event
* Description   : Performs state transition and execute corresponding action when
*                 specified event happen
* Arguments     : p_state_machine   - the pointer to the state machine data structure
*                 p_object          - the pointer to parameters passed to the action handler
*                 u1_event          - the event index to be executed
*                       MTR_EVENT_INACTIVE  Stop the motor drive system
*                       MTR_EVENT_ACTIVE    Activate the motor drive system
*                       MTR_EVENT_ERROR     Throw an error and stop driving
*                       MTR_EVENT_RESET     Reset the configurations of motor drive system
* Return Value  : None
***********************************************************************************************************************/
void mtr_statemachine_event(st_mtr_statemachine_t *p_state_machine, void *p_object, uint8_t u1_event)
{
    mtr_action_t func_action;

    /* Check if accessing state transition table out of bound */
    if (MTR_SIZE_EVENT <= u1_event)
    {
        /* Event is out of bound */
        u1_event = MTR_EVENT_ERROR;
    }
    if (MTR_SIZE_STATE <= p_state_machine->u1_status)
    {
        /* State is out of bound */
        u1_event = MTR_EVENT_ERROR;
        p_state_machine->u1_status = MTR_MODE_INIT;
    }

    /*
     * u1_current_event : Event happening
     * u1_status        : Current status
     * u1_status_next   : Status after action executed
     */
    p_state_machine->u1_current_event = u1_event;
    p_state_machine->u1_status_next   = state_transition_table[u1_event][p_state_machine->u1_status];

    /* Get action function from action table and execute action */
    func_action = action_table[u1_event][p_state_machine->u1_status];
    func_action(p_state_machine, p_object);

    p_state_machine->u1_status = p_state_machine->u1_status_next;
} /* End of function mtr_statemachine_event */

/***********************************************************************************************************************
* Function Name : mtr_statemachine_get_status
* Description   : Gets the status of system
* Arguments     : p_state_machine - the pointer to the state machine data structure
* Return Value  : Status of system
***********************************************************************************************************************/
uint8_t mtr_statemachine_get_status(st_mtr_statemachine_t *p_state_machine)
{
    return (p_state_machine->u1_status);
} /* End of function mtr_statemachine_get_status */

/***********************************************************************************************************************
* Function Name : mtr_act_none
* Description   : The empty dummy function used to fill the blank in action table
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_act_none(st_mtr_statemachine_t *st_stm, void *p_param)
{
    /* do nothing */

} /* End of function mtr_act_none */

/***********************************************************************************************************************
* Function Name : mtr_act_init
* Description   : Resets the configurations to default and clear error flags
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
void mtr_act_init(st_mtr_statemachine_t *st_stm, void *p_param)
{
    st_mtr_120_control_t *pfoc = p_param;

    mtr_120_motor_default_init(pfoc);

    mtr_statemachine_event(&pfoc->st_stm, &pfoc, MTR_EVENT_STOP);

} /* End of function mtr_act_reset */

/***********************************************************************************************************************
* Function Name : mtr_act_error
* Description   : Executes the post-processing (include stopping the PWM output) when an error has been detected
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_act_error(st_mtr_statemachine_t *st_stm, void *p_param)
{
    R_MTR_ctrl_stop();                                /* TRD output disable, disable Hall interrupts,
                                                          motor output port is off for motor control stop */
} /* End of function mtr_act_error */

/***********************************************************************************************************************
* Function Name : mtr_act_drive
* Description   : Activates the motor control system and enables PWM output
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_act_drive(st_mtr_statemachine_t *st_stm, void *p_param)
{
    st_mtr_120_control_t *pfoc = p_param;

    mtr_120_motor_reset(pfoc);                           /* initialize variables when motor control start */

} /* End of function mtr_act_active */

/***********************************************************************************************************************
* Function Name : mtr_act_stop
* Description   : Deactivates the motor control system and disables PWM output
* Arguments     : st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the 120 degree control structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_act_stop(st_mtr_statemachine_t *st_stm, void *p_param)
{

    R_MTR_ctrl_stop();                                   /* TRD output disable, disable Hall interrupts,
                                                             motor output port is off for motor control stop */

} /* End of function mtr_act_inactive */
