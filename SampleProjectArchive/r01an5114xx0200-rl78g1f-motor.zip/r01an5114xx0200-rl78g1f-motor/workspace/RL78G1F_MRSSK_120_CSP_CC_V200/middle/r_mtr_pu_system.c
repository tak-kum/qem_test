/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_pu_system.c
* Description : PU system module
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <math.h>
#include "r_mtr_config.h"
#include "r_mtr_common.h"
#include "r_mtr_pu_system.h"
#include "r_mtr_fixed.h"

/***********************************************************************************************************************
Private function definitions
***********************************************************************************************************************/
static inline int16_t mtr_flex_conv(mtr_frex_conv_t *, int16_t);     /* convert to PU units */

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
mtr_frex_conv_t st_conv_adc2voltage;         /* structure for conversion from ADC to voltage */ 
mtr_frex_conv_t st_conv_rpm2afreq_pu;        /* structure for conversion from rpm to rad/s */ 
mtr_frex_conv_t st_conv_afreq2rpm;           /* structure for conversion from rad/s to rpm */ 

/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_pu_system_init
* Description   : Initialize per-unit system modules
* Arguments     : f4_adc_voltage_scl - Scale factor (Bus Voltage[PU(V)] / Bus Voltage ADC[digit])
*               : u2_polepair - Number of pole pairs of motor
* Return Value  : None
***********************************************************************************************************************/
void mtr_pu_system_init(float f4_adc_voltage_scl, uint16_t u2_polepair)
{
    mtr_flex_conv_init(&st_conv_adc2voltage, 0, MTR_Q_VOLTAGE, 1, PU_SF_VOLTAGE * f4_adc_voltage_scl);
    mtr_flex_conv_init(&st_conv_rpm2afreq_pu,
                       0,
                       MTR_Q_AFREQ,
                       1,
                       PU_SF_AFREQ * ((float)u2_polepair * MTR_TWOPI_60)
    );
    mtr_flex_conv_init(&st_conv_afreq2rpm,
                       MTR_Q_AFREQ,
                       0,
                       1,
                       1.0f / (PU_SF_AFREQ * ((float)u2_polepair * MTR_TWOPI_60))
    );
} /* End of function mtr_pu_system_init */

/***********************************************************************************************************************
* Function Name : mtr_conv_vdc_pu
* Description   : Convert bus voltage A/D result [digit] to per-unit voltage[PU(V)]
* Arguments     : s2_voltage_adc - Result of bus voltage A/D conversion
* Return Value  : Bus voltage [PU(V)]
***********************************************************************************************************************/
int16_t mtr_conv_vdc_pu(int16_t s2_voltage_adc)
{
    return mtr_flex_conv(&st_conv_adc2voltage, s2_voltage_adc);
} /* End of function mtr_conv_vdc_pu */

/***********************************************************************************************************************
* Function Name : mtr_conv_rpm2rad_pu
* Description   : Convert mechanical speed[rpm] to electrical speed (angular frequency) [PU(rad/s)]
* Arguments     : s2_speed_rpm - Speed[rpm] to convert
* Return Value  : Electrical angular speed [PU(rad/s)]
***********************************************************************************************************************/
int16_t mtr_conv_rpm2rad_pu(int16_t s2_speed_rpm)
{
    return mtr_flex_conv(&st_conv_rpm2afreq_pu, s2_speed_rpm);
} /* End of function mtr_conv_rpm2rad_pu */

/***********************************************************************************************************************
* Function Name : mtr_conv_rad2rpm_pu
* Description   : Convert electrical speed [PU(rad/s)] to mechanical speed[rpm]
* Arguments     : s2_ele_speed_pu - Speed[PU(rad/s)] to convert
* Return Value  : Mechanical speed [rpm]
***********************************************************************************************************************/
int16_t mtr_conv_rad2rpm_pu(int16_t s2_ele_speed_pu)
{
    return mtr_flex_conv(&st_conv_afreq2rpm, s2_ele_speed_pu);
} /* End of function mtr_conv_rad2rpm_pu */

/***********************************************************************************************************************
* Function Name : mtr_flex_conv_init
* Description   : Initialize flexible converter module to calculate (input) * (scale factor)
* Arguments     : (mtr_frex_conv_t*)st_conv - Pointer to converter structure
*                 (int8_t)s1_in_q - Q-format of input
*                 (int8_t)s1_out_q - Q-format of output
*                 (int8_t)s1_margin_q - Margin[bits] when calculate fixed point scale factor
*                 (float)f4_sf - Scale factor
* Return Value  : None
***********************************************************************************************************************/
void mtr_flex_conv_init(mtr_frex_conv_t *st_conv, int8_t s1_in_q, int8_t s1_out_q, int8_t s1_margin_q, float f4_sf)
{
    float temp;

    temp = log10f(f4_sf) * INV_LOG10_2;

    st_conv->s1_sf_q = 15 - (int8_t)ceilf(temp) - s1_margin_q;
    st_conv->s1_rsft = s1_in_q + st_conv->s1_sf_q - s1_out_q;
    st_conv->s2_sf = (int16_t)(f4_sf * (float)((int32_t)1 << st_conv->s1_sf_q));
} /* End of function mtr_flex_conv_init */

/***********************************************************************************************************************
* Function Name : mtr_flex_conv
* Description   : Calculate (input) * (predefined scale factor)
* Arguments     : (mtr_frex_conv_t*)st_conv - Pointer to converter structure
*                 (int16_t)s2_input - Input value
* Return Value  : Conversion value
***********************************************************************************************************************/
int16_t mtr_flex_conv(mtr_frex_conv_t *st_conv, int16_t s2_input)
{
    switch (st_conv->s1_rsft)
    {
        case 0:
            return (int16_t)((int32_t)s2_input * st_conv->s2_sf);

        case 1:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 1);

        case 2:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 2);

        case 3:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 3);

        case 4:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 4);

        case 5:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 5);

        case 6:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 6);

        case 7:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 7);

        case 8:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 8);

        case 9:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 9);

        case 10:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 10);

        case 11:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 11);

        case 12:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 12);

        case 13:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 13);

        case 14:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 14);

        case 15:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 15);

        case 16:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 16);

        case 17:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 17);

        case 18:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 18);

        case 19:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 19);

        case 20:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 20);

        case 21:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 21);

        case 22:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 22);

        case 23:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 23);

        case 24:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 24);

        case 25:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 25);

        case 26:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 26);

        case 27:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 27);

        case 28:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 28);

        case 29:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 29);

        case 30:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 30);

        case 31:
            return (int16_t)(((int32_t)s2_input * st_conv->s2_sf) >> 31);

        default:
            return 0;
    }
} /* End of function mtr_flex_conv */
