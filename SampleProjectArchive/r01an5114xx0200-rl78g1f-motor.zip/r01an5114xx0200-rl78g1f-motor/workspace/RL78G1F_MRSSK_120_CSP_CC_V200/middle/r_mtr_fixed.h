/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_fixed.h
* Description : Defines of Q-format used in fixed point arithmetic
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

#ifndef R_MTR_FIXED_H
#define R_MTR_FIXED_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Basic physics quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define        MTR_Q_CURRENT             (12)           /* Q-format of current */
#define        MTR_Q_VOLTAGE             (14)           /* Q-format of voltage */
#define        MTR_Q_AFREQ               (13)           /* Q-format of angular frequency */
#define        MTR_Q_FREQ                (MTR_Q_AFREQ)  /* Q-format of frequency */
#define        MTR_Q_RES                 (15)           /* Q-format of resistance */
#define        MTR_Q_IND                 (15)           /* Q-format of inductance */
#define        MTR_Q_FLUX                (12)           /* Q-format of induced voltage constant */
#define        MTR_Q_INERTIA             (7)            /* Q-format of inertia */
#define        MTR_Q_SPEED_KP            (14)           /* Q-format of speed PI proportional gain */
#define        MTR_Q_SPEED_KIDT          (15)           /* Q-format of speed PI (integral gain * period) */

/* Number of bits to left shift, (KIDT * omega) = voltage << (lsft) */
#define        LSFT_VOLTAGE_2KIDT_AFREQ  (MTR_Q_SPEED_KIDT + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
/* Number of bits to right shift, V = (KP * omega) >> (rsft) */
#define        RSFT_AFREQ_KP_2VOLTAGE  (MTR_Q_SPEED_KP + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
/* Number of bits to right shift, V = (KIDT * omega) >> (rsft) */
#define        RSFT_AFREQ_KIDT_2VOLTAGE  (MTR_Q_SPEED_KIDT + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
/* Number of bits to right shift, V = (flux * omega) >> (rsft) */
#define        RSFT_AFREQ_FLUX_2VOLTAGE  (MTR_Q_FLUX + MTR_Q_AFREQ - MTR_Q_VOLTAGE)

#endif /* R_MTR_FIXED_H */