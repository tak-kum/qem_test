/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_interrupt.c
* Description : The interrupt handler
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"
#include "r_mtr_common.h"
#include "r_mtr_ics.h"
#include "r_dsp.h"
#include "r_mtr_parameter.h"
#include "r_mtr_pu_system.h"
#include "r_mtr_fixed.h"
#include "r_mtr_spm_120.h"
#include "r_mtr_driver_access.h"
#include "r_mtr_ctrl_rl78g1f.h"
#include "r_mtr_statemachine.h"

/****** for ICS ******/
#include "ics_RL78G1F_Lx.h"
/*********************/

/***********************************************************************************************************************
Interrupt vector definitions
***********************************************************************************************************************/
#pragma interrupt mtr_over_current_interrupt     ( vect = INTP0   )
#pragma interrupt mtr_carrier_interrupt          ( vect = INTTRD0 )

#if (MTRCONF_SENSOR_MODE == HALL)
#pragma interrupt mtr_1ms_interrupt_hall         ( vect = INTTM00 )
#pragma interrupt mtr_hall_u_interrupt           ( vect = INTP1   )
#pragma interrupt mtr_hall_v_interrupt           ( vect = INTP2   )
#pragma interrupt mtr_hall_w_interrupt           ( vect = INTP3   )

#elif (MTRCONF_SENSOR_MODE == LESS)
#pragma interrupt mtr_1ms_interrupt_less         ( vect = INTTM00 )
#pragma interrupt mtr_delay_interrupt            ( vect = INTTM03 )
#endif

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
st_mtr_120_control_t g_st_120;                      /* structure of 120 degree control */

/* array of voltage pattern for openloop drive */
const uint16_t   g_u2_ol_v_pattern_table[2][7] = {
               /************  CW  ************/
                        {0,
                         MTR_PATTERN_CW_V_U,        /* 2 */
                         MTR_PATTERN_CW_W_U,        /* 3 */
                         MTR_PATTERN_CW_W_V,        /* 1 */
                         MTR_PATTERN_CW_U_V,        /* 5 */
                         MTR_PATTERN_CW_U_W,        /* 4 */
                         MTR_PATTERN_CW_V_W},       /* 6 */
               /************  CCW  ************/  
                        {0,
                         MTR_PATTERN_CCW_V_U,       /* 3 */
                         MTR_PATTERN_CCW_V_W,       /* 2 */
                         MTR_PATTERN_CCW_U_W,       /* 6 */
                         MTR_PATTERN_CCW_U_V,       /* 4 */
                         MTR_PATTERN_CCW_W_V,       /* 5 */
                         MTR_PATTERN_CCW_W_U}       /* 1 */        
                 };

/* array of chopping pattern */
const uint16_t g_u2_chopping_pattern_table[2][6] = {
#if (MTRCONF_PWM_MODE == NON_COMPLEMENTARY)
               /* non-complementary chopping */
               /***********   CW   ***********/
                        {MTR_WP_PWM_VN_ON,          /* 6 */
                         MTR_UP_PWM_VN_ON,          /* 1 */
                         MTR_UP_PWM_WN_ON,          /* 2 */
                         MTR_VP_PWM_WN_ON,          /* 4 */
                         MTR_VP_PWM_UN_ON,          /* 3 */
                         MTR_WP_PWM_UN_ON},         /* 5 */
                /***********   CCW   ***********/
                        {MTR_WP_PWM_VN_ON,          /* 6 */
                         MTR_WP_PWM_UN_ON,          /* 5 */
                         MTR_VP_PWM_UN_ON,          /* 3 */
                         MTR_VP_PWM_WN_ON,          /* 4 */
                         MTR_UP_PWM_WN_ON,          /* 2 */
                         MTR_UP_PWM_VN_ON}          /* 1 */

#elif (MTRCONF_PWM_MODE == COMPLEMENTARY)
               /* complementary chopping */
               /***********   CW   ***********/
                        {MTR_W_PWM_VN_ON,           /* 18 */
                         MTR_U_PWM_VN_ON,           /* 13 */
                         MTR_U_PWM_WN_ON,           /* 14 */
                         MTR_V_PWM_WN_ON,           /* 16 */
                         MTR_V_PWM_UN_ON,           /* 15 */
                         MTR_W_PWM_UN_ON},          /* 17 */
               /***********   CCW   ***********/
                        {MTR_W_PWM_VN_ON,           /* 18 */
                         MTR_W_PWM_UN_ON,           /* 17 */
                         MTR_V_PWM_UN_ON,           /* 15 */
                         MTR_V_PWM_WN_ON,           /* 16 */
                         MTR_U_PWM_WN_ON,           /* 14 */
                         MTR_U_PWM_VN_ON}           /* 13 */
#endif
                 };

#ifdef ICS_USE
/****** for ICS ******/
static uint8_t   g_u1_cnt_ics;                   /* counter for period of calling "ics_watchpoint" */
/*********************/
#endif

/***********************************************************************************************************************
Private functions definitions
***********************************************************************************************************************/
/* speed calculation */
#pragma inline mtr_speed_calc
static void mtr_speed_calc(void);
/* set chopping pattern */
#pragma inline mtr_set_chopping_pattern
static void mtr_set_chopping_pattern(uint16_t);
/* ICS process*/
#pragma inline mtr_ics_interrupt_process
void mtr_ics_interrupt_process(void);
/* set reference speed for control */
#pragma inline mtr_set_speed_ref
static void mtr_set_speed_ref(void);
/* set reference voltage for control */
#pragma inline mtr_set_voltage_ref
static void mtr_set_voltage_ref(void);
/* PI control calculation */
#pragma inline mtr_pi_ctrl
static int16_t mtr_pi_ctrl(st_mtr_pi_control_t *);
/* duty calculation */
#pragma inline mtr_duty_calc
static uint16_t mtr_duty_calc(int16_t, int16_t);
/* get absolute value */
#pragma inline mtr_abs
static int16_t mtr_abs(int16_t s2_value);
/* limit process*/
#pragma inline mtr_limit_value
static int16_t mtr_limit_value(int16_t, int16_t);
/* error check */
#pragma inline mtr_error_check
static void mtr_error_check(void);

#if (MTRCONF_SENSOR_MODE == HALL)
/* get hall signal and set voltage pattern */
#pragma inline mtr_hall_signal_set
static void mtr_hall_signal_set(void);
/* control process for hall interrupt */
#pragma inline mtr_hall_signal_process
static void mtr_hall_signal_process(void);

#elif (MTRCONF_SENSOR_MODE == LESS)
/* voltage pattern set at draw-in */
#pragma inline mtr_draw_in_pattern_set
static void mtr_draw_in_pattern_set(void);
/* estimate rotor position from bemf signal */
#pragma inline mtr_detect_zerocross
static uint16_t mtr_detect_zerocross(st_mtr_sensorless_control_t *, uint16_t *);
/* driving process at opeenloop */
#pragma inline mtr_drive_openloop
static void mtr_drive_openloop(void);
/* calculate delay count */
#pragma inline mtr_set_angle_shift
static void mtr_set_angle_shift(void);
/* start delay timer */
#pragma inline mtr_start_delay_timer
static void mtr_start_delay_timer(uint16_t u2_delay_cnt);
/* stop delay timer */
#pragma inline mtr_stop_delay_timer
static void mtr_stop_delay_timer(void);
/* set voltage pattern at opeenloop */
#pragma inline mtr_openloop_pattern_set
static uint8_t mtr_openloop_pattern_set(void);
/* control for transition from openloop to sensorless control */
#pragma inline mtr_ol2less_ctrl
static void mtr_ol2less_ctrl(void);
/* get bemf voltage */
#pragma inline mtr_get_bemf_voltage
static int16_t mtr_get_bemf_voltage(void);
/* phase of control */
#pragma inline mtr_openloop_phase_ctrl
static void mtr_openloop_phase_ctrl(void);
#endif

/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_over_current_interrupt
* Description   : Over current interrupt(INTP0)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_over_current_interrupt(void)
{
    MTR_OC_INTR_MASK = MTR_DISABLE_OC_INTR;                /* INTP0 interrupt servicing disabled */

    R_MTR_ExecEvent(MTR_EVENT_ERROR);                      /* execute error event */

    g_st_120.u2_error_status |= MTR_ERROR_OVER_CURRENT;    /* error status update : over current error */
} /* End of function mtr_over_current_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_carrier_interrupt
* Description   : Carrier interrupt (Period:50us)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_carrier_interrupt(void)
{
#if (MTRCONF_SENSOR_MODE == HALL)
    g_st_120.s2_vdc_ad = R_MTR_get_adc(MTR_ADCCH_VDC);                                       /* get A/D value of Vdc */
EI();
    g_st_120.s2_vdc_ad = (int16_t)(g_st_120.s2_vdc_ad * MTR_PU_Q_VDC_SCALING);                     /* convert to [V] */
#endif

#if (MTRCONF_SENSOR_MODE == LESS)
    R_MTR_get_v_dcuvw_adc(&g_st_120.s2_vdc_ad, &g_st_120.st_less.s2_vu_ad);         /* get A/D value of Vdc,VU,VV,VW */

    g_st_120.u2_speed_timer_cnt = MTR_TAU1_CNT;                                       /* get TAU1count for speed calc*/
EI();
    g_st_120.s2_vdc_ad = (int16_t)(g_st_120.s2_vdc_ad * MTR_PU_Q_VDC_SCALING);                     /* convert to [V] */

    if (MTR_MODE_DRIVE == g_st_120.u2_run_mode)
    {
        if (MTR_DRAW_IN_FINISH != g_st_120.st_less.u1_state_draw_in)
        {
            /* set voltage pattern to draw in the rotor */
            mtr_draw_in_pattern_set();
        }
        else
        {
            /* estimate BEMF pattern and detect zerocross */
            g_st_120.st_less.u2_bemf_signal = mtr_detect_zerocross(&g_st_120.st_less, &g_st_120.u2_cnt_timeout);

            /* change from open-loop drive to PI control */
            mtr_ol2less_ctrl();

            /*** When need to change pattern ***/
            if (MTR_SET == g_st_120.st_less.u1_flag_pattern_change)
            {
                /* speed calculation */
                mtr_speed_calc();
            }

            /* openloop drive */
            if (MTR_V_MANUAL == g_st_120.u2_state_voltage_ref)
            {
                /* set voltage pattern for openloop drive */
                mtr_drive_openloop();
            }
            else if (MTR_V_PI_OUTPUT == g_st_120.u2_state_voltage_ref)
            {
                /*** When need to change pattern ***/
                if (MTR_SET == g_st_120.st_less.u1_flag_pattern_change)
                {
                    /* set shift value (delay time) */
                    mtr_set_angle_shift();
                    /* set voltage pattern */
                    mtr_set_chopping_pattern(g_st_120.st_less.u2_bemf_signal);
                    /* set change voltage pattern after delay count */
                    mtr_start_delay_timer(g_st_120.st_less.u2_bemf_delay);
                }
            }
            else
            {
                /* do nothing */
            }
            g_st_120.st_less.u1_flag_pattern_change = MTR_CLR;
        }
    }

#endif /* SENSORLESS */

#ifdef ICS_USE
    mtr_ics_interrupt_process();
#endif

    mtr_clear_trd0_imfa();                              /* clear compare match flag A */

} /* End of function mtr_carrier_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_speed_calc
* Description   : Calculate motor speed
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_speed_calc(void)
{
    uint16_t u2_temp;

    /* calculate the difference of timer */
    if (g_st_120.u2_pre_speed_timer_cnt < g_st_120.u2_speed_timer_cnt)
    {
        u2_temp = g_st_120.u2_speed_timer_cnt - g_st_120.u2_pre_speed_timer_cnt;
    }
    else
    {
        u2_temp = g_st_120.u2_speed_timer_cnt + (0xFFFF - g_st_120.u2_pre_speed_timer_cnt);
    }

    /* speed calculation */
    if (0 == g_st_120.u2_first_rotation_cnt)
    {
        /* calculate speed from timer count for one rotation with rounding formula (electric angle) */
        g_st_120.u2_timer_cnt_sum -= g_st_120.u2_timer_cnt_buff[g_st_120.u2_v_pattern_ring_buff];
        g_st_120.u2_timer_cnt_buff[g_st_120.u2_v_pattern_ring_buff] = u2_temp;
        g_st_120.u2_timer_cnt_sum += u2_temp;
        g_st_120.s2_speed_rad = (int16_t)((MTR_PU_Q_SPEED_CALC_BASE + (g_st_120.u2_timer_cnt_sum >> 1))
                                                                                          / g_st_120.u2_timer_cnt_sum);
    }
    else
    {
        /* calculate speed for first rotation with rounding formula (electric angle) */
        switch (g_st_120.u2_first_rotation_cnt)
        {
            case 6:           /* 60 degrees */
                g_st_120.u2_timer_cnt_buff[0] = u2_temp;
                g_st_120.u2_timer_cnt_sum = u2_temp;
                g_st_120.s2_speed_rad = (int16_t)((MTR_PU_Q_SPEED_CALC_BASE_1ST + (g_st_120.u2_timer_cnt_sum >> 1))
                                                                                          / g_st_120.u2_timer_cnt_sum);
                g_st_120.u2_first_rotation_cnt--;
            break;

            case 5:           /* 120 degrees */
                g_st_120.u2_timer_cnt_buff[1] = u2_temp;
                g_st_120.u2_timer_cnt_sum += u2_temp;
                g_st_120.s2_speed_rad = (int16_t)((MTR_PU_Q_SPEED_CALC_BASE_2ND + (g_st_120.u2_timer_cnt_sum >> 1))
                                                                                          / g_st_120.u2_timer_cnt_sum);
                g_st_120.u2_first_rotation_cnt--;
            break;

            case 4:           /* 180 degrees */
                g_st_120.u2_timer_cnt_buff[2] = u2_temp;
                g_st_120.u2_timer_cnt_sum += u2_temp;
                g_st_120.s2_speed_rad = (int16_t)((MTR_PU_Q_SPEED_CALC_BASE_3RD + (g_st_120.u2_timer_cnt_sum >> 1))
                                                                                          / g_st_120.u2_timer_cnt_sum);
                g_st_120.u2_first_rotation_cnt--;
            break;

            case 3:           /* 240 degrees */
                g_st_120.u2_timer_cnt_buff[3] = u2_temp;
                g_st_120.u2_timer_cnt_sum += u2_temp;
                g_st_120.s2_speed_rad = (int16_t)((MTR_PU_Q_SPEED_CALC_BASE_4TH + (g_st_120.u2_timer_cnt_sum >> 1))
                                                                                          / g_st_120.u2_timer_cnt_sum);
                g_st_120.u2_first_rotation_cnt--;
            break;

            case 2:           /* 300 degrees */
                g_st_120.u2_timer_cnt_buff[4] = u2_temp;
                g_st_120.u2_timer_cnt_sum += u2_temp;
                g_st_120.s2_speed_rad = (int16_t)((MTR_PU_Q_SPEED_CALC_BASE_5TH + (g_st_120.u2_timer_cnt_sum >> 1))
                                                                                          / g_st_120.u2_timer_cnt_sum);
                g_st_120.u2_first_rotation_cnt--;
            break;

            case 1:           /* 360 degrees */
                g_st_120.u2_timer_cnt_buff[5] = u2_temp;
                g_st_120.u2_timer_cnt_sum += u2_temp;
                g_st_120.s2_speed_rad = (int16_t)((MTR_PU_Q_SPEED_CALC_BASE + (g_st_120.u2_timer_cnt_sum >> 1))
                                                                                          / g_st_120.u2_timer_cnt_sum);
                g_st_120.u2_first_rotation_cnt--;
            break;

            default:
            /* do nothing */
            break;
        }
    }

    /* set ring buffer */
    g_st_120.u2_v_pattern_ring_buff++;
    if (g_st_120.u2_v_pattern_ring_buff > 5)
    {
        g_st_120.u2_v_pattern_ring_buff = 0;
    }

    /* when CCW, speed is set to negative value */
    if (MTR_CCW == g_st_120.u1_dir)
    {
        g_st_120.s2_speed_rad = -g_st_120.s2_speed_rad;
    }

    g_st_120.u2_pre_speed_timer_cnt = g_st_120.u2_speed_timer_cnt;     /* keep timer counter value */
} /* End of function mtr_speed_calc */

/***********************************************************************************************************************
* Function Name : mtr_set_chopping_pattern
* Description   : Set chopping pattern depending on voltage pattern
* Arguments     : u2_pattern - voltage pattern
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_chopping_pattern(uint16_t u2_pattern)
{
    /*** set voltage pattern ***/
    if (MTR_CW == g_st_120.u1_dir)              /* check rotation direction */
    {
        switch (u2_pattern)
        {
            case MTR_PATTERN_CW_W_V:            /* from W phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CW][0];
            break;

            case MTR_PATTERN_CW_U_V:            /* from U phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CW][1];
            break;

            case MTR_PATTERN_CW_U_W:            /* from U phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CW][2];
            break;

            case MTR_PATTERN_CW_V_W:            /* from V phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CW][3];
            break;

            case MTR_PATTERN_CW_V_U:            /* from V phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CW][4];
            break;

            case MTR_PATTERN_CW_W_U:            /* from W phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CW][5];
            break;

            default:                            /* Hall signal pattern error */
                g_st_120.u2_v_pattern = MTR_PATTERN_ERROR;
            break;
        }
    }
    else if (MTR_CCW == g_st_120.u1_dir)         /* check rotation direction */
    {
        switch (u2_pattern)
        {
            case MTR_PATTERN_CCW_W_V:           /* from W phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CCW][0];
            break;

            case MTR_PATTERN_CCW_W_U:           /* from W phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CCW][1];
            break;

            case MTR_PATTERN_CCW_V_U:           /* from V phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CCW][2];
            break;

            case MTR_PATTERN_CCW_V_W:           /* from V phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CCW][3];
            break;

            case MTR_PATTERN_CCW_U_W:           /* from U phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CCW][4];
            break;

            case MTR_PATTERN_CCW_U_V:           /* from U phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table[MTR_CCW][5];
            break;

            default:                            /* Hall signal pattern error */
                g_st_120.u2_v_pattern = MTR_PATTERN_ERROR;
            break;
        }
    }
    else
    {
        /* do nothing */
    }
} /* End of function mtr_set_chopping_pattern */

#ifdef ICS_USE
/***********************************************************************************************************************
* Function Name : mtr_ics_interrupt_process
* Description   : Call by interrupt process(Period interval: 250 [us])
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_ics_interrupt_process(void)
{
    g_u1_cnt_ics++;
    /* Decimation of ICS call */
    if (ICS_DECIMATION < g_u1_cnt_ics)
    {
DI();
        ics2_watchpoint();
EI();
        g_u1_cnt_ics = 0;
    }

    /* Update commands and configurations when trigger flag is set */
    R_MTR_UpdatePolling();

} /* End of function mtr_ics_interrupt_process */
#endif

/***********************************************************************************************************************
* Function Name : mtr_set_speed_ref
* Description   : Set reference speed
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_speed_ref(void)
{
    int16_t  s2_temp;
    int16_t  s2_ref_speed_rad_buff;

    s2_ref_speed_rad_buff = g_st_120.s2_ref_speed_rad_ctrl;

    switch (g_st_120.u2_state_speed_ref)
    {
        /* voltage constant, frequency no control */
        case MTR_SPEED_ZERO_CONST:
            s2_ref_speed_rad_buff = 0;
        break;

        /* Speed MANUAL control */
        case MTR_SPEED_MANUAL:
            s2_temp = g_st_120.s2_ref_speed_rad - s2_ref_speed_rad_buff;
            s2_temp = mtr_limit_value(s2_temp, g_st_120.s2_ramp_limit_speed_rad);           /* ramp limit */
            s2_ref_speed_rad_buff += s2_temp;
        break;

        default:
                /* do nothing */
        break;
    }

    /* set rotation direction */
    if (s2_ref_speed_rad_buff >= 0)
    {
        g_st_120.u1_dir = MTR_CW;
    }
    else
    {
        g_st_120.u1_dir = MTR_CCW;
    }

    g_st_120.s2_ref_speed_rad_ctrl = s2_ref_speed_rad_buff;
} /* End of function mtr_set_speed_ref */

/***********************************************************************************************************************
* Function Name : mtr_set_voltage_ref
* Description   : Set reference voltage
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_voltage_ref(void)
{
    int16_t s2_temp;
    int16_t s2_ref_v_buff;

    s2_ref_v_buff = g_st_120.s2_ref_v_ctrl;

    switch (g_st_120.u2_state_voltage_ref)
    {
        /* zero voltage constantly. */
        case MTR_V_ZERO_CONST:
            s2_ref_v_buff = 0;
        break;

        /* manual input */
        case MTR_V_MANUAL:
            s2_temp = g_st_120.s2_ref_v - s2_ref_v_buff;
            s2_temp = mtr_limit_value(s2_temp, g_st_120.s2_ramp_limit_v);           /* ramp limit */
            s2_ref_v_buff += s2_temp;
        break;

        /* PI control */
        case MTR_V_PI_OUTPUT:
            g_st_120.st_pi_speed.s2_err = (g_st_120.s2_ref_speed_rad_ctrl - g_st_120.s2_speed_rad);

            s2_ref_v_buff += mtr_pi_ctrl(&g_st_120.st_pi_speed);

        break;

        default:
                /* do nothing */
        break;
    }

    /* limit voltage */
    if (s2_ref_v_buff >  MTR_PU_Q_MAX_DRIVE_V)
    {
        s2_ref_v_buff =  MTR_PU_Q_MAX_DRIVE_V;
    }
    else if (s2_ref_v_buff < MTR_PU_Q_MIN_DRIVE_V)
    {
        s2_ref_v_buff = MTR_PU_Q_MIN_DRIVE_V;
    }
    else
    {
        /* do nothing */
    }

    g_st_120.s2_ref_v_ctrl = s2_ref_v_buff;

} /* End of function mtr_set_voltage_ref */

/***********************************************************************************************************************
* Function Name : mtr_pi_ctrl
* Description   : PI control (velocity form)
* Arguments     : PI control input structure
* Return Value  : PI control output value
***********************************************************************************************************************/
int16_t mtr_pi_ctrl(st_mtr_pi_control_t *pi_ctrl)
{
    int16_t s2_err, s2_kp, s2_kidt, s2_ref_v_delta;
    int32_t s4_refp, s4_refi, s4_pre_refp;

    s2_err      = pi_ctrl->s2_err;
    s2_kp       = pi_ctrl->s2_kp;
    s2_kidt     = pi_ctrl->s2_kidt;
    s4_pre_refp = pi_ctrl->s4_pre_refp;

    s4_refp = (int32_t)s2_err * s2_kp;                      /* proportional part */
    s4_refi = (int32_t)s2_err * s2_kidt;                    /* integral part */

    /* calculate variation of reference voltage */
    s2_ref_v_delta = (int16_t)((s4_refp - s4_pre_refp) >> RSFT_AFREQ_KP_2VOLTAGE)
                                     + (int16_t)(s4_refi >> RSFT_AFREQ_KIDT_2VOLTAGE);

    /* store proportional term */
    pi_ctrl->s4_pre_refp = s4_refp;

    /* correct sign of variation because speed is negative when rotating in CCW direction */
    if (MTR_CCW == g_st_120.u1_dir)
    {
        s2_ref_v_delta = -s2_ref_v_delta;
    }

    return (s2_ref_v_delta);
} /* End of function mtr_pi_ctrl */

/***********************************************************************************************************************
* Function Name : mtr_duty_calc
* Description   : Get duty
* Arguments     : s2_ref_v - Voltage reference [V]
*               : s2_vdc_ad - Vdc value [V]
* Return Value  : duty value
***********************************************************************************************************************/
uint16_t mtr_duty_calc(int16_t s2_ref_v, int16_t s2_vdc_ad)
{
    uint32_t u4_temp;

    /* duty caluculation with rounding formula */
    u4_temp = ((uint32_t)(32768 << MTR_Q_VOLTAGE) + (s2_vdc_ad >> 1)) / s2_vdc_ad;             /* 15 bits left shift */
    if (s2_vdc_ad < s2_ref_v)
    {
        s2_ref_v = s2_vdc_ad;
    }
    u4_temp = (s2_ref_v * u4_temp) >> MTR_Q_VOLTAGE;

#if (MTRCONF_PWM_MODE == NON_COMPLEMENTARY)
    u4_temp = (uint32_t)(MTR_CARRIER_SET * u4_temp) >> 15;                                     /* 15 bits right shift */
#elif (MTRCONF_PWM_MODE == COMPLEMENTARY)
    u4_temp = (uint32_t)(MTR_NDT_CARRIER_SET * u4_temp) >> 15;                                 /* 15 bits right shift */
    u4_temp += MTR_DEADTIME_SET;
#endif

    return ((uint16_t)u4_temp);
} /* End of function mtr_duty_calc */

/***********************************************************************************************************************
* Function Name : mtr_abs
* Description   : absolute value
* Arguments     : s2_value - Target value
* Return Value  : absolute value
***********************************************************************************************************************/
int16_t mtr_abs(int16_t s2_value)
{
    int16_t s2_temp;

    s2_temp = s2_value;

    /* keep s2_value as positive */
    if (0 > s2_temp)
    {
        s2_temp = -s2_temp;
    }

    return (s2_temp);
} /* End of function mtr_abs */

/***********************************************************************************************************************
* Function Name : mtr_limit_value
* Description   : Limit with absolute value
* Arguments     : s2_value - Target value, s2_limit_value - Limit value
* Return Value  : limited value
***********************************************************************************************************************/
int16_t mtr_limit_value(int16_t s2_value, int16_t s2_limit_value)
{
    int16_t s2_temp;

    s2_temp = s2_value;

    if (s2_value > s2_limit_value)
    {
        s2_temp = s2_limit_value;           /* when s2_temp is too large */
    }
    else if (s2_value < (- s2_limit_value))
    {
        s2_temp = -s2_limit_value;          /* when s2_temp is too small */
    }
    else
    {
        /* do nothing */
    }

    return (s2_temp);
} /* End of function mtr_limit_value */

/***********************************************************************************************************************
* Function Name : mtr_error_check
* Description   : Check error status
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_error_check(void)
{
    /*==================================*/
    /*     over voltage error check     */
    /*==================================*/
    if (g_st_120.s2_vdc_ad > MTR_PU_Q_OVERVOLTAGE_LIMIT)
    {
        g_st_120.u2_error_status |= MTR_ERROR_OVER_VOLTAGE;                      /* over voltage error */
    }

    /*===================================*/
    /*     under voltage error check     */
    /*===================================*/
    /* check "capacitor charge completed" */
    if (MTR_SET == g_st_120.u1_flag_charge_cap)
    {
        if (g_st_120.s2_vdc_ad < MTR_PU_Q_UNDERVOLTAGE_LIMIT)
        {
            g_st_120.u2_error_status |= MTR_ERROR_UNDER_VOLTAGE;                 /* under voltage error */
        }
    }

    /*================================*/
    /*     over speed error check     */
    /*================================*/
    /* Speed check is only performed at SPEED CHANGE state. */
    if (MTR_V_PI_OUTPUT == g_st_120.u2_state_voltage_ref)
    {
        if (mtr_abs(g_st_120.s2_speed_rad) > MTR_PU_Q_SPEED_LIMIT)
        {
            g_st_120.u2_error_status |= MTR_ERROR_OVER_SPEED;                    /* over speed error */
        }
    }

    /*=============================*/
    /*     timeout error check     */
    /*==== ========================*/
    /* Timeout check is performed (except for INIT state). */
    if (MTR_MODE_INIT != g_st_120.u2_run_mode)
    {
        if (g_st_120.u2_cnt_timeout > MTR_TIMEOUT_CNT)
        {
#if (MTRCONF_SENSOR_MODE == HALL)
            g_st_120.u2_error_status |= MTR_ERROR_HALL_TIMEOUT;                  /* Hall timeout error */
#elif (MTRCONF_SENSOR_MODE == LESS)
            g_st_120.u2_error_status |= MTR_ERROR_BEMF_TIMEOUT;                  /* sensorless timeout error */
#endif
        }
    }

    /*=======================================*/
    /*     Hall/BEMF pattern error check     */
    /*==== ==================================*/
    /* Hall/BEMF pattern check is performed */
    if (MTR_SET == g_st_120.u1_flag_pattern_error)
    {
#if (MTRCONF_SENSOR_MODE == HALL)
        g_st_120.u2_error_status |= MTR_ERROR_HALL_PATTERN;                      /* Hall pattern error */
#elif (MTRCONF_SENSOR_MODE == LESS)
        g_st_120.u2_error_status |= MTR_ERROR_BEMF_PATTERN;                      /* BEMF pattern error */
#endif
    }

    /* When any error happened, ERROR_EVENT should be executed. */
    if (g_st_120.u2_error_status != MTR_ERROR_NONE)
    {
DI();
        R_MTR_ExecEvent(MTR_EVENT_ERROR);
EI();
    }
} /* End of function mtr_error_check */

#if (MTRCONF_SENSOR_MODE == HALL)
/***********************************************************************************************************************
* Function Name : mtr_1ms_interrupt_hall
* Description   : TAU0 interrupt (Period:1ms)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_1ms_interrupt_hall(void)
{
EI();
    g_st_120.u2_run_mode = mtr_statemachine_get_status(&g_st_120.st_stm);            /* get motor status */

    /*=============================*/
    /*  Run mode state management  */
    /*=============================*/
    if (MTR_MODE_DRIVE == g_st_120.u2_run_mode)
    {
        if (MTR_SPEED_ZERO_CONST == g_st_120.u2_state_speed_ref)
        {
            g_st_120.u2_pwm_duty = mtr_duty_calc(g_st_120.s2_ref_v_ctrl, g_st_120.s2_vdc_ad);
            mtr_hall_signal_set();                       /* set initial voltage pattern */
            R_MTR_hall_interrupt_enable();                       /* start motor control */

            g_st_120.u2_state_speed_ref = MTR_SPEED_MANUAL;
            g_st_120.u2_pre_speed_timer_cnt = MTR_TAU1_CNT;
        }
        else
        {
            /*=============================*/
            /*   Open Loop <-> PI control  */
            /*=============================*/
            mtr_set_speed_ref();                    /* set speed reference */

            if (MTR_V_MANUAL == g_st_120.u2_state_voltage_ref)
            {
                /* after rotation direction has changed, restart PI control */
                if (g_st_120.u1_dir == g_st_120.u1_ref_dir)
                {
                    /* clear values of variables for speed calculation */
                    g_st_120.s2_speed_rad                   = 0;
                    g_st_120.u2_speed_timer_cnt             = 0;
                    g_st_120.u2_pre_speed_timer_cnt         = 0;
                    g_st_120.u2_timer_cnt_buff[0]           = 0;
                    g_st_120.u2_timer_cnt_buff[1]           = 0;
                    g_st_120.u2_timer_cnt_buff[2]           = 0;
                    g_st_120.u2_timer_cnt_buff[3]           = 0;
                    g_st_120.u2_timer_cnt_buff[4]           = 0;
                    g_st_120.u2_timer_cnt_buff[5]           = 0;
                    g_st_120.u2_v_pattern_ring_buff         = 0;
                    g_st_120.u2_first_rotation_cnt          = MTR_PATTERN_NUM;
                    g_st_120.st_hall.u2_flag_1st_interrupt  = MTR_SET;

                    g_st_120.u2_state_voltage_ref = MTR_V_PI_OUTPUT;
                }
            }
            else if (MTR_V_PI_OUTPUT == g_st_120.u2_state_voltage_ref)
            {
                /* when rotation direction is changed, reference voltage is set to const */
                if ((g_st_120.u1_dir != g_st_120.u1_ref_dir)
                       && (MTR_HALL2OL_REV_SPEED_RAD > mtr_abs(g_st_120.s2_ref_speed_rad_ctrl)))
                {
                    g_st_120.u2_cnt_timeout = 0;
                    g_st_120.s2_ref_v_ctrl = g_st_120.st_hall.s2_start_ref_v;
                    g_st_120.u2_state_voltage_ref = MTR_V_MANUAL;
                }

                /*==================================*/
                /*     TimeOut Error Handling       */
                /*==================================*/
                if (g_st_120.u2_cnt_timeout <= MTR_TIMEOUT_CNT)
                {
                  g_st_120.u2_cnt_timeout++;
                }
            }
        }
        mtr_set_voltage_ref();                                                     /* set voltage reference */
        g_st_120.u2_pwm_duty = mtr_duty_calc(g_st_120.s2_ref_v_ctrl, g_st_120.s2_vdc_ad);    /* set PWM duty */
    }
    else
    {
        R_MTR_ctrl_stop();
    }

    /*============================*/
    /*        check error         */
    /*============================*/
    mtr_error_check();

} /* End of function mtr_1ms_interrupt_hall */

/***********************************************************************************************************************
* Function Name : mtr_hall_u_interrupt
* Description   : U phase Hall sensor interrupt(INTP1)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_hall_u_interrupt(void)
{
    mtr_hall_signal_process();
EI();
} /* End of function mtr_hall_u_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_hall_v_interrupt
* Description   : V phase Hall sensor interrupt(INTP2)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_hall_v_interrupt(void)
{
    mtr_hall_signal_process();
EI();
} /* End of function mtr_hall_v_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_hall_w_interrupt
* Description   : W phase Hall sensor interrupt(INTP3)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_hall_w_interrupt(void)
{
    mtr_hall_signal_process();
EI();
} /* End of function mtr_hall_w_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_hall_signal_set
* Description   : Set voltage pattern
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_hall_signal_set(void)
{
    /*** get Hall signal ***/
    g_st_120.st_hall.u2_hall_signal  = MTR_PORT_HALL_U << 2;
    g_st_120.st_hall.u2_hall_signal |= MTR_PORT_HALL_V << 1;
    g_st_120.st_hall.u2_hall_signal |= MTR_PORT_HALL_W;

    /*** set voltage pattern ***/
    mtr_set_chopping_pattern(g_st_120.st_hall.u2_hall_signal);

    /* output voltage pattern */
    g_st_120.u1_flag_pattern_error = R_MTR_v_pattern_output(g_st_120.u2_v_pattern, g_st_120.u2_pwm_duty);

} /* End of function mtr_hall_signal_set */

/***********************************************************************************************************************
* Function Name : mtr_hall_signal_process
* Description   : Process for Hall sensor interrupt
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_hall_signal_process(void)
{
    g_st_120.u2_speed_timer_cnt = MTR_TAU1_CNT;

    if (MTR_MODE_DRIVE == g_st_120.u2_run_mode)
    {
        mtr_hall_signal_set();                              /* set voltage pattern */

        if (MTR_CLR == g_st_120.st_hall.u2_flag_1st_interrupt)
        {
            mtr_speed_calc();                               /* speed calculation */
        }
        else
        {
            g_st_120.st_hall.u2_flag_1st_interrupt = MTR_CLR;
            g_st_120.u2_pre_speed_timer_cnt = MTR_TAU1_CNT;
        }
    }

    /* timeout error check */
    if ((MTR_MODE_DRIVE == g_st_120.u2_run_mode) && (MTR_SPEED_ZERO_CONST != g_st_120.u2_state_speed_ref))
    {
        g_st_120.u2_cnt_timeout = 0;                         /* timeout counter reset */
    }
} /* End of function mtr_hall_signal_process */
#endif

#if (MTRCONF_SENSOR_MODE == LESS)
/***********************************************************************************************************************
* Function Name : mtr_1ms_interrupt_less
* Description   : TAU0 interrupt (Period:1ms)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_1ms_interrupt_less(void)
{
EI();
    g_st_120.u2_run_mode = mtr_statemachine_get_status(&g_st_120.st_stm);

    /*=============================*/
    /*  Run mode state management  */
    /*=============================*/
    if (MTR_MODE_DRIVE == g_st_120.u2_run_mode)
    {
        if (MTR_DRAW_IN_FINISH != g_st_120.st_less.u1_state_draw_in)
        {
            /*=================================================*/
            /* Draw-in two times to initial the rotor position */
            /*=================================================*/
            /* when draw-in (rotor initialization) is finished,
               open-loop drive should be started. */
            if (MTR_V_ZERO_CONST == g_st_120.u2_state_voltage_ref)
            {
                g_st_120.u2_state_voltage_ref = MTR_V_MANUAL;
            }

            /* wait for constatnt period*/
            if (g_st_120.s2_ref_v_ctrl == g_st_120.st_less.s2_draw_in_ref_v)
            {
                g_st_120.st_less.u2_cnt_draw_in++;
            }

            /* When constant period passed, change to next state */
            if (g_st_120.st_less.u2_v_const_period <= g_st_120.st_less.u2_cnt_draw_in)
            {
                if (MTR_DRAW_IN_1ST == g_st_120.st_less.u1_state_draw_in)
                {
                    /* after 1st draw-in, start 2nd draw-in */
                    g_st_120.st_less.u2_cnt_draw_in = 0;
                    g_st_120.u2_state_voltage_ref = MTR_V_ZERO_CONST;
                    g_st_120.st_less.u1_state_draw_in = MTR_DRAW_IN_2ND;
                }
                else if (MTR_DRAW_IN_2ND == g_st_120.st_less.u1_state_draw_in)
                {
                    /* after 2nd draw-in, start open-loop drive */
                    g_st_120.st_less.u2_cnt_draw_in = 0;
                    g_st_120.u2_state_speed_ref = MTR_SPEED_MANUAL;
                    g_st_120.s2_ref_v = g_st_120.st_less.s2_ol_ref_v;
                    g_st_120.s2_ref_v_ctrl = g_st_120.st_less.s2_ol_ref_v;
                    g_st_120.u2_pwm_duty = mtr_duty_calc(g_st_120.s2_ref_v_ctrl, g_st_120.s2_vdc_ad);
                    g_st_120.st_less.u1_state_draw_in = MTR_DRAW_IN_FINISH;

                    /* set 1st voltage pattern for open-loop drive */
                    g_st_120.st_less.u2_ol_v_pattern = mtr_openloop_pattern_set();
                    mtr_set_chopping_pattern(g_st_120.st_less.u2_ol_v_pattern);
                    mtr_start_delay_timer(0);
                    g_st_120.u2_pre_speed_timer_cnt = MTR_TAU1_CNT;
                }
                else
                {
                    /* do nothing */
                }
            }
        }
        else
        {
            /*=============================*/
            /*   open-loop <-> PI control  */
            /*=============================*/
            mtr_set_speed_ref();                    /* set speed reference */
            if (MTR_V_MANUAL == g_st_120.u2_state_voltage_ref)
            {
                /* when reference speed is over s2_change_speed_rad, allowed to change to sensorless control */
                if (mtr_abs(g_st_120.s2_ref_speed_rad_ctrl) >= g_st_120.st_less.st_ol2less.s2_change_speed_rad)
                {
                    g_st_120.st_less.st_ol2less.u2_flag_change_speed = MTR_SET;

                    /* set reference speed at transition from openloop drive to sensorless control */
                    if (MTR_PHASE_ADV == g_st_120.st_less.st_ol2less.u2_rotor_pos)
                    {
                        g_st_120.st_less.st_ol2less.s2_ref_speed_rad_buf
                                        += g_st_120.st_less.st_ol2less.s2_ramp_speed_rad;
                    }
                    else
                    {
                        g_st_120.st_less.st_ol2less.s2_ref_speed_rad_buf
                                        -= g_st_120.st_less.st_ol2less.s2_ramp_speed_rad;
                    }

                    /* set reference speed while trying to detect zerocross */
                    if (MTR_CW == g_st_120.u1_dir)
                    {
                        g_st_120.s2_ref_speed_rad_ctrl = g_st_120.st_less.st_ol2less.s2_ref_speed_rad_buf;
                    }
                    else
                    {
                        g_st_120.s2_ref_speed_rad_ctrl = -g_st_120.st_less.st_ol2less.s2_ref_speed_rad_buf;
                    }
                }
            }
            else if (MTR_V_PI_OUTPUT == g_st_120.u2_state_voltage_ref)
            {
                /* when reference speed is under s2_less2ol_speed_rad, change to open-loop drive */
                if (mtr_abs(g_st_120.s2_ref_speed_rad_ctrl) < g_st_120.st_less.s2_less2ol_speed_rad)
                {
                    g_st_120.u2_cnt_timeout = 0;
                    g_st_120.u2_state_voltage_ref = MTR_V_MANUAL;
                    g_st_120.st_less.st_ol2less.u2_flag_change_speed = MTR_CLR;

                    g_st_120.s2_ref_v = g_st_120.st_less.s2_ol_ref_v;
                    g_st_120.s2_ref_v_ctrl = g_st_120.st_less.s2_ol_ref_v;
                    g_st_120.st_less.st_ol2less.s2_ref_speed_rad_buf = g_st_120.st_less.st_ol2less.s2_change_speed_rad;
                    g_st_120.st_less.st_ol2less.u2_zc_cnt = 0;
                }

                /*==================================*/
                /*     TimeOut Error Handling       */
                /*==================================*/
                if (g_st_120.u2_cnt_timeout <= MTR_TIMEOUT_CNT)
                {
                    g_st_120.u2_cnt_timeout++;
                }
            }
            else
            {
                /* do nothing */
            }
        }
        mtr_set_voltage_ref();                  /* set voltage reference */
        /*** PWM duty set ***/
        g_st_120.u2_pwm_duty = mtr_duty_calc(g_st_120.s2_ref_v_ctrl, g_st_120.s2_vdc_ad);
    }
    else
    {
        R_MTR_ctrl_stop();
    }

    /*============================*/
    /*        check error         */
    /*============================*/
    mtr_error_check();

} /* End of function mtr_1ms_interrupt_less */

/***********************************************************************************************************************
* Function Name : mtr_delay_interrupt
* Description   : 30 degrees phase lag interrupt (from zerocross)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
__interrupt void mtr_delay_interrupt(void)
{
EI();
    mtr_stop_delay_timer();

    if (MTR_MODE_DRIVE == g_st_120.u2_run_mode)         /* check system mode */
    {
        /* output voltage pattern */
        g_st_120.u1_flag_pattern_error = R_MTR_v_pattern_output(g_st_120.u2_v_pattern, g_st_120.u2_pwm_duty);
    }
    else
    {
        R_MTR_ctrl_stop();
    }

} /* End of function mtr_delay_interrupt */

/***********************************************************************************************************************
* Function Name : mtr_draw_in_pattern_set
* Description   : Set voltage pattern at draw in state
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_draw_in_pattern_set(void)
{
    uint16_t u2_pattern;

    /* set voltage pattern depending on draw-in state */
    switch (g_st_120.st_less.u1_state_draw_in)
    {
        case MTR_DRAW_IN_1ST:
            u2_pattern = g_u2_ol_v_pattern_table[g_st_120.u1_dir][MTR_DRAW_IN_1ST_PATTERN];
        break;

        case MTR_DRAW_IN_2ND:
            u2_pattern = g_u2_ol_v_pattern_table[g_st_120.u1_dir][MTR_DRAW_IN_2ND_PATTERN];
        break;

        default:
            /* do nothing */
        break;
    }

    /*** set chopping pattern ***/
    mtr_set_chopping_pattern(u2_pattern);
    mtr_start_delay_timer(0);

} /* End of function mtr_draw_in_pattern_set */

/***********************************************************************************************************************
* Function Name : mtr_detect_zerocross
* Description   : Generate voltage pattern
* Arguments     : sensorless control structure
*               : u2_cnt_timeout - timeout counter
* Return Value  : voltage pattern
***********************************************************************************************************************/
uint16_t mtr_detect_zerocross(st_mtr_sensorless_control_t *st_less, uint16_t *u2_cnt_timeout)
{
    uint16_t u2_temp_signal;
    uint16_t u2_thresh_carrier_cnt;

    st_less->u2_pre_bemf_signal = st_less->u2_bemf_signal;    /* keep previous pattern */
    
    u2_temp_signal = 0;

    /* multiply three by each phase because vn_ad is sum of 3 phases. */
    st_less->s2_vn_ad = st_less->s2_vu_ad + st_less->s2_vv_ad + st_less->s2_vw_ad;
    st_less->s2_vu_ad *= 3;
    st_less->s2_vv_ad *= 3;
    st_less->s2_vw_ad *= 3;

    /*=========================================================*/
    /*     compare each voltage with neutral voltage           */
    /*                                                         */
    /*     g_st_120.st_less.u1_bemf_signal b7:b3 - don't use   */
    /*                      b2    - U phase                    */
    /*                      b1    - V phase                    */
    /*                      b0    - W phase                    */
    /*=========================================================*/
    if (st_less->s2_vu_ad > st_less->s2_vn_ad)            /* U phase */
    {
        u2_temp_signal |= 0x04;
    }
    else
    {
        u2_temp_signal &= ~0x04;
    }

    if (st_less->s2_vv_ad > st_less->s2_vn_ad)            /* V phase */
    {
        u2_temp_signal |= 0x02;
    }
    else
    {
        u2_temp_signal &= ~0x02;
    }

    if (st_less->s2_vw_ad > st_less->s2_vn_ad)            /* W phase */
    {
        u2_temp_signal |= 0x01;
    }
    else
    {
        u2_temp_signal &= ~0x01;
    }

    /* filtering bemf signal at transition from openloop drive to sensorless control */
    if (MTR_SET == st_less->st_ol2less.u2_flag_change)
    {
        /* prepare to detect zerocross after commutation */
        if (MTR_AVOID_COMMUTATION == st_less->u2_cnt_ol_speed)
        {
            st_less->u2_pre_bemf_signal = u2_temp_signal;
            st_less->u2_pre_cnt_carrier = 0; 

            /* update state of zerocross flag and zerocross count */
            if (MTR_SET == g_st_120.st_less.st_ol2less.u2_zc_flag)
            {
                st_less->st_ol2less.u2_zc_flag = MTR_CLR;
            }
            else
            {
                st_less->st_ol2less.u2_zc_cnt = 0;
            }
        }

        /* when zerocross flag is set, filter bemf signal change */
        if (MTR_SET == g_st_120.st_less.st_ol2less.u2_zc_flag)
        {
            u2_temp_signal = st_less->u2_pre_bemf_signal;
        }
    }

    g_st_120.st_less.u2_cnt_carrier++;
    if (u2_temp_signal != st_less->u2_pre_bemf_signal)                                /* check signal change */
    {
        /* calculate three quarters previous count of carrier interrupt for filter (The result is 45 degrees.) */
        u2_thresh_carrier_cnt = ((st_less->u2_pre_cnt_carrier << 1) + st_less->u2_pre_cnt_carrier) >> 2;

        if (st_less->u2_cnt_carrier > u2_thresh_carrier_cnt)                          /* check carrier count */
        {
            st_less->u2_pre_cnt_carrier = st_less->u2_cnt_carrier;            /* keep previous carrier count */
            st_less->u2_cnt_carrier = 0;
            *u2_cnt_timeout = 0;                                          /* clear counter for timeout error */
            st_less->u1_flag_pattern_change = MTR_SET;
        }
        else
        {
            u2_temp_signal = st_less->u2_pre_bemf_signal;                          /* invalid changed signal */
        }
    }

    return (u2_temp_signal);
} /* End of function mtr_detect_zerocross */

/***********************************************************************************************************************
* Function Name : mtr_drive_openloop
* Description   : Forced voltage pattern control for open loop
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_drive_openloop(void)
{
    /* Check divide by zero */
    if (0 != g_st_120.s2_ref_speed_rad_ctrl)
    {
        /* calculate period for 60 degrees with rounding formula at open-loop drive */
        g_st_120.st_less.u2_ol_pattern_period = (uint16_t)((MTR_PU_Q_OL_SPEED_CALC_BASE
                                                               + (mtr_abs(g_st_120.s2_ref_speed_rad_ctrl) >> 1))
                                                               / mtr_abs(g_st_120.s2_ref_speed_rad_ctrl));

        /* during open-loop drive, voltage pattern is changed depending on count */
        g_st_120.st_less.u2_cnt_ol_speed++;
        if (g_st_120.st_less.u2_cnt_ol_speed > g_st_120.st_less.u2_ol_pattern_period)
        {
            g_st_120.u2_cnt_timeout = 0; 
            g_st_120.st_less.u2_cnt_ol_speed = 0;

            g_st_120.st_less.u2_ol_v_pattern = mtr_openloop_pattern_set();
            mtr_set_chopping_pattern(g_st_120.st_less.u2_ol_v_pattern);
            mtr_start_delay_timer(0);
        }
    }
} /* End of function mtr_drive_openloop */

/***********************************************************************************************************************
* Function Name : mtr_set_angle_shift
* Description   : set adjust shift value for pattern change
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_angle_shift(void)
{
    uint16_t u2_temp_delay_cnt;

    /* calculate count of 30 degrees */
    switch (g_st_120.u2_v_pattern_ring_buff)
    {
        case 0:
            u2_temp_delay_cnt = (g_st_120.u2_timer_cnt_buff[5] + g_st_120.u2_timer_cnt_buff[4]) >> 2;
        break;

        case 1:
            u2_temp_delay_cnt = (g_st_120.u2_timer_cnt_buff[0] + g_st_120.u2_timer_cnt_buff[5]) >> 2;
        break;

        case 2:
            u2_temp_delay_cnt = (g_st_120.u2_timer_cnt_buff[1] + g_st_120.u2_timer_cnt_buff[0]) >> 2;
        break;

        case 3:
            u2_temp_delay_cnt = (g_st_120.u2_timer_cnt_buff[2] + g_st_120.u2_timer_cnt_buff[1]) >> 2;
        break;

        case 4:
            u2_temp_delay_cnt = (g_st_120.u2_timer_cnt_buff[3] + g_st_120.u2_timer_cnt_buff[2]) >> 2;
        break;

        case 5:
            u2_temp_delay_cnt = (g_st_120.u2_timer_cnt_buff[4] + g_st_120.u2_timer_cnt_buff[3]) >> 2;
        break;

        default:
            /* do nothing */
        break;
    }

    g_st_120.st_less.u2_bemf_delay = (uint16_t)((int16_t)u2_temp_delay_cnt + g_st_120.st_less.s2_angle_shift_adjust);

} /* End of function mtr_set_angle_shift */

/***********************************************************************************************************************
* Function Name : mtr_start_delay_timer
* Description   : 30 degrees phase lag interrupt (from zerocross)
* Arguments     : u2_delay_cnt - timer delay count
* Return Value  : None
***********************************************************************************************************************/
void mtr_start_delay_timer(uint16_t u2_delay_cnt)
{
    mtr_set_tdr03(u2_delay_cnt);  /* set delay count */
    mtr_clear_inttm03();          /* clear INTTM03 interrupt flag */
    mtr_start_delay_cnt();        /* Start delay counter */
} /* End of function mtr_start_delay_timer */

/***********************************************************************************************************************
* Function Name : mtr_stop_delay_timer
* Description   : Stop delay timer (TAU channel1)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_stop_delay_timer(void)
{
    mtr_stop_delay_cnt();            /* stop delay counter */
    mtr_clear_inttm03();             /* clear INTTM03 interrupt flag */
} /* End of function mtr_stop_delay_timer */

/***********************************************************************************************************************
* Function Name : mtr_openloop_pattern_set
* Description   : Set forced voltage pattern at open-loop state
* Arguments     : None
* Return Value  : voltage pattern
***********************************************************************************************************************/
uint8_t mtr_openloop_pattern_set(void)
{
    uint16_t u2_pattern;

    /* set ring buffer  */
    g_st_120.st_less.u2_ol_v_pattern_num++;
    if (g_st_120.st_less.u2_ol_v_pattern_num > 6)
    {
        g_st_120.st_less.u2_ol_v_pattern_num = 1;
    }

    u2_pattern = g_u2_ol_v_pattern_table[g_st_120.u1_dir][g_st_120.st_less.u2_ol_v_pattern_num];

    return (u2_pattern);
} /* End of function mtr_openloop_pattern_set */

/***********************************************************************************************************************
* Function Name : mtr_ol2less_ctrl
* Description   : Change from opeen-loop drive to sensorless control
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_ol2less_ctrl(void)
{
    int16_t s2_bemf_voltage;

    /* judge whether bemf voltage exceeds threshold voltage */
    if (MTR_V_MANUAL == g_st_120.u2_state_voltage_ref)
    {
        if ((MTR_CLR == g_st_120.st_less.st_ol2less.u2_flag_change)
            && (MTR_SET == g_st_120.st_less.st_ol2less.u2_flag_change_speed))
        {
            if (MTR_AVOID_COMMUTATION < g_st_120.st_less.u2_cnt_ol_speed)
            {
                /* calculate bemf voltage */
                s2_bemf_voltage = mtr_abs(mtr_get_bemf_voltage() - g_st_120.st_less.s2_vn_ad);

                /* if bemf voltage is over threshold voltage, u2_flag_change is set*/
                if ((MTR_OL2LESS_BEMF_THRESH * 3) < s2_bemf_voltage)
                {
                    g_st_120.st_less.st_ol2less.u2_flag_change = MTR_SET;
                    g_st_120.st_less.st_ol2less.s2_ref_speed_rad_buf = g_st_120.st_less.st_ol2less.s2_change_speed_rad;
                }
            }
        }
    }

    if (MTR_SET == g_st_120.st_less.st_ol2less.u2_flag_change)
    {
        /* detect zerocross while avoiding influence of commutation */
        if (g_st_120.st_less.u2_cnt_ol_speed > MTR_AVOID_COMMUTATION)
        {
            if (MTR_SET == g_st_120.st_less.u1_flag_pattern_change)
            {
                g_st_120.st_less.st_ol2less.u2_zc_flag = MTR_SET;
                g_st_120.st_less.st_ol2less.u2_zc_cnt++;
            }
        }

        /* when zerocross count reaches three times, voltage state is set as PI mode */
        if (g_st_120.st_less.st_ol2less.u2_zc_cnt >= MTR_OL2LESS_ZC_CNT)
        {
            g_st_120.st_less.st_ol2less.u2_flag_change = MTR_CLR;
            g_st_120.st_less.st_ol2less.u2_zc_flag = MTR_CLR;
            g_st_120.u2_state_voltage_ref = MTR_V_PI_OUTPUT;
        }
        else if (1 == g_st_120.st_less.st_ol2less.u2_zc_cnt)
        {
            /* when first zerocross is detected, skip speed calculation */
            if (MTR_SET == g_st_120.st_less.u1_flag_pattern_change)
            {
                g_st_120.u2_pre_speed_timer_cnt = g_st_120.u2_speed_timer_cnt;
                g_st_120.st_less.u1_flag_pattern_change = MTR_CLR;
            }
        }
        else
        {
            /* do nothing */
        }

        /* adjust phase of rotor to detect zerocross*/
        if ((g_st_120.st_less.u2_ol_pattern_period >> 1) == g_st_120.st_less.u2_cnt_ol_speed)
        {
            mtr_openloop_phase_ctrl();
        }
    }
} /* End of function mtr_ol2less_ctrl */

/***********************************************************************************************************************
* Function Name : mtr_get_bemf_voltage
* Description   : Get BEMF voltage
* Arguments     : None
* Return Value  : s2_bemf_temp - BEMF voltage
***********************************************************************************************************************/
int16_t mtr_get_bemf_voltage(void)
{
    int16_t s2_bemf_voltage;

    /* extract BEMF voltage depending on voltage pattern */
    if (MTR_CW == g_st_120.u1_dir)
    {
        switch (g_st_120.st_less.u2_ol_v_pattern)
        {
            case MTR_PATTERN_CW_W_V:
            case MTR_PATTERN_CW_V_W:
                s2_bemf_voltage = g_st_120.st_less.s2_vu_ad;     /* U phase has no output */
            break;

            case MTR_PATTERN_CW_U_W:
            case MTR_PATTERN_CW_W_U:
                s2_bemf_voltage = g_st_120.st_less.s2_vv_ad;     /* V phase has no output */
            break;

            case MTR_PATTERN_CW_U_V:
            case MTR_PATTERN_CW_V_U:
                s2_bemf_voltage = g_st_120.st_less.s2_vw_ad;     /* W phase has no output */
            break;

            default:
                /* do nothing */
            break;
        }
    }
    else
    {
        switch (g_st_120.st_less.u2_ol_v_pattern)
        {
            case MTR_PATTERN_CCW_V_W:
            case MTR_PATTERN_CCW_W_V:
                s2_bemf_voltage = g_st_120.st_less.s2_vu_ad;     /* U phase has no output */
            break;

            case MTR_PATTERN_CCW_U_W:
            case MTR_PATTERN_CCW_W_U:
                s2_bemf_voltage = g_st_120.st_less.s2_vv_ad;     /* V phase has no output */
            break;

            case MTR_PATTERN_CCW_U_V:
            case MTR_PATTERN_CCW_V_U:
                s2_bemf_voltage = g_st_120.st_less.s2_vw_ad;     /* W phase has no output */
            break;

            default:
                /* do nothing */
            break;
        }
    }

    return (s2_bemf_voltage);
} /* End of function mtr_get_bemf_voltage */

/***********************************************************************************************************************
* Function Name : mtr_openloop_phase_ctrl
* Description   : Control position of rotor to detect zerocross
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_openloop_phase_ctrl(void)
{
    int16_t s2_bemf_temp;

    s2_bemf_temp = mtr_get_bemf_voltage();

    /* detect whether phase of rotor is advanced or delayed */
    if (MTR_CW == g_st_120.u1_dir)
    {
        switch (g_st_120.st_less.u2_ol_v_pattern)
        {
            case MTR_PATTERN_CW_V_U:
            case MTR_PATTERN_CW_W_V:
            case MTR_PATTERN_CW_U_W:
                if (s2_bemf_temp > g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_ADV;   /* advanced phase */
                }
                else if (s2_bemf_temp < g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_DLY;   /* delayed phase */
                }
            break;

            case MTR_PATTERN_CW_W_U:
            case MTR_PATTERN_CW_U_V:
            case MTR_PATTERN_CW_V_W:
                if (s2_bemf_temp < g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_ADV;    /* advanced phase */
                }
                else if (s2_bemf_temp > g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_DLY;    /* delayed phase */
                }
            break;

            default:
                /* do nothing */
            break;
        }
    }
    else
    {
        switch (g_st_120.st_less.u2_ol_v_pattern)
        {
            case MTR_PATTERN_CCW_W_V:
            case MTR_PATTERN_CCW_V_U:
            case MTR_PATTERN_CCW_U_W:
                if (s2_bemf_temp > g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_DLY;     /* delayed phase */
                } 
                else if (s2_bemf_temp < g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_ADV;      /* advanced phase */
                }
            break;

            case MTR_PATTERN_CCW_V_W:
            case MTR_PATTERN_CCW_W_U:
            case MTR_PATTERN_CCW_U_V:
                if (s2_bemf_temp < g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_DLY;      /* delayed phase */
                }
                else if (s2_bemf_temp > g_st_120.st_less.s2_vn_ad)
                {
                    g_st_120.st_less.st_ol2less.u2_rotor_pos = MTR_PHASE_ADV;      /* advanced phase */
                }
            break;

            default:
                /* do nothing */
            break;
        }
    }
} /* End of function mtr_openloop_phase_ctrl */
#endif
