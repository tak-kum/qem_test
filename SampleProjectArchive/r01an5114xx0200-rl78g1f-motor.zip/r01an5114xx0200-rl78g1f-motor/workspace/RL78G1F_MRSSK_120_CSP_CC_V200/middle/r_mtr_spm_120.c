/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_spm_120.c
* Description : The processing of motor control layer
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_config.h"
#include "r_mtr_spm_120.h"
#include "r_mtr_ctrl_rl78g1f.h"
#include "r_dsp.h"
#include "r_mtr_driver_access.h"
#include "r_mtr_statemachine.h"
#include "r_mtr_fixed.h"
#include "r_mtr_parameter.h"
#include "r_mtr_pu_system.h"

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
extern uint8_t     g_u1_trig_enable_write;     /* ICS write enable flag */

#ifdef ICS_USE
/****** for ICS ******/
volatile uint8_t      g_u1_cnt_ics;               /* counter for period of calling "ics_watchpoint" */
extern mtr_ctrl_input_t st_ics_input_buff;
/*********************/
#endif

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_120_motor_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : st_120 - The pointer to the 120 degree control data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_120_motor_default_init(st_mtr_120_control_t *st_120)
{
    /* 120 degree control structure */
    st_120->u1_ref_dir              = MTR_CW;
    st_120->u1_dir                  = MTR_CW;
    st_120->u1_flag_charge_cap      = MTR_CLR;
    st_120->u1_flag_pattern_error   = MTR_CLR;
    st_120->u2_run_mode             = mtr_statemachine_get_status(&st_120->st_stm);
    st_120->u2_error_status         = MTR_ERROR_NONE;
    st_120->u2_state_speed_ref      = MTR_SPEED_ZERO_CONST;
    st_120->u2_state_voltage_ref    = MTR_V_ZERO_CONST;
    st_120->u2_speed_timer_cnt      = 0;
    st_120->u2_pre_speed_timer_cnt  = 0;
    st_120->u2_timer_cnt_buff[0]    = 0;
    st_120->u2_timer_cnt_buff[1]    = 0;
    st_120->u2_timer_cnt_buff[2]    = 0;
    st_120->u2_timer_cnt_buff[3]    = 0;
    st_120->u2_timer_cnt_buff[4]    = 0;
    st_120->u2_timer_cnt_buff[5]    = 0;
    st_120->u2_v_pattern_ring_buff  = 0;
    st_120->u2_v_pattern            = 0;
    st_120->u2_pwm_duty             = 0;
    st_120->u2_cnt_timeout          = 0;
    st_120->u2_first_rotation_cnt   = MTR_PATTERN_NUM;
    st_120->u2_timer_cnt_sum        = 0;

    st_120->s2_speed_rad            = 0;                                                                  /* PU unit */
    st_120->s2_ref_speed_rad        = mtr_conv_rpm2rad_pu(CP_MIN_SPEED_RPM);                              /* PU unit */
    st_120->s2_ref_speed_rad_ctrl   = 0;                                                                  /* PU unit */
    st_120->s2_ramp_limit_speed_rad = mtr_conv_rpm2rad_pu(CP_RAMP_LIMIT_SPEED_RPM);                       /* PU unit */
    st_120->s2_vdc_ad               = 0;                                                                  /* PU unit */
    st_120->s2_ref_v                = 0;                                                                  /* PU unit */
    st_120->s2_ref_v_ctrl           = 0;                                                                  /* PU unit */
    st_120->s2_ramp_limit_v         = FIX_fromfloat(CP_RAMP_LIMIT_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);      /* PU unit */

    /* motor parameter structure */
    st_120->st_motor.u2_mtr_pp      = MP_POLE_PAIRS;
    st_120->st_motor.s2_mtr_r       = FIX_fromfloat((MP_RESISTANCE * PU_SF_RES), MTR_Q_RES);              /* PU unit */
    st_120->st_motor.s2_mtr_ld      = FIX_fromfloat((MP_D_INDUCTANCE * PU_SF_IND), MTR_Q_IND);            /* PU unit */
    st_120->st_motor.s2_mtr_lq      = FIX_fromfloat((MP_Q_INDUCTANCE * PU_SF_IND), MTR_Q_IND);            /* PU unit */
    st_120->st_motor.s2_mtr_m       = FIX_fromfloat((MP_MAGNETIC_FLUX * PU_SF_FLUX), MTR_Q_FLUX);         /* PU unit */
    st_120->st_motor.s2_mtr_j       = FIX_fromfloat((MP_ROTOR_INERTIA * PU_SF_INERTIA), MTR_Q_INERTIA);   /* PU unit */

    /* PI control structure */
    st_120->st_pi_speed.s2_err      = 0;
    st_120->st_pi_speed.s2_kp       = FIX_fromfloat((CP_SPEED_PI_KP * PU_SF_SPEED_KP), MTR_Q_SPEED_KP);   /* PU unit */
    st_120->st_pi_speed.s2_kidt     = FIX_fromfloat((CP_SPEED_PI_KIDT * PU_SF_SPEED_KIDT), MTR_Q_SPEED_KIDT);
                                                                                                          /* PU unit */
    st_120->st_pi_speed.s2_limit    = FIX_fromfloat(MTR_SPEED_PI_LIMIT_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE); /* PU unit */
    st_120->st_pi_speed.s4_pre_refp = 0;

#if (MTRCONF_SENSOR_MODE == HALL)
    /* Hall-effect-sensor control structure */
    st_120->st_hall.u2_hall_signal         = 0;
    st_120->st_hall.u2_flag_1st_interrupt  = MTR_SET;
    st_120->st_hall.s2_start_ref_v         = FIX_fromfloat(CP_START_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);/* PU unit */
#elif (MTRCONF_SENSOR_MODE == LESS)
    /* sensorless control structure */
    st_120->st_less.u1_state_draw_in       = MTR_DRAW_IN_NONE;
    st_120->st_less.u1_flag_pattern_change = MTR_CLR;

    st_120->st_less.u2_bemf_delay          = 0;
    st_120->st_less.u2_bemf_signal         = 0;
    st_120->st_less.u2_pre_bemf_signal     = 0;
    st_120->st_less.u2_cnt_ol_speed        = 0;
    st_120->st_less.u2_ol_pattern_period   = 0;
    st_120->st_less.u2_cnt_draw_in         = 0;
    st_120->st_less.u2_v_const_period      = 0;
    st_120->st_less.u2_ol_v_pattern        = 0;
    st_120->st_less.u2_ol_v_pattern_num    = MTR_DRAW_IN_2ND_PATTERN;
    st_120->st_less.u2_cnt_carrier         = 0;
    st_120->st_less.u2_pre_cnt_carrier     = MTR_INIT_CNT_CARRIER;

    st_120->st_less.s2_less2ol_speed_rad   = mtr_conv_rpm2rad_pu(CP_OL2LESS_SPEED_RPM - MTR_LESS2OL_HYSTERESIS);
                                                                                                          /* PU unit */
    st_120->st_less.s2_vu_ad               = 0;
    st_120->st_less.s2_vv_ad               = 0;
    st_120->st_less.s2_vw_ad               = 0;
    st_120->st_less.s2_vn_ad               = 0;
    st_120->st_less.s2_draw_in_ref_v       = FIX_fromfloat(CP_DRAW_IN_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
                                                                                                          /* PU unit */
    st_120->st_less.s2_ol_ref_v            = FIX_fromfloat(CP_OL_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);   /* PU unit */
    st_120->st_less.s2_angle_shift_adjust  = 0;

    /* structure for transition from openloop drive into sensorless control */
    st_120->st_less.st_ol2less.u2_flag_change            = MTR_CLR;
    st_120->st_less.st_ol2less.u2_zc_flag                = MTR_CLR;
    st_120->st_less.st_ol2less.u2_zc_cnt                 = 0;
    st_120->st_less.st_ol2less.u2_flag_change_speed      = MTR_CLR;

    st_120->st_less.st_ol2less.s2_change_speed_rad       = mtr_conv_rpm2rad_pu(CP_OL2LESS_SPEED_RPM);     /* PU unit */
    st_120->st_less.st_ol2less.s2_ref_speed_rad_buf      = mtr_conv_rpm2rad_pu(CP_OL2LESS_SPEED_RPM);     /* PU unit */
    st_120->st_less.st_ol2less.s2_ramp_speed_rad         = mtr_conv_rpm2rad_pu(CP_OL2LESS_SPEED_RAMP_RPM);/* PU unit */
    st_120->st_less.st_ol2less.u2_rotor_pos              = MTR_PHASE_ADV;
#endif

    mtr_pu_system_init(MTR_VDC_SCALING, MP_POLE_PAIRS);

#ifdef ICS_USE
/****** for ICS ******/
    g_u1_trig_enable_write  = MTR_CLR;
    g_u1_cnt_ics            = 0;
/*********************/
#endif
} /* End of function mtr_120_motor_default_init */

/***********************************************************************************************************************
* Function Name : mtr_120_motor_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : st_120 - The pointer to the 120 degree control data structure
* Return Value  : None
***********************************************************************************************************************/
void mtr_120_motor_reset(st_mtr_120_control_t *st_120)
{
    /* 120 degree control structure */
    st_120->u1_dir                         = MTR_CW;
    st_120->u1_flag_pattern_error          = MTR_CLR;
    st_120->u2_run_mode                    = mtr_statemachine_get_status(&st_120->st_stm);
    st_120->u2_error_status                = MTR_ERROR_NONE;
    st_120->u2_state_voltage_ref           = MTR_V_MANUAL;
    st_120->u2_state_speed_ref             = MTR_SPEED_ZERO_CONST;

    st_120->u2_speed_timer_cnt             = 0;
    st_120->u2_pre_speed_timer_cnt         = 0;
    st_120->u2_timer_cnt_buff[0]           = 0;
    st_120->u2_timer_cnt_buff[1]           = 0;
    st_120->u2_timer_cnt_buff[2]           = 0;
    st_120->u2_timer_cnt_buff[3]           = 0;
    st_120->u2_timer_cnt_buff[4]           = 0;
    st_120->u2_timer_cnt_buff[5]           = 0;
    st_120->u2_v_pattern_ring_buff         = 0;
    st_120->u2_v_pattern                   = 0;
    st_120->u2_pwm_duty                    = 0;
    st_120->u2_cnt_timeout                 = 0;
    st_120->u2_first_rotation_cnt          = MTR_PATTERN_NUM;
    st_120->u2_timer_cnt_sum               = 0;

    st_120->s2_speed_rad                   = 0;                                                           /* PU unit */
    st_120->s2_ref_speed_rad_ctrl          = 0;                                                           /* PU unit */

    /* PI control structure */
    st_120->st_pi_speed.s2_err             = 0;                                                           /* PU unit */
    st_120->st_pi_speed.s4_pre_refp        = 0;                                                           /* PU unit */

#if (MTRCONF_SENSOR_MODE == HALL)
    /* Hall-effect-sensor control structure */
    st_120->s2_ref_v                       = st_120->st_hall.s2_start_ref_v;                              /* PU unit */
    st_120->s2_ref_v_ctrl                  = st_120->st_hall.s2_start_ref_v;                              /* PU unit */

    st_120->st_hall.u2_hall_signal         = 0;
    st_120->st_hall.u2_flag_1st_interrupt  = MTR_SET;

#elif (MTRCONF_SENSOR_MODE == LESS)
    /* sensorless control structure */
    st_120->s2_ref_v                       = st_120->st_less.s2_draw_in_ref_v;                            /* PU unit */
    st_120->s2_ref_v_ctrl                  = 0;                                                           /* PU unit */

    st_120->st_less.u1_state_draw_in       = MTR_DRAW_IN_1ST;
    st_120->st_less.u1_flag_pattern_change = MTR_CLR;

    st_120->st_less.u2_bemf_delay          = 0;
    st_120->st_less.u2_bemf_signal         = 0;
    st_120->st_less.u2_pre_bemf_signal     = 0;
    st_120->st_less.u2_cnt_ol_speed        = 0;
    st_120->st_less.u2_ol_pattern_period   = 0;
    st_120->st_less.u2_cnt_draw_in         = 0;
    st_120->st_less.u2_ol_v_pattern        = 0;
    st_120->st_less.u2_ol_v_pattern_num    = MTR_DRAW_IN_2ND_PATTERN;
    st_120->st_less.u2_cnt_carrier         = 0;
    st_120->st_less.u2_pre_cnt_carrier     = MTR_INIT_CNT_CARRIER;

    st_120->st_less.s2_vu_ad               = 0;
    st_120->st_less.s2_vv_ad               = 0;
    st_120->st_less.s2_vw_ad               = 0;
    st_120->st_less.s2_vn_ad               = 0;
    st_120->st_less.s2_angle_shift_adjust  = 0;

    /* structure for transition from openloop drive to sensorless control */
    st_120->st_less.st_ol2less.u2_flag_change        = MTR_CLR;
    st_120->st_less.st_ol2less.u2_zc_flag            = MTR_CLR;
    st_120->st_less.st_ol2less.u2_zc_cnt             = 0;
    st_120->st_less.st_ol2less.u2_flag_change_speed  = MTR_CLR;
    st_120->st_less.st_ol2less.u2_rotor_pos          = MTR_PHASE_ADV;
    st_120->st_less.st_ol2less.s2_ref_speed_rad_buf  = st_120->st_less.st_ol2less.s2_change_speed_rad;    /* PU unit */
#endif

} /* End of function mtr_120_motor_reset */
