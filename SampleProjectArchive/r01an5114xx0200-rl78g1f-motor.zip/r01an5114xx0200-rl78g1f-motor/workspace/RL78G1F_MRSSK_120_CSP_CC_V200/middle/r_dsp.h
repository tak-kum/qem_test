/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_dsp.h
* Description  : The header file defines types and functions for motor control and fix point operations.
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

#ifndef __r_dsp_h__
#define __r_dsp_h__

#include "r_stdint.h"

/* Motor control library */
void R_motor_uv2ab_abs_int16(int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uv2ab_rel_int16(int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uw2ab_abs_int16(int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uw2ab_rel_int16(int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uvw2ab_abs_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uvw2ab_rel_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
void R_motor_ab2uvw_abs_int16(int16_t, int16_t, int16_t *, int16_t *, int16_t *);
void R_motor_ab2uvw_rel_int16(int16_t, int16_t, int16_t *, int16_t *, int16_t *);
void R_motor_ab2dq_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
void R_motor_dq2ab_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
void R_motor_xy2ra_int16(int16_t, int16_t, int16_t *, int16_t *);
void R_motor_ra2xy_int16(int16_t, int16_t, int16_t *, int16_t *);
int16_t R_motor_PI_i16( int16_t err,int16_t max,int16_t kpro,int16_t kint,int32_t *integ);
void R_motor_dq2uvw_abs_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *, int16_t *);
void R_motor_dq2uvw_rel_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *, int16_t *);
void R_motor_dq2uvw_abs_3rdin_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *, int16_t *);
void R_motor_dq2uvw_rel_3rdin_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *, int16_t *);
void R_motor_uvw2dq_abs_int16(int16_t, int16_t, int16_t, int16_t , int16_t *, int16_t *);
void R_motor_uvw2dq_rel_int16(int16_t, int16_t, int16_t, int16_t , int16_t *, int16_t *);
void R_motor_uv2dq_abs_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uv2dq_rel_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uw2dq_abs_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
void R_motor_uw2dq_rel_int16(int16_t, int16_t, int16_t, int16_t *, int16_t *);
typedef int16_t FIX8, FIX10, FIX12, FIX14, FIX16;
typedef int16_t FIX;

/* fixmath library */
FIX16 R_FIX16_mul_int16(FIX16, FIX16);
FIX14 R_FIX14_mul_int16(FIX14, FIX14);
FIX12 R_FIX12_mul_int16(FIX12, FIX12);
FIX10 R_FIX10_mul_int16(FIX10, FIX10);
FIX8 R_FIX8_mul_int16(FIX8, FIX8);

uint16_t R_FIX_div_int16(uint16_t, uint16_t);
int32_t R_FIX_mul32_int16(int16_t, int16_t);

uint16_t R_FIX_sqrt_int16(uint16_t);
uint16_t R_FIX_sqrt2_int16(int16_t, int16_t);
int16_t R_FIX_sin_int16(int16_t);
int16_t R_FIX_cos_int16(int16_t);
int16_t R_FIX_atan_int16(int16_t);
int16_t R_FIX_atan2_int16(int16_t, int16_t);
int16_t R_FIX_limit_int16(int16_t, uint16_t);
uint16_t R_FIX_ulimit_int16(int16_t, uint16_t);

/* Conversion macros between floating point. */

#define FIX8_tofloat(x) ((float)(x)/256.0f)
#define FIX10_tofloat(x) ((float)(x)/1024.0f)
#define FIX12_tofloat(x) ((float)(x)/4096.0f)
#define FIX14_tofloat(x) ((float)(x)/16384.0f)
#define FIX16_tofloat(x) ((float)(x)/65536.0f)

#define FIX8_fromfloat(x) ((FIX8)((x)*256.0f))
#define FIX10_fromfloat(x) ((FIX10)((x)*1024.0f))
#define FIX12_fromfloat(x) ((FIX12)((x)*4096.0f))
#define FIX14_fromfloat(x) ((FIX14)((x)*16384.0f))
#define FIX16_fromfloat(x) ((FIX16)((x)*65536.0f))


/* Conversion macros between floating point.  to double and from double */

#define FIX8_todouble(x) ((double)(x)/256.0)
#define FIX10_todouble(x) ((double)(x)/1024.0)
#define FIX12_todouble(x) ((double)(x)/4096.0)
#define FIX14_todouble(x) ((double)(x)/16384.0)
#define FIX16_todouble(x) ((double)(x)/65536.0)

#define FIX8_fromdouble(x) ((FIX8)((x)*256.0))
#define FIX10_fromdouble(x) ((FIX10)((x)*1024.0))
#define FIX12_fromdouble(x) ((FIX12)((x)*4096.0))
#define FIX14_fromdouble(x) ((FIX14)((x)*16384.0))
#define FIX16_fromdouble(x) ((FIX16)((x)*65536.0))

#define     FIX_tofloat(x, n)                     ((float)(x)/(float)(1L<<(n)))
                                                  /* Convert x in Qn format to float */
#define     FIX_fromfloat(x, n)                   ((int16_t)((float)(x)*(float)(1L<<(n))))
                                                  /* Convert float x to int16_t in Qn format  */
#define     FIX32_fromfloat(x, n)                 ((int32_t)((float)(x)*(float)(1L<<(n))))
                                                  /* Convert float x to int16_t in Qn format  */
#define     FIX_lsar(a, sar)                      ((int32_t)(a  >> (sar)))
#define     FIX_lsal(a, sal)                      ((int32_t)(a  << (sal)))

/* Multiplication followed by right shift operation (predefined number of shift bits) */
#define     FIX_mul_int16_constsar(a, b, sar)     ((int16_t)(((int32_t)(a) * (int32_t)(b)) >> (sar)))
/* Multiplication followed by left shift operation (predefined number of shift bits) */
#define     FIX_mul_int16_constsal(a, b, sal)     ((int16_t)(((int32_t)(a) * (int32_t)(b)) << (sal)))
/* Multiplication followed by right shift operation (predefined number of shift bits) */
#define     FIX_mul32_int16_constsar(a, b, sar)   (((int32_t)(a) * (int32_t)(b)) >> (sar))
/* Multiplication followed by left shift operation (predefined number of shift bits) */
#define     FIX_mul32_int16_constsal(a, b, sal)   (((int32_t)(a) * (int32_t)(b)) << (sal))
/* Multiplication */
#define     FIX_mul_int16(a, b)                   ((int16_t)((int32_t)(a) * (int32_t)(b)))
/* Multiplication */
#define     FIX_mul32_int16(a, b)                 ((int32_t)(a) * (int32_t)(b))
#define     FIX_div_int16(a, b)                   (((uint16_t)(a) / (uint16_t)(b)))

#endif
