/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : main.h
* Description : main processes
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"
#include "main.h"
#include "r_mtr_common.h"
#include "r_mtr_ics.h"
#include "r_mtr_board.h"
#include "r_mtr_spm_120.h"
#include "r_mtr_driver_access.h"
#include "r_mtr_ctrl_mrssk.h"
#include "r_mtr_ctrl_rl78g1f.h"
/****** for ICS ******/
#include "ics_RL78G1F_Lx.h"
/*********************/

/***********************************************************************************************************************
Private function definitions
***********************************************************************************************************************/
static void  ics_ui(void);                      /* ICS UI control */
static void  board_ui(void);                    /* board UI control */
static void  software_init(void);               /* initialize ICS variables */

/***********************************************************************************************************************
Private variables
***********************************************************************************************************************/
static uint8_t    g_u1_system_mode;             /* system status */
static uint8_t    g_u1_motor_status;            /* motor status */
static uint8_t    g_u1_reset_req;               /* reset request flag */
static uint8_t    g_u1_stop_req;                /* stop request flag */
static uint8_t    g_u1_flag_ui_change;          /* UI change flag */
static uint16_t   g_u2_error_status;            /* error status */

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
uint16_t    g_u2_conf_hw         = 0x0401;      /* 0000010000000001b */
uint16_t    g_u2_conf_sw         = 0x01C4;      /* 0000000111000100b */
uint16_t    g_u2_conf_tool       = 0x0200;      /* 0000001000000000b */
uint8_t     gui_u1_active_gui;
uint16_t    g_u2_conf_sw_ver;

int16_t    com_s2_sw_userif;                    /* user interface switching */
int16_t    g_s2_sw_userif;                      /* user interface switching */
uint8_t    com_u1_run_event;                    /* change run mode */
uint8_t    g_u1_run_event;                      /* change run mode */
uint16_t   g_u2_system_error;                   /* error of system */

/****** for ICS ******/
#pragma address  dtc_tbl = 0xFFE00
char  dtc_tbl[0xD0];
/*********************/

/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: main
* Description  : Initialization and main routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
DI();
    g_u2_system_error |= R_MTR_InitHardware();          /* initialize peripheral function */
    software_init();                                    /* initialize private variables for control*/
/****** for ICS ******/
ics2_init(ICS_ADDR, ICS_SCI2_P77_P76, ICS_INT_LEVEL, ICS_NUM, ICS_BRR, ICS_INT_MODE); /* T5103 CN7 */
/*********************/
    R_MTR_InitControl();                                /* initialize global variables */
    R_MTR_ExecEvent(MTR_EVENT_RESET);                   /* execute reset event */
EI();
    g_u2_system_error |= R_MTR_ChargeCapacitor();       /* wait for charge of capacitor */

    /* change system mode */
    if (ERROR_NONE == g_u2_system_error)
    {
        g_u1_system_mode = MODE_ACTIVE;
    }
    else
    {
        g_u1_system_mode = MODE_ERROR;
    }

    /*** main routine ***/
    while (1)
    {
        /*** change UI ***/
        if (g_s2_sw_userif != com_s2_sw_userif)
        {
            g_s2_sw_userif = com_s2_sw_userif;
            /* if UI is changed to ICS, set flag to reflect ICS variables */
            if (ICS_UI == g_s2_sw_userif)
            {
                g_u1_flag_ui_change = MTR_SET;
            }
        }

        /* UI control process */
        if (ICS_UI == g_s2_sw_userif)
        {
            ics_ui();                                     /* ICS UI control */
        }
        else if (BOARD_UI == g_s2_sw_userif)
        {
            board_ui();                                   /* BOARD UI control */
        }
        else
        {
            /* do nothing */
        }

        /* check error status */
        if (MTR_ERROR_NONE != g_u2_error_status)
        {
            g_u1_run_event = MTR_EVENT_ERROR;
            com_u1_run_event = MTR_EVENT_ERROR;
            g_u1_system_mode = MODE_ERROR;
        }

        /* LED control */
        mtr_board_led_control(g_u1_motor_status, g_u1_system_mode);
        /* clear watch dog timer */
        clear_wdt();
    }
} /* End of function main */

/***********************************************************************************************************************
* Function Name : ics_ui
* Description   : ICS UI control routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void ics_ui(void)
{
    uint8_t u1_run_event_buff;

    /* set com values to ICS variables */
    mtr_set_com_variables();

    g_u1_motor_status = R_MTR_GetStatus();              /* get status of motor control system */
    g_u2_error_status = R_MTR_GetErrorStatus();         /* get error status */

    /*==============================*/
    /*        execute event         */
    /*==============================*/
    u1_run_event_buff = com_u1_run_event;               /* prevent com_u1_run_event rewritten */

    if ((g_u1_run_event != u1_run_event_buff) || (MTR_SET == g_u1_flag_ui_change))
    {
        if (MODE_ACTIVE == g_u1_system_mode)
        {
            /* when system mode is not error mode, execute event */
            if (u1_run_event_buff >= MTR_SIZE_EVENT)
            {
                com_u1_run_event = g_u1_run_event;
            }
            else
            {
                /* execute input event */
                g_u1_run_event = u1_run_event_buff;
                R_MTR_ExecEvent(g_u1_run_event);
            }

            g_u1_flag_ui_change = MTR_CLR;
        }
        else if (MODE_ERROR == g_u1_system_mode)
        {
            /* when system mode is error mode, reset process is performed */
            if (MTR_EVENT_RESET == u1_run_event_buff)
            {
                /* execute reset event */
                g_u1_run_event = u1_run_event_buff;
                R_MTR_ExecEvent(MTR_EVENT_RESET);
                g_u1_system_mode = MODE_ACTIVE;
                g_u2_error_status = R_MTR_GetErrorStatus();
            }
        }
        else
        {
            /* do nothing */
        }

        /* initialize private global variables for reset event */
        if (MTR_EVENT_RESET == u1_run_event_buff)
        {
            if (MTR_ERROR_NONE == g_u2_error_status)
            {
                software_init();
            }
        }
    }

} /* End of function ics_ui */

/***********************************************************************************************************************
* Function Name : board_ui
* Description   : Board UI control routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void board_ui(void)
{
    int16_t  s2_ref_speed_rpm;

    g_u1_motor_status = R_MTR_GetStatus();              /* get motor status */
    g_u2_error_status = R_MTR_GetErrorStatus();         /* get error status */

    /*======================*/
    /*     mode control     */
    /*======================*/
    if (MODE_ACTIVE == g_u1_system_mode)
    {
        switch (g_u1_motor_status)
        {
            case MTR_MODE_STOP:
               /*** when SW1 is ON, execute drive event ***/
               if ((MTR_CLR == g_u1_stop_req) && (MTR_SET == mtr_remove_chattering(R_MTR_GetSw1(), MTR_ON)))
               {
                   R_MTR_ExecEvent(MTR_EVENT_DRIVE);
               }
            break;

            case MTR_MODE_DRIVE:
               /*** when SW1 is OFF, execute stop event ***/
               if ((MTR_SET == g_u1_stop_req) || (MTR_SET == mtr_remove_chattering(R_MTR_GetSw1(), MTR_OFF)))
               {
                   g_u1_stop_req = MTR_CLR;
                   R_MTR_ExecEvent(MTR_EVENT_STOP);
               }
            break;

            default:
                /* do nothing */
            break;
        }
    }
    else
    {
        if ((MTR_CLR == g_u1_reset_req) && (MTR_SET == mtr_remove_chattering(R_MTR_GetSw2(), MTR_ON)))
        {
            /*** when SW2 is ON, set reset flag ***/
            g_u1_reset_req = MTR_SET;
        }
        else if ((MTR_SET == g_u1_reset_req) && (MTR_SET == mtr_remove_chattering(R_MTR_GetSw2(), MTR_OFF)))
        {
            /*** when SW2 is turned OFF, execute reset event ***/
            g_u1_reset_req = MTR_CLR;
            R_MTR_ExecEvent(MTR_EVENT_RESET);
            g_u1_system_mode = MODE_ACTIVE;
            g_u2_error_status = R_MTR_GetErrorStatus();
        }
        else
        {
            /* do nothing */
        }
    }

    /*=============================*/
    /*     set speed reference     */
    /*=============================*/
    /* read speed reference from VR1 */
    s2_ref_speed_rpm = (int16_t)((R_MTR_GetVr1Ad() - VR1_OFFSET) * VR1_SCALING);
    /* limit and set speed reference */
    g_u1_stop_req = R_MTR_SetSpeed(s2_ref_speed_rpm);

} /* End of function board_ui */

/***********************************************************************************************************************
* Function Name : software_init
* Description   : Initialize system variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void software_init(void)
{
    /* initialize variables used at main process */
    g_u1_system_mode    = MODE_ACTIVE;           /* system status */
    g_u1_motor_status   = MTR_MODE_INIT;           /* motor status */
    g_u2_error_status   = MTR_ERROR_NONE;          /* error status */
    g_u1_reset_req      = MTR_CLR;                 /* reset request flag */
    g_u1_stop_req       = MTR_CLR;                 /* stop request flag */
    g_u1_flag_ui_change = MTR_CLR;                 /* UI change flag */

    com_s2_sw_userif    = MTRCONF_DEFAULT_UI;      /* select UI */
    g_s2_sw_userif      = MTRCONF_DEFAULT_UI;

    com_u1_run_event    = MTR_EVENT_STOP;          /* change run mode */
    g_u1_run_event      = MTR_EVENT_STOP;          /* change run mode */

    /* initialize ICS variables */
    R_MTR_InputBuffParamReset();
    mtr_ics_variables_init();

} /* End of function software_init */
