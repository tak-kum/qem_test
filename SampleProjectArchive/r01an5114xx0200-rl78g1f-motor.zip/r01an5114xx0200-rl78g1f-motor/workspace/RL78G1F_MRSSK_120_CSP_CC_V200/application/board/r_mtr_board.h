/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_board.h
* Description : Definitions of user interface on inverter board
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_BOARD_H
#define R_MTR_BOARD_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* board UI definitions */
#define     SW_CHATTERING_CNT (10)                                       /* counts to remove chattering for SW */
#define     VR1_MARGIN        (400)                                      /* margin for VR1 [rpm] */
#define     VR1_SCALING       ((CP_MAX_SPEED_RPM + VR1_MARGIN) / 0x0200) /* scaling factor for speed reference (A/D) */
#define     VR1_OFFSET        (0x1FF)                                    /* adjusting offset for speed reference */

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_board_led_control
* Description   : Set LED pattern depend on motor status and system status
* Arguments     : u1_motor_status   - motor control status
*               : u1_system_status - system status
* Return Value  : None
***********************************************************************************************************************/
void mtr_board_led_control(uint8_t u1_motor_status, uint8_t g_u1_system_mode);

/***********************************************************************************************************************
* Function Name : mtr_remove_chattering
* Description   : Get switch status and remove chattering
* Arguments     : u1_sw - Board interface switch signal
*                 u1_on_off - Detected status (ON/OFF)
* Return Value  : u1_remove_chattering_flag - Detection result
***********************************************************************************************************************/
uint8_t mtr_remove_chattering(uint8_t u1_sw, uint8_t u1_on_off);

#endif /* R_MTR_BOARD_H */