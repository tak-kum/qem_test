/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_board.c
* Description : Processes of user interface on inverter board
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "main.h"
#include "r_mtr_common.h"
#include "r_mtr_board.h"
#include "r_mtr_spm_120.h"
#include "r_mtr_ctrl_mrssk.h"

/***********************************************************************************************************************
Private variables
***********************************************************************************************************************/
static uint8_t      u1_sw_cnt;                         /* Counter to remove chattering */

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_board_led_control
* Description   : Set LED pattern depend on motor status and system status
* Arguments     : u1_motor_status - motor control status
*               : u1_system_status - system status
* Return Value  : None
***********************************************************************************************************************/
void mtr_board_led_control(uint8_t u1_motor_status, uint8_t u1_system_status)
{
    /***** LED control *****/
    if (MODE_ERROR == u1_system_status)       /* Check motor status */
    {
        R_MTR_Led1Off();                                     /* LED1 off */
        R_MTR_Led2On();                                      /* LED2 on */
        R_MTR_Led3Off();                                     /* LED3 off */
    }
    else
    {
        if (MTR_MODE_STOP == u1_motor_status)         /* Check motor status */
        {
            R_MTR_Led1Off();                                     /* LED1 off */
            R_MTR_Led2Off();                                     /* LED2 off */
            R_MTR_Led3Off();                                     /* LED3 off */
        }
        else if (MTR_MODE_DRIVE == u1_motor_status)      /* Check motor status */
        {
            R_MTR_Led1On();                                      /* LED1 on */
            R_MTR_Led2Off();                                     /* LED2 off */
            R_MTR_Led3Off();                                     /* LED3 off */
        }
        else
        {
            /* do nothing */
        }
    }
} /* End of function mtr_board_led_control */

/***********************************************************************************************************************
* Function Name : mtr_remove_chattering
* Description   : Get switch status and remove chattering
* Arguments     : u1_sw - Board interface switch signal
*                 u1_on_off - Detected status (ON/OFF)
* Return Value  : u1_flag_chattering - Detection result
***********************************************************************************************************************/
uint8_t mtr_remove_chattering(uint8_t u1_sw, uint8_t u1_on_off)
{
    uint8_t u1_flag_chattering;

    u1_flag_chattering = MTR_CLR;

    /* when ON/OFF state becomes stable, chattering flag is set */
    if (u1_on_off == u1_sw)
    {
        u1_sw_cnt++;
        if (SW_CHATTERING_CNT < u1_sw_cnt)
        {
            u1_flag_chattering = MTR_SET;
            u1_sw_cnt = 0;
        }
    }
    else
    {
        /* if chattering occurs, counter is set to zero */
        u1_sw_cnt = 0;
    }

    return (u1_flag_chattering);
} /* End of function mtr_remove_chattering */
