#ifndef  ICS_RL78G1F_H
#define  ICS_RL78G1F_H

#if 0
  #define   ICS_R5F11B7X    /* 24pin ROM=64kB */
  #define   ICS_R5F11BBX    /* 32pin ROM=64kB */
  #define   ICS_R5F11BCX    /* 36pin ROM=64kB */
  #define   ICS_R5F11BGX    /* 48pin ROM=64kB */
#endif
  #define   ICS_R5F11BLX    /* 64pin ROM=64kB */

#ifdef  ICS_R5F11B7X
  #define   ICS_SCI0_P51_P50    (0x00)  /* Not supported */
  #define   ICS_SCI0_P17_P16    (0x01)  /* Not supported */
  #define   ICS_SCI1_P00_P01    (0x11)  /* Not supported */
  #define   ICS_SCI1_P72_P73    (0x12)  /* Not supported */
#endif

#ifdef  ICS_R5F11BBX
  #define   ICS_SCI0_P51_P50    (0x00)
  #define   ICS_SCI0_P17_P16    (0x01)  /* Not supported */
  #define   ICS_SCI1_P00_P01    (0x11)  /* Not supported */
  #define   ICS_SCI1_P72_P73    (0x12)  /* Not supported */
#endif

#ifdef  ICS_R5F11BCX
  #define   ICS_SCI0_P51_P50    (0x00)  /* Not supported */
  #define   ICS_SCI0_P17_P16    (0x01)  /* Not supported */
  #define   ICS_SCI1_P00_P01    (0x11)  /* Not supported */
#endif

#ifdef  ICS_R5F11BGX
  #define   ICS_SCI0_P51_P50    (0x00)  /* Not supported */
  #define   ICS_SCI0_P17_P16    (0x01)  /* Not supported */
  #define   ICS_SCI1_P00_P01    (0x11)  /* Not supported */
  #define   ICS_SCI1_P72_P73    (0x12)  /* Not supported */
#endif

#ifdef  ICS_R5F11BLX
  #define   ICS_SCI0_P51_P50    (0x00)  /* Not supported */
  #define   ICS_SCI0_P17_P16    (0x01)  /* Not supported */
  #define   ICS_SCI1_P02_P03    (0x10)  /* Not supported */
#ifdef __CA78K0R__
  #define   ICS_SCI2_P77_P76    (0x20)
#else
  #define   ICS_SCI2_P77_P76    (0x21)
#endif

#endif

#ifdef __CA78K0R__
void  ics_init(unsigned int addr, char pin, char level, unsigned char num);
void  ics_watchpoint(void); 
#else
void  ics2_init(unsigned int addr, char pin, char level, char num, char brr, char mode );
void  ics2_watchpoint(void); 
#endif

void  int_ics_sci_tx(void);
void  int_ics_sci_rx(void);
void  int_ics_sci_err(void);

#endif  /* ICS_RL78G1F_H */
