#include "r_mtr_common.h"
#include  "ICS_define.h"

#pragma interrupt Excep_INTST2 ( vect = INTST2  , bank = RB1 )
#pragma interrupt Excep_INTSR2 ( vect = INTSR2  , bank = RB1 )
#pragma interrupt Excep_INTSRE2( vect = INTSRE2 , bank = RB1 )

#include  "ics_RL78G1F_Lx.h"

__interrupt void  Excep_INTST2(void)
{
    int_ics_sci_tx();
}
__interrupt void  Excep_INTSR2(void)
{
    int_ics_sci_rx();
}
__interrupt void  Excep_INTSRE2(void)
{
     int_ics_sci_err();
}
