
/*********** HARDWARE / CPU DEFINITION **************/
#define   RL78
