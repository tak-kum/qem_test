/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.    
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ics.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.04.2020 2.00
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"
#include "r_mtr_common.h"
#include "r_mtr_ics.h"
#include "r_dsp.h"
#include "r_mtr_fixed.h"
#include "r_mtr_pu_system.h"
#include "r_mtr_spm_120.h"
#include "r_mtr_driver_access.h"

/****** for ICS ******/
#include "ics_RL78G1F_Lx.h"
/*********************/

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
uint8_t    com_u1_direction;                  /* rotation direction (0:CW,1:CCW) */
uint16_t   com_u2_mtr_pp;                     /* motor pole pairs */
float      com_f4_mtr_r;                      /* resistance [ohm] */
float      com_f4_mtr_ld;                     /* d-axis inductance [H] */
float      com_f4_mtr_lq;                     /* q-axis inductance [H] */
float      com_f4_mtr_m;                      /* Induced voltage constant [V s/rad] */
float      com_f4_mtr_j;                      /* rotor inertia [kgm^2] */

int16_t    com_s2_ref_speed_rpm;              /* motor speed reference [rpm] */
int16_t    com_s2_ramp_limit_speed_rpm;       /* limit of acceleration [rpm/ms] */
float      com_f4_ramp_limit_v;               /* limit of rate of voltage change [V/ms] */

float      com_f4_kp_speed;                   /* proportional gain for speed PI control [V s/rad] */
float      com_f4_kidt_speed;                 /* integral gain for speed PI control [V s/rad] */

#if (MTRCONF_SENSOR_MODE == HALL)
float      com_f4_start_ref_v;                /* openloop start reference voltage [V] */

#elif (MTRCONF_SENSOR_MODE == LESS)
float      com_f4_draw_in_ref_v;              /* voltage reference at draw-in [V] */
float      com_f4_ol_ref_v;                   /* openloop start reference voltage [V] */
int16_t    com_s2_ol2less_speed_rpm ;         /* openloop to sensorless control change speed [rpm] */
int16_t    com_s2_ol2less_ramp_speed_rpm;     /* accelerattion at translating into PI control [rpm/ms] */
int16_t    com_s2_angle_shift_adjust;         /* adjust for delay counts */
#endif

int16_t    com_s2_enable_write;               /* ICS write enable flag */
int16_t    g_s2_enable_write;                 /* ICS write enable flag */

mtr_ctrl_input_t   st_ics_input;              /* struct for ICS input */

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : mtr_set_com_variables
* Description   : Set command values to ICS variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_com_variables(void)
{
    /*============================*/
    /*      get ICS value         */
    /*============================*/
    /***** limit input speed *****/
    com_s2_ref_speed_rpm = R_MTR_Limit(com_s2_ref_speed_rpm, CP_MAX_SPEED_RPM, CP_MIN_SPEED_RPM);

    /***** When com_s2_enable_write and g_s2_enable_write are same value, rewrite enable. *****/
    if (com_s2_enable_write == g_s2_enable_write)
    {
        /* rotation direction */
        if (R_MTR_GetDir() != com_u1_direction)
        {
            if (com_u1_direction > MTR_CCW)
            {
                com_u1_direction = MTR_CCW;
            }
        }
        st_ics_input.u1_dir = com_u1_direction;

        /* motor parameters */
        st_ics_input.st_motor.u2_mtr_pp = com_u2_mtr_pp;
        st_ics_input.st_motor.s2_mtr_r  = FIX_fromfloat(com_f4_mtr_r * PU_SF_RES, MTR_Q_RES);
        st_ics_input.st_motor.s2_mtr_m  = FIX_fromfloat(com_f4_mtr_m * PU_SF_FLUX, MTR_Q_FLUX);
        st_ics_input.st_motor.s2_mtr_ld = FIX_fromfloat(com_f4_mtr_ld * PU_SF_IND, MTR_Q_IND);
        st_ics_input.st_motor.s2_mtr_lq = FIX_fromfloat(com_f4_mtr_lq * PU_SF_IND, MTR_Q_IND);
        st_ics_input.st_motor.s2_mtr_j  = FIX_fromfloat(com_f4_mtr_j * PU_SF_INERTIA, MTR_Q_INERTIA);

        /* reference speed */
        st_ics_input.s2_ref_speed_rad = mtr_conv_rpm2rad_pu(com_s2_ref_speed_rpm);
        /* limit of acceleration */
        st_ics_input.s2_ramp_limit_speed_rad = mtr_conv_rpm2rad_pu(com_s2_ramp_limit_speed_rpm);
        /* limit of variation of voltage */
        st_ics_input.s2_ramp_limit_v = FIX_fromfloat(com_f4_ramp_limit_v * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

        /* speed PI gain */
        st_ics_input.st_gain.s2_speed_pi_kp = FIX_fromfloat(com_f4_kp_speed * PU_SF_SPEED_KP, MTR_Q_SPEED_KP);
        st_ics_input.st_gain.s2_speed_pi_kidt = FIX_fromfloat(com_f4_kidt_speed * PU_SF_SPEED_KIDT, MTR_Q_SPEED_KIDT);

#if (MTRCONF_SENSOR_MODE == HALL)
        /* initial reference voltage */
        st_ics_input.s2_start_ref_v = FIX_fromfloat(com_f4_start_ref_v * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

#elif (MTRCONF_SENSOR_MODE == LESS)
        /* voltage reference at draw-in */
        st_ics_input.s2_draw_in_ref_v = FIX_fromfloat(com_f4_draw_in_ref_v * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
        /* open-loop start reference voltage */
        st_ics_input.s2_ol_ref_v = FIX_fromfloat(com_f4_ol_ref_v * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
        /* speed to change from open-loop drive to sensorless control */
        st_ics_input.s2_ol2less_speed_rad = mtr_conv_rpm2rad_pu(com_s2_ol2less_speed_rpm);
        /* accelerattion at translating into PI control */
        st_ics_input.s2_ol2less_ramp_speed_rad = mtr_conv_rpm2rad_pu(com_s2_ol2less_ramp_speed_rpm);
        /* speed to change from sensorless control to open-loop drive */
        st_ics_input.s2_less2ol_speed_rad = mtr_conv_rpm2rad_pu(com_s2_ol2less_speed_rpm - MTR_LESS2OL_HYSTERESIS);
        /* adjust for delay counts */
        st_ics_input.s2_angle_shift_adjust = com_s2_angle_shift_adjust;
#endif

        R_MTR_IcsInput(&st_ics_input);

        g_s2_enable_write ^= 1;                         /* change every time 0 and 1 */
    }

} /* End of function mtr_set_com_variables */

/***********************************************************************************************************************
* Function Name : mtr_ics_variables_init
* Description   : Initialize valiables for main process
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_ics_variables_init(void)
{
    /* rotation direction */
    com_u1_direction               = MTR_CW;

    /* motor parameters */
    com_u2_mtr_pp                  = MP_POLE_PAIRS;
    com_f4_mtr_r                   = MP_RESISTANCE;
    com_f4_mtr_ld                  = MP_D_INDUCTANCE;
    com_f4_mtr_lq                  = MP_Q_INDUCTANCE;
    com_f4_mtr_m                   = MP_MAGNETIC_FLUX;
    com_f4_mtr_j                   = MP_ROTOR_INERTIA;

    /* reference speed */
    com_s2_ref_speed_rpm           = 0;
    /* limit of acceleration */
    com_s2_ramp_limit_speed_rpm    = CP_RAMP_LIMIT_SPEED_RPM;
    /* limit of variation of voltage */
    com_f4_ramp_limit_v            = CP_RAMP_LIMIT_V;

    /* speed PI gain */
    com_f4_kp_speed                = CP_SPEED_PI_KP;
    com_f4_kidt_speed              = CP_SPEED_PI_KIDT;

#if (MTRCONF_SENSOR_MODE == HALL)
    /* open-loop start reference voltage */
    com_f4_start_ref_v             = CP_START_REF_V;

#elif (MTRCONF_SENSOR_MODE == LESS)
    /* voltage reference at draw-in */
    com_f4_draw_in_ref_v           = CP_DRAW_IN_REF_V;
    /* open-loop start reference voltage */
    com_f4_ol_ref_v                = CP_OL_REF_V;
    /* open-loop to sensorless control change speed */
    com_s2_ol2less_speed_rpm       = CP_OL2LESS_SPEED_RPM;
    /* acceleration at translating into PI control */
    com_s2_ol2less_ramp_speed_rpm  = CP_OL2LESS_SPEED_RAMP_RPM;
    /* adjust for delay counts */
    com_s2_angle_shift_adjust      = 0;
#endif

    /* ICS write enable flag */
    com_s2_enable_write            = 0;
    g_s2_enable_write              = 0;
} /* End of function mtr_ics_variables_init */

/***********************************************************************************************************************
* Function Name : R_MTR_Limit
* Description   : Compare with max limit and minimum limit
* Arguments     : s2_value - target value,
*               : s2_max   - max limit,
*               : s2_min   - minimum limit
* Return Value  : limited target value
***********************************************************************************************************************/
int16_t R_MTR_Limit(int16_t s2_value, int16_t s2_max, int16_t s2_min)
{
    int16_t s2_temp;

    s2_temp = s2_value;

    if (s2_value > s2_max)
    {
        /* max limit */
        s2_temp = s2_max;
    }
    else if (s2_value < s2_min)
    {
        /* minimum limit */
        s2_temp = s2_min;
    }
    else
    {
        /* do nothing */
    }

    return (s2_temp);
} /* End of function R_MTR_Limit */
